<?php
/** Malay (Bahasa Melayu)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Algazel-ms
 * @author Anakmalaysia
 * @author Aurora
 * @author Aviator
 * @author CoolCityCat
 * @author Diagramma Della Verita
 * @author Hydra
 * @author Izzudin
 * @author Kaganer
 * @author Kurniasan
 * @author Meno25
 * @author Putera Luqman Tunku Andre
 * @author Urhixidur
 * @author Yosri
 * @author Zamwan
 * @author לערי ריינהארט
 */

/**
 * CHANGELOG
 * =========
 * Init - This localisation is based on a file kindly donated by the folks at MIMOS
 * http://www.asiaosc.org/enwiki/page/Knowledgebase_Home.html
 * Sep 2007 - Rewritten by the folks at ms.wikipedia.org
 */

$defaultDateFormat = 'dmy';

$namespaceNames = array(
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Khas',
	NS_TALK             => 'Perbincangan',
	NS_USER             => 'Pengguna',
	NS_USER_TALK        => 'Perbincangan_pengguna',
	NS_PROJECT_TALK     => 'Perbincangan_$1',
	NS_FILE             => 'Fail',
	NS_FILE_TALK        => 'Perbincangan_fail',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'Perbincangan_MediaWiki',
	NS_TEMPLATE         => 'Templat',
	NS_TEMPLATE_TALK    => 'Perbincangan_templat',
	NS_HELP             => 'Bantuan',
	NS_HELP_TALK        => 'Perbincangan_bantuan',
	NS_CATEGORY         => 'Kategori',
	NS_CATEGORY_TALK    => 'Perbincangan_kategori',
);

$namespaceAliases = array(
	'Imej' => NS_FILE,
	'Perbincangan_Imej' => NS_FILE_TALK,
	'Istimewa'            => NS_SPECIAL,
	'Perbualan'           => NS_TALK,
	'Perbualan_Pengguna'  => NS_USER_TALK,
	'Perbualan_$1'        => NS_PROJECT_TALK,
	'Imej_Perbualan'      => NS_FILE_TALK,
	'MediaWiki_Perbualan' => NS_MEDIAWIKI_TALK,
	'Perbualan_Templat'   => NS_TEMPLATE_TALK,
	'Perbualan_Kategori'  => NS_CATEGORY_TALK,
	'Perbualan_Bantuan'   => NS_HELP_TALK,
);

$magicWords = array(
	'redirect'                  => array( '0', '#LENCONG', '#REDIRECT' ),
	'currentmonth'              => array( '1', 'BULANSEMASA', 'BULANSEMASA2', 'CURRENTMONTH', 'CURRENTMONTH2' ),
	'currentmonth1'             => array( '1', 'BULANSEMASA1', 'CURRENTMONTH1' ),
	'currentmonthname'          => array( '1', 'NAMABULANSEMASA', 'CURRENTMONTHNAME' ),
	'currentmonthnamegen'       => array( '1', 'NAMABULANSEMASAGEN', 'CURRENTMONTHNAMEGEN' ),
	'currentmonthabbrev'        => array( '1', 'SINGBULANSEMASA', 'CURRENTMONTHABBREV' ),
	'currentday'                => array( '1', 'HARISEMASA', 'CURRENTDAY' ),
	'currentday2'               => array( '1', 'HARISEMASA2', 'CURRENTDAY2' ),
	'currentdayname'            => array( '1', 'NAMAHARISEMASA', 'CURRENTDAYNAME' ),
	'currentyear'               => array( '1', 'TAHUNSEMASA', 'CURRENTYEAR' ),
	'currenttime'               => array( '1', 'WAKTUSEMASA', 'CURRENTTIME' ),
	'currenthour'               => array( '1', 'JAMSEMASA', 'CURRENTHOUR' ),
	'pagename'                  => array( '1', 'NAMALAMAN', 'PAGENAME' ),
	'pagenamee'                 => array( '1', 'NAMALAMANE', 'PAGENAMEE' ),
	'namespace'                 => array( '1', 'RUANGNAMA', 'NAMESPACE' ),
	'namespacee'                => array( '1', 'RUANGNAMAE', 'NAMESPACEE' ),
	'namespacenumber'           => array( '1', 'NOMBORRUANGNAMA', 'NAMESPACENUMBER' ),
	'talkspace'                 => array( '1', 'RUANGBINCANG', 'TALKSPACE' ),
	'talkspacee'                => array( '1', 'RUANGBINCANGE', 'TALKSPACEE' ),
	'fullpagename'              => array( '1', 'NAMALAMANPENUH', 'FULLPAGENAME' ),
	'fullpagenamee'             => array( '1', 'NAMALAMANPENUHE', 'FULLPAGENAMEE' ),
	'msg'                       => array( '0', 'PESAN:', 'MSG:' ),
	'subst'                     => array( '0', 'TUKAR:', 'SUBST:' ),
	'img_right'                 => array( '1', 'kiri', 'right' ),
	'img_left'                  => array( '1', 'kanan', 'left' ),
	'img_none'                  => array( '1', 'tiada', 'none' ),
	'img_center'                => array( '1', 'tengah', 'center', 'centre' ),
	'img_border'                => array( '1', 'bingkai', 'border' ),
	'sitename'                  => array( '1', 'NAMATAPAK', 'SITENAME' ),
	'ns'                        => array( '0', 'RN:', 'NS:' ),
	'nse'                       => array( '0', 'RNE:', 'NSE:' ),
	'gender'                    => array( '0', 'JANTINA:', 'GENDER:' ),
	'currentweek'               => array( '1', 'MINGGUSEMASA', 'CURRENTWEEK' ),
);

$specialPageAliases = array(
	'Activeusers'               => array( 'Pengguna_aktif' ),
	'Allmessages'               => array( 'Semua_pesanan', 'Semua_mesej' ),
	'Allpages'                  => array( 'Semua_laman' ),
	'Ancientpages'              => array( 'Laman_lapuk' ),
	'Blankpage'                 => array( 'Laman_kosong' ),
	'Block'                     => array( 'Sekat_IP' ),
	'Blockme'                   => array( 'Sekat_saya' ),
	'Booksources'               => array( 'Sumber_buku' ),
	'BrokenRedirects'           => array( 'Lencongan_rosak', 'Pelencongan_rosak' ),
	'Categories'                => array( 'Kategori' ),
	'ChangeEmail'               => array( 'Tukar_e-mel' ),
	'ChangePassword'            => array( 'Lupa_kata_laluan' ),
	'ComparePages'              => array( 'Banding_laman' ),
	'Confirmemail'              => array( 'Sahkan_e-mel' ),
	'Contributions'             => array( 'Sumbangan' ),
	'CreateAccount'             => array( 'Buka_akaun' ),
	'Deadendpages'              => array( 'Laman_buntu' ),
	'DeletedContributions'      => array( 'Sumbangan_dihapuskan' ),
	'Disambiguations'           => array( 'Penyahtaksaan', 'Nyahkekaburan' ),
	'DoubleRedirects'           => array( 'Lencongan_berganda', 'Pelencongan_berganda' ),
	'Emailuser'                 => array( 'E-mel_pengguna' ),
	'Export'                    => array( 'Eksport' ),
	'Fewestrevisions'           => array( 'Semakan_tersikit' ),
	'FileDuplicateSearch'       => array( 'Cari_fail_berganda' ),
	'Filepath'                  => array( 'Laluan_fail' ),
	'Invalidateemail'           => array( 'Batalkan_pengesahan_e-mel' ),
	'BlockList'                 => array( 'Sekatan_IP' ),
	'LinkSearch'                => array( 'Cari_pautan' ),
	'Listadmins'                => array( 'Senarai_pentadbir' ),
	'Listbots'                  => array( 'Senarai_bot' ),
	'Listfiles'                 => array( 'Senarai_imej' ),
	'Listgrouprights'           => array( 'Senarai_hak_kumpulan' ),
	'Listredirects'             => array( 'Senarai_lencongan', 'Senarai_pelencongan' ),
	'Listusers'                 => array( 'Senarai_pengguna' ),
	'Lockdb'                    => array( 'Kunci_pangkalan_data' ),
	'Lonelypages'               => array( 'Laman_yatim' ),
	'Longpages'                 => array( 'Laman_panjang' ),
	'MergeHistory'              => array( 'Gabung_sejarah' ),
	'MIMEsearch'                => array( 'Gelintar_MIME' ),
	'Mostcategories'            => array( 'Kategori_terbanyak' ),
	'Mostimages'                => array( 'Imej_terbanyak' ),
	'Mostlinked'                => array( 'Laman_dipaut_terbanyak' ),
	'Mostlinkedcategories'      => array( 'Kategori_dipaut_terbanyak' ),
	'Mostlinkedtemplates'       => array( 'Templat_dipaut_terbanyak' ),
	'Mostrevisions'             => array( 'Semakan_terbanyak' ),
	'Movepage'                  => array( 'Pindah_laman' ),
	'Mycontributions'           => array( 'Sumbangan_saya' ),
	'Mypage'                    => array( 'Laman_saya' ),
	'Mytalk'                    => array( 'Perbincangan_saya' ),
	'Myuploads'                 => array( 'Muat_naik_saya' ),
	'Newimages'                 => array( 'Imej_baru' ),
	'Newpages'                  => array( 'Laman_baru' ),
	'Popularpages'              => array( 'Laman_popular' ),
	'Preferences'               => array( 'Keutamaan' ),
	'Prefixindex'               => array( 'Indeks_awalan' ),
	'Protectedpages'            => array( 'Laman_dilindungi' ),
	'Protectedtitles'           => array( 'Tajuk_dilindungi' ),
	'Randompage'                => array( 'Laman_rawak' ),
	'Randomredirect'            => array( 'Lencongan_rawak', 'Pelencongan_rawak' ),
	'Recentchanges'             => array( 'Perubahan_terkini' ),
	'Recentchangeslinked'       => array( 'Perubahan_berkaitan' ),
	'Revisiondelete'            => array( 'Hapus_semakan' ),
	'Search'                    => array( 'Gelintar' ),
	'Shortpages'                => array( 'Laman_pendek' ),
	'Specialpages'              => array( 'Laman_khas' ),
	'Statistics'                => array( 'Statistik' ),
	'Tags'                      => array( 'Label' ),
	'Unblock'                   => array( 'Nyahsekat' ),
	'Uncategorizedcategories'   => array( 'Kategori_tanpa_kategori' ),
	'Uncategorizedimages'       => array( 'Imej_tanpa_kategori' ),
	'Uncategorizedpages'        => array( 'Laman_tanpa_kategori' ),
	'Uncategorizedtemplates'    => array( 'Templat_tanpa_kategori' ),
	'Undelete'                  => array( 'Nyahhapus' ),
	'Unlockdb'                  => array( 'Buka_kunci_pangkalan_data' ),
	'Unusedcategories'          => array( 'Kategori_tak_digunakan' ),
	'Unusedimages'              => array( 'Imej_tak_digunakan' ),
	'Unusedtemplates'           => array( 'Templat_tak_digunakan' ),
	'Unwatchedpages'            => array( 'Laman_tak_dipantau' ),
	'Upload'                    => array( 'Muat_naik' ),
	'Userlogin'                 => array( 'Log_masuk' ),
	'Userlogout'                => array( 'Log_keluar' ),
	'Userrights'                => array( 'Hak_pengguna' ),
	'Version'                   => array( 'Versi' ),
	'Wantedcategories'          => array( 'Kategori_dikehendaki' ),
	'Wantedfiles'               => array( 'Fail_dikehendaki' ),
	'Wantedpages'               => array( 'Laman_dikehendaki' ),
	'Wantedtemplates'           => array( 'Templat_dikehendaki' ),
	'Watchlist'                 => array( 'Senarai_pantau' ),
	'Whatlinkshere'             => array( 'Pautan_ke' ),
	'Withoutinterwiki'          => array( 'Laman_tanpa_pautan_bahasa' ),
);

$messages = array(
# User preference toggles
'tog-underline' => 'Gariskan pautan:',
'tog-justify' => 'Laraskan perenggan',
'tog-hideminor' => 'Sembunyikan suntingan kecil dalam laman perubahan terkini',
'tog-hidepatrolled' => 'Sorokkan suntingan yang telah dironda daripada senarai perubahan terkini',
'tog-newpageshidepatrolled' => 'Sorokkan laman yang telah dironda daripada senarai laman baru',
'tog-extendwatchlist' => 'Kembangkan senarai pantau untuk memaparkan semua perubahan, bukan hanya yang terkini',
'tog-usenewrc' => 'Perubahan kumpulan mengikut laman dalam perubahan terkini dan senarai pantau',
'tog-numberheadings' => 'Nomborkan tajuk secara automatik',
'tog-showtoolbar' => 'Tunjukkan palang sunting (perlukan JavaScript)',
'tog-editondblclick' => 'Dwiklik untuk sunting laman (JavaScript)',
'tog-editsection' => 'Bolehkan penyuntingan bahagian melalui pautan [sunting]',
'tog-editsectiononrightclick' => 'Bolehkan penyuntingan bahagian dengan mengklik kanan pada tajuk bahagian',
'tog-showtoc' => 'Tunjukkan isi kandungan (bagi rencana yang melebihi 3 tajuk)',
'tog-rememberpassword' => 'Ingat log masuk saya di pelayar ini (tidak melebihi $1 {{PLURAL:$1|hari|hari}})',
'tog-watchcreations' => 'Tambahkan laman yang saya buat dan fail yang saya muat naik ke dalam senarai pantau',
'tog-watchdefault' => 'Tambahkan laman dan fail yang saya sunting ke dalam senarai pantau',
'tog-watchmoves' => 'Tambahkan laman dan fail yang saya pindahkan ke dalam senarai pantau',
'tog-watchdeletion' => 'Tambahkan laman dan fail yang saya hapuskan ke dalam senarai pantau',
'tog-minordefault' => 'Tandakan semua suntingan sebagai kecil secara asali',
'tog-previewontop' => 'Tunjukkan pralihat di atas kotak sunting',
'tog-previewonfirst' => 'Tunjukkan pralihat pada suntingan pertama',
'tog-nocache' => 'Lumpuhkan pengagregatan laman',
'tog-enotifwatchlistpages' => 'E-mel kepada saya tentang perubahan pada halaman-halaman dan fail-fail dalam senarai pantau saya',
'tog-enotifusertalkpages' => 'E-melkan saya apabila berlaku perubahan pada laman perbincangan saya',
'tog-enotifminoredits' => 'Juga e-mel kepada saya tentang suntingan kecil pada halaman-halaman dan fail-fail',
'tog-enotifrevealaddr' => 'Serlahkan alamat e-mel saya dalam e-mel pemberitahuan',
'tog-shownumberswatching' => 'Tunjukkan bilangan pemantau',
'tog-oldsig' => 'Tanda tangan yang sedia ada:',
'tog-fancysig' => 'Anggap tandatangan sebagai teks wiki (tanpa pautan automatik)',
'tog-uselivepreview' => 'Gunakan pralihat langsung (dalam percubaan)',
'tog-forceeditsummary' => 'Tanya saya jika ringkasan suntingan kosong',
'tog-watchlisthideown' => 'Sembunyikan suntingan saya daripada senarai pantau',
'tog-watchlisthidebots' => 'Sembunyikan suntingan bot daripada senarai pantau',
'tog-watchlisthideminor' => 'Sembunyikan suntingan kecil daripada senarai pantau',
'tog-watchlisthideliu' => 'Sembunyikan suntingan oleh pengguna log masuk daripada senarai pantau',
'tog-watchlisthideanons' => 'Sembunyikan suntingan oleh pengguna tanpa nama daripada senarai pantau',
'tog-watchlisthidepatrolled' => 'Sorokkan suntingan yang telah dironda daripada senarai pantau',
'tog-ccmeonemails' => 'Kirimkan saya salinan e-mel yang saya hantar kepada pengguna lain',
'tog-diffonly' => 'Jangan tunjukkan kandungan laman di bawah perbezaan',
'tog-showhiddencats' => 'Tunjukkan kategori tersembunyi',
'tog-noconvertlink' => 'Lumpuhkan penukaran tajuk pautan',
'tog-norollbackdiff' => 'Abaikan perbezaan selepas melakukan pengunduran suntingan.',
'tog-useeditwarning' => 'Beri saya amaran apabila saya meninggalkan sesebuah laman penyuntingan tanpa menyimpan perubahan.',
'tog-prefershttps' => 'Sentiasa gunakan sambungan terlindung apabila log masuk',

'underline-always' => 'Sentiasa',
'underline-never' => 'Jangan',
'underline-default' => 'Tetapan lalai kulit/pelayar',

# Font style option in Special:Preferences
'editfont-style' => 'Gaya fon ruang sunting:',
'editfont-default' => 'Lalaian pelayar web',
'editfont-monospace' => 'Fon monospace',
'editfont-sansserif' => 'Fon sans-serif',
'editfont-serif' => 'Fon serif',

# Dates
'sunday' => 'Ahad',
'monday' => 'Isnin',
'tuesday' => 'Selasa',
'wednesday' => 'Rabu',
'thursday' => 'Khamis',
'friday' => 'Jumaat',
'saturday' => 'Sabtu',
'sun' => 'Ahd',
'mon' => 'Isn',
'tue' => 'Sel',
'wed' => 'Rab',
'thu' => 'Kha',
'fri' => 'Jum',
'sat' => 'Sab',
'january' => 'Januari',
'february' => 'Februari',
'march' => 'Mac',
'april' => 'April',
'may_long' => 'Mei',
'june' => 'Jun',
'july' => 'Julai',
'august' => 'Ogos',
'september' => 'September',
'october' => 'Oktober',
'november' => 'November',
'december' => 'Disember',
'january-gen' => 'Januari',
'february-gen' => 'Februari',
'march-gen' => 'Mac',
'april-gen' => 'April',
'may-gen' => 'Mei',
'june-gen' => 'Jun',
'july-gen' => 'Julai',
'august-gen' => 'Ogos',
'september-gen' => 'September',
'october-gen' => 'Oktober',
'november-gen' => 'November',
'december-gen' => 'Disember',
'jan' => 'Jan',
'feb' => 'Feb',
'mar' => 'Mac',
'apr' => 'Apr',
'may' => 'Mei',
'jun' => 'Jun',
'jul' => 'Jul',
'aug' => 'Ogs',
'sep' => 'Sep',
'oct' => 'Okt',
'nov' => 'Nov',
'dec' => 'Dis',
'january-date' => '$1 Januari',
'february-date' => '$1 Februari',
'march-date' => '$1 Mac',
'april-date' => '$1 April',
'may-date' => '$1 Mei',
'june-date' => '$1 Jun',
'july-date' => '$1 Julai',
'august-date' => '$1 Ogos',
'september-date' => '$1 September',
'october-date' => '$1 Oktober',
'november-date' => '$1 November',
'december-date' => '$1 Disember',

# Categories related messages
'pagecategories' => '{{PLURAL:$1|Kategori|Kategori}}',
'category_header' => 'Laman-laman dalam kategori "$1"',
'subcategories' => 'Subkategori',
'category-media-header' => 'Media-media dalam kategori "$1"',
'category-empty' => "''Kategori ini tidak mengandungi sebarang laman atau media.''",
'hidden-categories' => '{{PLURAL:$1|Kategori tersembunyi|Kategori-kategori tersembunyi}}',
'hidden-category-category' => 'Kategori tersembunyi',
'category-subcat-count' => '{{PLURAL:$2|Kategori ini mengandungi sebuah subkategori berikut.|Yang berikut ialah $1 daripada $2 buah subkategori dalam kategori ini.}}',
'category-subcat-count-limited' => 'Katergori ini mengandungi {{PLURAL:$1|subkategori|$1 subkategori}}.',
'category-article-count' => '{{PLURAL:$2|Kategori ini mengandungi sebuah laman berikut.|Yang berikut ialah $1 daripada $2 buah laman dalam kategori ini.}}',
'category-article-count-limited' => '{{PLURAL:$1|Laman berikut|$1 laman berikut}} kini terkandung dalam kategori terkini.',
'category-file-count' => '{{PLURAL:$2|Kategori ini mengandungi sebuah fail berikut.|Yang berikut ialah $1 daripada $2 buah fail dalam kategori ini.}}',
'category-file-count-limited' => '$1 fail berikut terdapat dalam kategori ini.',
'listingcontinuesabbrev' => 'samb.',
'index-category' => 'Laman terindeks',
'noindex-category' => 'Laman tak diindeks',
'broken-file-category' => 'Laman yang ada pautan fail yang terputus',

'linkprefix' => '/^((?>.*(?<![a-zA-Z\\x80-\\xff])))(.+)$/sD',

'about' => 'Perihal',
'article' => 'Laman kandungan',
'newwindow' => '(dibuka di tetingkap baru)',
'cancel' => 'Batal',
'moredotdotdot' => 'Lagi...',
'morenotlisted' => 'Senarai ini tidak lengkap.',
'mypage' => 'Halaman',
'mytalk' => 'Perbualan',
'anontalk' => 'Perbualan bagi IP ini',
'navigation' => 'Pandu arah',
'and' => '&#32;dan',

# Cologne Blue skin
'qbfind' => 'Cari',
'qbbrowse' => 'Semak imbas',
'qbedit' => 'Sunting',
'qbpageoptions' => 'Laman ini',
'qbmyoptions' => 'Laman-laman saya',
'qbspecialpages' => 'Laman khas',
'faq' => 'Soalan Lazim',
'faqpage' => 'Project:Soalan Lazim',

# Vector skin
'vector-action-addsection' => 'Buka topik',
'vector-action-delete' => 'Hapuskan',
'vector-action-move' => 'Pindahkan',
'vector-action-protect' => 'Lindungi',
'vector-action-undelete' => 'Batal hapus',
'vector-action-unprotect' => 'Ubah perlindungan',
'vector-simplesearch-preference' => 'Bolehkan bar carian ringkas (kulit Vector sahaja)',
'vector-view-create' => 'Cipta',
'vector-view-edit' => 'Sunting',
'vector-view-history' => 'Lihat sejarah',
'vector-view-view' => 'Baca',
'vector-view-viewsource' => 'Lihat sumber',
'actions' => 'Tindakan',
'namespaces' => 'Ruang nama',
'variants' => 'Kelainan',

'navigation-heading' => 'Menu pandu arah',
'errorpagetitle' => 'Ralat',
'returnto' => 'Kembali ke $1.',
'tagline' => 'Daripada {{SITENAME}}.',
'help' => 'Bantuan',
'search' => 'Cari',
'searchbutton' => 'Cari',
'go' => 'Pergi',
'searcharticle' => 'Pergi',
'history' => 'Sejarah laman',
'history_short' => 'Sejarah',
'updatedmarker' => 'dikemaskinikan sejak kunjungan terakhir saya',
'printableversion' => 'Versi boleh cetak',
'permalink' => 'Pautan kekal',
'print' => 'Cetak',
'view' => 'Paparkan',
'edit' => 'Sunting',
'create' => 'Cipta',
'editthispage' => 'Sunting laman ini',
'create-this-page' => 'Cipta laman ini',
'delete' => 'Hapuskan',
'deletethispage' => 'Hapuskan laman ini',
'undeletethispage' => 'Nyahhapuskan halaman ini',
'undelete_short' => 'Nyahhapus {{PLURAL:$1|satu suntingan|$1 suntingan}}',
'viewdeleted_short' => 'Papar {{PLURAL:$1|satu|$1}} suntingan dihapuskan',
'protect' => 'Lindung',
'protect_change' => 'ubah',
'protectthispage' => 'Lindungi laman ini',
'unprotect' => 'Ubah perlindungan',
'unprotectthispage' => 'Ubah tahap perlindungan laman ini',
'newpage' => 'Laman baru',
'talkpage' => 'Bincangkan laman ini',
'talkpagelinktext' => 'Perbualan',
'specialpage' => 'Laman Khas',
'personaltools' => 'Alatan peribadi',
'postcomment' => 'Bahagian baru',
'articlepage' => 'Lihat laman kandungan',
'talk' => 'Perbincangan',
'views' => 'Rupa',
'toolbox' => 'Alatan',
'userpage' => 'Lihat laman pengguna',
'projectpage' => 'Lihat laman projek',
'imagepage' => 'Lihat laman fail',
'mediawikipage' => 'Lihat laman pesanan',
'templatepage' => 'Lihat laman templat',
'viewhelppage' => 'Lihat laman bantuan',
'categorypage' => 'Lihat laman kategori',
'viewtalkpage' => 'Lihat perbincangan',
'otherlanguages' => 'Bahasa lain',
'redirectedfrom' => '(Dilencongkan dari $1)',
'redirectpagesub' => 'Laman lencongan',
'lastmodifiedat' => 'Laman ini diubah buat kali terakhir pada $2, $1.',
'viewcount' => 'Laman ini telah dilihat {{PLURAL:$1|sekali|sebanyak $1 kali}}.',
'protectedpage' => 'Laman dilindungi',
'jumpto' => 'Lompat ke:',
'jumptonavigation' => 'pandu arah',
'jumptosearch' => 'cari',
'view-pool-error' => 'Maaf, pelayan terlebih bebanan pada masa ini.
Terlalu ramai pengguna cuba melihat laman ini.
Sila tunggu sebentar sebelum cuba mencapai laman ini lagi.

$1',
'pool-timeout' => 'Menunggu sebentar untuk dikunci',
'pool-queuefull' => 'Giliran kolam telah penuh',
'pool-errorunknown' => 'Ralat tak diketahui',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage).
'aboutsite' => 'Perihal {{SITENAME}}',
'aboutpage' => 'Project:Perihal',
'copyright' => 'Kandungan disediakan di bawah $1 melainkan dinyatakan sebaliknya.',
'copyrightpage' => '{{ns:project}}:Hak cipta',
'currentevents' => 'Hal semasa',
'currentevents-url' => 'Project:Hal semasa',
'disclaimers' => 'Penolak tuntutan',
'disclaimerpage' => 'Project:Penolak tuntutan umum',
'edithelp' => 'Bantuan menyunting',
'helppage' => 'Help:Kandungan',
'mainpage' => 'Laman Utama',
'mainpage-description' => 'Laman utama',
'policy-url' => 'Project:Dasar',
'portal' => 'Portal masyarakat',
'portal-url' => 'Project:Portal Masyarakat',
'privacy' => 'Dasar privasi',
'privacypage' => 'Project:Dasar privasi',

'badaccess' => 'Tidak dibenarkan',
'badaccess-group0' => 'Anda tidak dibenarkan melaksanakan tindakan ini.',
'badaccess-groups' => 'Tindakan ini hanya boleh dilakukan oleh pengguna dari {{PLURAL:$2|kumpulan|kumpulan-kumpulan}} berikut: $1.',

'versionrequired' => 'MediaWiki versi $1 diperlukan',
'versionrequiredtext' => 'MediaWiki versi $1 diperlukan untuk menggunakan laman ini. Sila lihat [[Special:Version|laman versi]].',

'ok' => 'OK',
'pagetitle' => '$1 - {{SITENAME}}',
'pagetitle-view-mainpage' => '{{SITENAME}}',
'retrievedfrom' => 'Diambil daripada "$1"',
'youhavenewmessages' => 'Anda mempunyai $1 ($2).',
'newmessageslink' => 'pesanan baru',
'newmessagesdifflink' => 'perubahan terakhir',
'youhavenewmessagesfromusers' => 'Anda menerima $1 daripada {{PLURAL:$3|seorang|$3 orang}} pengguna lain ($2).',
'youhavenewmessagesmanyusers' => 'Anda menerima $1 daripada ramai pengguna ($2).',
'newmessageslinkplural' => '{{PLURAL:$1|pesanan|pesanan-pesanan}} baru',
'newmessagesdifflinkplural' => '{{PLURAL:$1|perubahan|perubahan-perubahan}} terkini',
'youhavenewmessagesmulti' => 'Anda telah menerima pesanan baru pada $1',
'editsection' => 'sunting',
'editold' => 'sunting',
'viewsourceold' => 'lihat sumber',
'editlink' => 'sunting',
'viewsourcelink' => 'lihat sumber',
'editsectionhint' => 'Sunting bahagian: $1',
'toc' => 'Isi kandungan',
'showtoc' => 'tunjukkan',
'hidetoc' => 'sorokkan',
'collapsible-collapse' => 'Lipat',
'collapsible-expand' => 'Kembangkan',
'thisisdeleted' => 'Lihat atau pulihkan $1?',
'viewdeleted' => 'Lihat $1?',
'restorelink' => '{{PLURAL:$1|satu|$1}} suntingan dihapuskan',
'feedlinks' => 'Suapan:',
'feed-invalid' => 'Jenis suapan langganan tidak sah.',
'feed-unavailable' => 'Tiada suapan pensindiketan',
'site-rss-feed' => 'Suapan RSS $1',
'site-atom-feed' => 'Suapan Atom $1',
'page-rss-feed' => 'Suapan RSS "$1"',
'page-atom-feed' => 'Suapan Atom "$1"',
'feed-atom' => 'Atom',
'feed-rss' => 'RSS',
'red-link-title' => '$1 (tidak wujud)',
'sort-descending' => 'Isih tertib menurun',
'sort-ascending' => 'Isih tertib menaik',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-main' => 'Laman',
'nstab-user' => 'Laman pengguna',
'nstab-media' => 'Laman media',
'nstab-special' => 'Laman khas',
'nstab-project' => 'Laman projek',
'nstab-image' => 'Fail',
'nstab-mediawiki' => 'Pesanan',
'nstab-template' => 'Templat',
'nstab-help' => 'Laman bantuan',
'nstab-category' => 'Kategori',

# Main script and global functions
'nosuchaction' => 'Tindakan tidak dikenali',
'nosuchactiontext' => 'Tindakan yang dinyatakan dalam URL ini tidak sah. Anda mungkin telah menaip URL yang salah atau mengikuti pautan yang tidak sah. Ini juga mungkin bererti terdapat pepijat dalam perisian yang digunakan oleh {{SITENAME}}.',
'nosuchspecialpage' => 'Laman khas tidak wujud',
'nospecialpagetext' => '<strong>Anda telah meminta laman khas yang tidak sah.</strong>

Senarai laman khas yang sah boleh dilihat di [[Special:SpecialPages]].',

# General errors
'error' => 'Ralat',
'databaseerror' => 'Ralat pangkalan data',
'databaseerror-text' => 'Ralat pertanyaan pangkalan data telah terjadi.
Ini mungkin menandakan pepijat dalam perisian.',
'databaseerror-textcl' => 'Ralat pertanyaan pangkalan data telah terjadi.',
'databaseerror-query' => 'Pertanyaan: $1',
'databaseerror-function' => 'Fungsi: $1',
'databaseerror-error' => 'Ralat: $1',
'laggedslavemode' => 'Amaran: Laman ini mungkin bukan yang terkini.',
'readonly' => 'Pangkalan data dikunci',
'enterlockreason' => 'Sila nyatakan sebab penguncian dan jangkaan
bila kunci ini akan dibuka.',
'readonlytext' => 'Pangkalan data sedang dikunci. Hal ini mungkin disebabkan oleh penyenggaraan rutin, dan akan dibuka semula selepas proses penyenggaraan ini siap.

Pentadbir yang menguncinya memberi penjelasan ini: $1',
'missing-article' => 'Teks bagi laman "$1" $2 tidak dijumpai dalam pangkalan data.

Perkara ini biasanya disebabkan oleh perbuatan mengikuti pautan perbezaan yang lama atau pautan ke laman yang telah dihapuskan.

Jika bukan ini sebabnya, anda mungkin telah menjumpai pepijat dalam perisian ini.
Sila catat URL bagi laman ini dan laporkan perkara ini kepada seorang [[Special:ListUsers/sysop|pentadbir]].',
'missingarticle-rev' => '(semakan $1)',
'missingarticle-diff' => '(Beza: $1, $2)',
'readonly_lag' => 'Pangkalan data telah dikunci secara automatik sementara semua pelayan pangkalan data diselaraskan.',
'internalerror' => 'Ralat dalaman',
'internalerror_info' => 'Ralat dalaman: $1',
'fileappenderrorread' => 'Tidak dapat membaca "$1" semasa tambah.',
'fileappenderror' => 'Tidak dapat menambah "$1" kepada "$2".',
'filecopyerror' => 'Fail "$1" tidak dapat disalin ke "$2".',
'filerenameerror' => 'Nama fail "$1" tidak dapat ditukarkan kepada "$2".',
'filedeleteerror' => 'Fail "$1" tidak dapat dihapuskan.',
'directorycreateerror' => 'Direktori "$1" gagal diciptakan.',
'filenotfound' => 'Fail "$1" tidak dijumpai.',
'fileexistserror' => 'File "$1" tidak dapat ditulis: fail telah pun wujud',
'unexpected' => 'Nilai tanpa diduga: "$1"="$2".',
'formerror' => 'Ralat: borang tidak dapat dikirim.',
'badarticleerror' => 'Tindakan ini tidak boleh dilaksanakan pada laman ini.',
'cannotdelete' => 'Laman atau fail $1 tidak dapat dihapuskan.
Ia mungkin telah pun dihapuskan oleh orang lain.',
'cannotdelete-title' => 'Laman "$1" tidak dapat dihapuskan',
'delete-hook-aborted' => 'Penghapusan dibatalkan oleh penyangkuk.
Tiada sebab diberikan.',
'no-null-revision' => 'Semakan nol baru untuk "$1" tidak dapat diwujudkan',
'badtitle' => 'Tajuk tidak sah',
'badtitletext' => 'Tajuk laman yang diminta tidak sah, kosong, ataupun tajuk antara bahasa atau tajuk antara wiki yang salah dipaut. Ia mungkin mengandungi aksara yang tidak dibenarkan.',
'perfcached' => 'Data yang berikut disimpan dalam cache dan mungkin tidak terkemas kini. Semaksimum {{PLURAL:$1|satu hasil|$1 hasil}} terdapat dalam cache.',
'perfcachedts' => 'Data yang berikut disimpan dalam cache dan kali terakhir dikemaskinikan pada $1. Semaksimum {{PLURAL:$4|satu hasil|$4 hasil}} terdapat dalam cache.',
'querypage-no-updates' => 'Buat masa ini, pengkemaskinian laman ini telah dilumpuhkan.
Data yang ada di sini tidak akan disegarkan semula sekarang.',
'wrong_wfQuery_params' => 'Parameter salah bagi wfQuery()<br />
Fungsi: $1<br />
Pertanyaan: $2',
'viewsource' => 'Lihat sumber',
'viewsource-title' => 'Lihat sumber bagi $1',
'actionthrottled' => 'Tindakan didikitkan',
'actionthrottledtext' => 'Untuk mencegah spam, anda dihadkan daripada melakukan tindakan ini berulang kali dalam ruang waktu yang singkat, dan anda telah melebihi had tersebut. Sila cuba lagi selepas beberapa minit.',
'protectedpagetext' => 'Laman ini telah dikunci untuk melarang penyuntingan atau sebarang tindakan yang lain.',
'viewsourcetext' => 'Anda boleh melihat dan menyalin sumber bagi laman ini:',
'viewyourtext' => "Anda boleh melihat dan menyalin sumber '''suntingan anda''' kepada laman ini:",
'protectedinterface' => 'Laman ini menyediakan teks antara muka bagi perisian ini, akan tetapi dikunci untuk menghalang penyalahgunaan.
Untuk menambah atau menyunting terjemahan untuk semua wiki, sila gunakan projek penyetempatan MediaWiki, [//translatewiki.net/ translatewiki.net].',
'editinginterface' => "'''Amaran:''' Anda sedang menyunting laman yang digunakan untuk menghasilkan teks antara muka bagi perisian ini. Sebarang perubahan terhadap laman ini akan menjejaskan rupa antara muka bagi pengguna-pengguna lain di wiki ini.
Untuk menambah atau menyunting terjemahan untuk semua wiki, sila gunakan projek penyetempatan MediaWiki, [//translatewiki.net/ translatewiki.net].",
'cascadeprotected' => 'Laman ini telah dilindungi daripada penyuntingan oleh pengguna selain penyelia, kerana ia termasuk dalam {{PLURAL:$1|laman|laman-laman}} berikut, yang dilindungi dengan secara "melata": $2',
'namespaceprotected' => "Anda tidak mempunyai keizinan untuk menyunting laman dalam ruang nama '''$1'''.",
'customcssprotected' => 'Anda tidak dibenarkan menyunting laman JavaScript ini kerana ia mengandungi tetapan peribadi pengguna lain.',
'customjsprotected' => 'Anda tidak dibenarkan menyunting laman JavaScript ini kerana ia mengandungi tetapan peribadi pengguna lain.',
'mycustomcssprotected' => 'Anda tiada kebenaran untuk menyunting halaman CSS ini.',
'mycustomjsprotected' => 'Anda tiada kebenaran untuk menyunting halaman JavaScript ini.',
'myprivateinfoprotected' => 'Anda tidak mempunyai kebenaran untuk menyunting maklumat peribadi anda.',
'mypreferencesprotected' => 'Anda tidak mempunyai kebenaran untuk menyunting tetapan keutamaan anda.',
'ns-specialprotected' => 'Laman khas tidak boleh disunting.',
'titleprotected' => "Tajuk ini telah dilindungi oleh [[User:$1|$1]] daripada dicipta. Sebab yang diberikan ialah ''$2''.",
'filereadonlyerror' => 'Fail "$1" tidak dapat diubah suai kerana repositori fail "$2" berada dalam ragam baca sahaja.

Pentadbir yang menguncinya memberikan penjelasan yang berikut: "$3".',
'invalidtitle-knownnamespace' => 'Tajuk tidak sah dengan ruang nama "$2" dan teks "$3"',
'invalidtitle-unknownnamespace' => 'Tajuk tidak sah dengan nombor ruang nama tidak dikenali $1 dan teks "$2"',
'exception-nologin' => 'Belum log masuk',
'exception-nologin-text' => 'Halaman atau tindakan ini memerlukan anda untuk log masuk ke dalam wiki ini.',

# Virus scanner
'virus-badscanner' => "Konfigurasi rosak: pengimbas virus yang tidak diketahui: ''$1''",
'virus-scanfailed' => 'pengimbasan gagal (kod $1)',
'virus-unknownscanner' => 'antivirus tidak dikenali:',

# Login and logout pages
'logouttext' => "'''Anda telah log keluar.'''

Sila ingat bahawa sesetengah halaman mungkin masih dipaparkan seolah-olah anda masih log masuk hingga anda memadamkan cache pelayar anda.",
'welcomeuser' => 'Selamat datang, $1!',
'welcomecreation-msg' => 'Akaun anda telah dibuka.
Jangan lupa untuk mengubah [[Special:Preferences|keutamaan anda di {{SITENAME}}]].',
'yourname' => 'Nama pengguna:',
'userlogin-yourname' => 'Nama pengguna',
'userlogin-yourname-ph' => 'Masukkan nama pengguna anda',
'createacct-another-username-ph' => 'Masukkan nama pengguna',
'yourpassword' => 'Kata laluan:',
'userlogin-yourpassword' => 'Kata laluan',
'userlogin-yourpassword-ph' => 'Masukkan kata laluan anda',
'createacct-yourpassword-ph' => 'Isikan kata laluan',
'yourpasswordagain' => 'Ulangi kata laluan:',
'createacct-yourpasswordagain' => 'Sahkan kata laluan',
'createacct-yourpasswordagain-ph' => 'Isikan kata laluan semula',
'remembermypassword' => 'Ingat log masuk saya pada pelayar ini (tidak melebihi $1 {{PLURAL:$1|hari|hari}})',
'userlogin-remembermypassword' => 'Biar saya kekal log masuk',
'userlogin-signwithsecure' => 'Gunakan sambungan terlindung',
'yourdomainname' => 'Domain anda:',
'password-change-forbidden' => 'Anda tidak dapat mengubah kata laluan di wiki ini.',
'externaldberror' => 'Berlaku ralat pangkalan data bagi pengesahan luar atau anda tidak dibenarkan mengemaskinikan akaun luar anda.',
'login' => 'Log masuk',
'nav-login-createaccount' => 'Log masuk / buka akaun',
'loginprompt' => 'Anda mesti membenarkan kuki untuk log masuk ke dalam {{SITENAME}}.',
'userlogin' => 'Log masuk / buka akaun',
'userloginnocreate' => 'Log masuk',
'logout' => 'Log keluar',
'userlogout' => 'Log keluar',
'notloggedin' => 'Belum log masuk',
'userlogin-noaccount' => 'Belum buka akaun?',
'userlogin-joinproject' => 'Sertai {{SITENAME}}',
'nologin' => "Belum mempunyai akaun? '''$1'''.",
'nologinlink' => 'Buka akaun baru',
'createaccount' => 'Buka akaun',
'gotaccount' => "Sudah mempunyai akaun? '''$1'''.",
'gotaccountlink' => 'Log masuk',
'userlogin-resetlink' => 'Lupa nama pengguna/kata laluan anda?',
'userlogin-resetpassword-link' => 'Reset kata laluan anda',
'helplogin-url' => 'Help:Log masuk',
'userlogin-helplink' => '[[{{MediaWiki:helplogin-url}}|Bantuan untuk log masuk]]',
'createacct-join' => 'Isikan keterangan anda di bawah.',
'createacct-another-join' => 'Masukkan maklumat akaun baru di bawah.',
'createacct-emailrequired' => 'Alamat e-mel',
'createacct-emailoptional' => 'Alamat e-mel (pilihan)',
'createacct-email-ph' => 'Isikan alamt e-mel anda',
'createacct-another-email-ph' => 'Masukkan alamat e-mel',
'createaccountmail' => 'Gunakan kata laluan rawak yang sementara dan hantarnya ke alamat e-mel yang dinyatakan',
'createacct-realname' => 'Nama sebenar (pilihan)',
'createaccountreason' => 'Sebab:',
'createacct-reason' => 'Sebab',
'createacct-reason-ph' => 'Mengapa anda membuka satu lagi akaun',
'createacct-captcha' => 'Pemeriksaan sekuriti',
'createacct-imgcaptcha-ph' => 'Isikan teks yang anda lihat di atas',
'createacct-submit' => 'Wujudkan akaun anda',
'createacct-another-submit' => 'Buka akaun baru',
'createacct-benefit-heading' => '{{SITENAME}} dijayakan oleh orang ramai seperti anda.',
'createacct-benefit-body1' => '{{PLURAL:$1|suntingan}}',
'createacct-benefit-body2' => '{{PLURAL:$1|halaman}}',
'createacct-benefit-body3' => '{{PLURAL:$1|penyumbang}} terkini',
'badretype' => 'Sila ulangi kata laluan dengan betul.',
'userexists' => 'Nama pengguna yang diisikan telah pun digunakan.
Sila pilih nama yang lain.',
'loginerror' => 'Ralat log masuk',
'createacct-error' => 'Ralat pembukaan akaun',
'createaccounterror' => 'Tidak dapat mencipta akaun: $1',
'nocookiesnew' => 'Akaun anda telah dibuka, tetapi anda belum log masuk. {{SITENAME}} menggunakan kuki untuk mencatat status log masuk pengguna. Sila aktifkan sokongan kuki pada pelayar anda, kemudian log masuk dengan nama pengguna dan kata laluan baru anda.',
'nocookieslogin' => "{{SITENAME}} menggunakan ''cookies'' untuk mencatat status log masuk pengguna. Sila aktifkan sokongan ''cookies'' pada pelayar anda dan cuba lagi.",
'nocookiesfornew' => 'Akaun pengguna tidak dicipta kerana kami tidak dapat sahkan sumbernya.
Pastikan anda telah bolehkan kuki, muat semula laman ini dan cuba lagi.',
'nocookiesforlogin' => '{{int:nocookieslogin}}',
'noname' => 'Nama pengguna tidak sah.',
'loginsuccesstitle' => 'Berjaya log masuk',
'loginsuccess' => "'''Anda telah log masuk ke dalam {{SITENAME}} sebagai \"\$1\".'''",
'nosuchuser' => 'Pengguna "$1" tidak wujud. Nama pengguna adalah peka huruf besar. Sila semak ejaan anda, atau anda boleh [[Special:UserLogin/signup|membuka akaun baru]].',
'nosuchusershort' => 'Pengguna "$1" tidak wujud. Sila semak ejaan anda.',
'nouserspecified' => 'Sila nyatakan nama pengguna.',
'login-userblocked' => 'Pengguna ini disekat. Log masuk tidak dibenarkan.',
'wrongpassword' => 'Kata laluan yang dimasukkan adalah salah. Sila cuba lagi.',
'wrongpasswordempty' => 'Kata laluan yang dimasukkan adalah kosong. Sila cuba lagi.',
'passwordtooshort' => 'Kata laluan mestilah sekurang-kurangnya {{PLURAL:$1|1 aksara|$1 aksara}}.',
'password-name-match' => 'Kata laluan anda mesti berbeza daripada nama pengguna anda.',
'password-login-forbidden' => 'Penggunaan nama pengguna dan kata laluan ini adalah dilarang.',
'mailmypassword' => 'E-melkan kata laluan baru',
'passwordremindertitle' => 'Pengingat kata laluan daripada {{SITENAME}}',
'passwordremindertext' => 'Seseorang (mungkin anda, dari alamat IP $1) telah meminta kata laluan baru untuk {{SITENAME}} ($4). Kata laluan sementara baru untuk pengguna "$2" ialah "$3". Untuk menamatkan prosedur ini, anda perlu log masuk dan tetapkan kata laluan yang baru dengan segera. Kata laluan sementara anda akan luput dalam $5 hari.

Jika anda tidak membuat permintaan ini, atau anda telah pun mengingati semula kata laluan anda dan tidak mahu menukarnya, anda boleh mengabaikan pesanan ini dan terus menggunakan kata laluan yang sedia ada.',
'noemail' => 'Tiada alamat e-mel direkodkan bagi pengguna "$1".',
'noemailcreate' => 'Anda perlu memberikan alamat e-mel sah',
'passwordsent' => 'Kata laluan baru telah dikirim kepada alamat
e-mel yang didaftarkan oleh "$1".
Sila log masuk semula setelah anda menerima e-mel tersebut.',
'blocked-mailpassword' => 'Alamat IP anda telah disekat daripada sebarang penyuntingan, oleh itu, untuk
mengelak penyalahgunaan, anda tidak dibenarkan menggunakan ciri pemulihan kata laluan.',
'eauthentsent' => 'Sebuah e-mel pengesahan telah dikirim kepada alamat e-mel tersebut.
Sebelum e-emel lain boleh dikirim kepada alamat tersebut, anda perlu mengikuti segala arahan dalam e-mel tersebut
untuk membuktikan bahawa alamat tersebut memang milik anda.',
'throttled-mailpassword' => 'E-mel set semula kata laluan telah dihantar dalam tempoh $1 jam yang lalu.
Untuk mencegah salah guna, hanya sepucuk e-mel set semula kata laluan dihantar setiap {{PLURAL:$1|jam|$1 jam}}.',
'mailerror' => 'Ralat ketika mengirim e-mel: $1',
'acct_creation_throttle_hit' => 'Pengunjung wiki ini yang menggunakan alamat IP anda telah membuka sebanyak $1 akaun semenjak sehari lepas, iaitu merupakan had maksimum yang dibenarkan dalam tempoh tersebut.
Akibatknya, pengunjung dari alamat IP ini tidak boleh membuka akaun lagi pada masa sekarang.',
'emailauthenticated' => 'Alamat e-mel anda telah disahkan pada $2, $3.',
'emailnotauthenticated' => 'Alamat e-mel anda belum disahkan. Oleh itu,
e-mel bagi ciri-ciri berikut tidak boleh dikirim.',
'noemailprefs' => 'Anda perlu menetapkan alamat e-mel terlebih dahulu untuk menggunakan ciri-ciri ini.',
'emailconfirmlink' => 'Sahkan alamat e-mel anda.',
'invalidemailaddress' => 'Alamat e-mel tersebut tidak boleh diterima kerana ia tidak sah. Sila masukkan alamat e-mel yang betul atau kosongkan sahaja ruangan tersebut.',
'cannotchangeemail' => 'Alamat e-mel akaun tidak boleh diubah di wiki ini.',
'emaildisabled' => 'Tapak ini tidak boleh menghantar e-mel.',
'accountcreated' => 'Akaun dibuka',
'accountcreatedtext' => 'Akaun pengguna [[{{ns:User}}:$1|$1]] ([[{{ns:User talk}}:$1|bual]]) telah dibuka.',
'createaccount-title' => 'Pembukaan akaun {{SITENAME}}',
'createaccount-text' => 'Seseorang telah membuka akaun untuk
alamat e-mel anda di {{SITENAME}} ($4) dengan nama "$2" dan kata laluan "$3".
Anda boleh log masuk dan tukar kata laluan anda sekarang.

Sila abaikan mesej ini jika anda tidak meminta untuk membuka akaun tersebut.',
'usernamehasherror' => 'Nama pengguna tidak boleh memiliki aksara cincangan',
'login-throttled' => 'Anda telah mencuba log masuk berulang kali.
Sila tunggu $1 dan cuba lagi.',
'login-abort-generic' => 'Log masuk anda tidak berjaya, dan terpaksa dibatalkan',
'loginlanguagelabel' => 'Bahasa: $1',
'suspicious-userlogout' => 'Permintaan anda untuk log keluar ditolak kerana ia kelihatan seperti dihantar oleh pelayar rosak atau proksi pengagregatan.',
'createacct-another-realname-tip' => 'Nama sebenar adalah tidak wajib.
Jika anda memilih untuk menyatakannya, ini akan digunakan untuk memberikan atribusi kepada pengguna atas sumbangan mereka.',

# Email sending
'php-mail-error-unknown' => 'Ralat tak diketahui dalam fungsi mail() PHP',
'user-mail-no-addy' => 'E-eml cuba dihantar tanpa alamat e-mel',
'user-mail-no-body' => 'Anda telah cuba menghantar e-mel dengan isi yang kosong atau terlampau ringkas.',

# Change password dialog
'resetpass' => 'Tukar kata laluan',
'resetpass_announce' => 'Anda sedang log masuk dengan kata laluan sementara. Untuk log masuk dengan sempurna, sila tetapkan kata laluan baru di sini:',
'resetpass_text' => '<!-- Tambah teks di sini -->',
'resetpass_header' => 'Tukar kata laluan',
'oldpassword' => 'Kata laluan lama:',
'newpassword' => 'Kata laluan baru:',
'retypenew' => 'Ulangi kata laluan baru:',
'resetpass_submit' => 'Tetapkan kata laluan dan log masuk',
'changepassword-success' => 'Kata laluan anda berjaya ditukar!',
'resetpass_forbidden' => 'Kata laluan tidak boleh ditukar',
'resetpass-no-info' => 'Anda hendaklah log masuk terlebih dahulu untuk mencapai laman ini secara terus.',
'resetpass-submit-loggedin' => 'Tukar kata laluan',
'resetpass-submit-cancel' => 'Batalkan',
'resetpass-wrong-oldpass' => 'Kata laluan sementara atau semasa tidak sah.
Anda mungkin telah pun berjaya menukar kata laluan anda atau meminta kata laluan sementara yang baru.',
'resetpass-temp-password' => 'Kata laluan sementara:',
'resetpass-abort-generic' => 'Penukaran kata laluan telah dihenti paksa oleh sambungan.',

# Special:PasswordReset
'passwordreset' => 'Set semula kata laluan',
'passwordreset-text-one' => 'Lengkapkan borang ini untuk mengeset semula kata laluan anda.',
'passwordreset-text-many' => '{{PLURAL:$1|Isi salah satu ruangan untuk mengeset semula kata laluan anda.}}',
'passwordreset-legend' => 'Set semula kata laluan',
'passwordreset-disabled' => 'Ciri set semula kata laluan telah dimatikan di wiki ini.',
'passwordreset-emaildisabled' => 'Ciri-ciri e-mel telah dipadamkan di wiki ini.',
'passwordreset-username' => 'Nama pengguna:',
'passwordreset-domain' => 'Domain:',
'passwordreset-capture' => 'Lihat e-mel yang terhasil?',
'passwordreset-capture-help' => 'Jika anda menandai ruang ini, e-mel (yang membawa kata laluan sementara) akan ditunjukkan kepada anda dan juga dihantar kepada pengguna itu.',
'passwordreset-email' => 'Alamat e-mel:',
'passwordreset-emailtitle' => 'Butiran akaun di {{SITENAME}}',
'passwordreset-emailtext-ip' => 'Seseorang (mungkin anda, dari alamat IP $1) telah memohon supaya kata laluan diset semula untuk {{SITENAME}} anda ($4). {{PLURAL:$3|Akaun|Akaun-akaun}} pengguna yang berikut
dikaitkan dengan alamat e-mel ini:

$2

{{PLURAL:$3|Kata|Kata-kata}} laluan sementara ini akan luput dalam masa $5 hari. Anda harus log masuk dan membuat kata laluan yang baru sekarang. Jika permohonan ini dibuat oleh orang lain, atau jika anda teringat kembali kata laluan asal anda dan anda tidak lagi berhasrat untuk mengubahnya, anda boleh mengabaikan pesanan ini dan terus menggunakan kata laluan lama anda.',
'passwordreset-emailtext-user' => 'Pengguna $1 telah memohon supaya kata laluan diset semula untuk {{SITENAME}} anda ($4). {{PLURAL:$3|Akaun|Akaun-akaun}} pengguna yang berikut
dikaitkan dengan alamat e-mel ini:

$2

{{PLURAL:$3|Kata|Kata-kata}} laluan sementara ini akan luput dalam masa $5 hari. Anda harus log masuk dan membuat kata laluan yang baru sekarang. Jika permohonan ini dibuat oleh orang lain, atau jika anda teringat kembali kata laluan asal anda dan anda tidak lagi berhasrat untuk mengubahnya, anda boleh mengabaikan pesanan ini dan terus menggunakan kata laluan lama anda.',
'passwordreset-emailelement' => 'Nama pengguna: $1
Kata laluan sementara: $2',
'passwordreset-emailsent' => 'E-mel set semula kata laluan telah dihantar.',
'passwordreset-emailsent-capture' => 'E-mel set semula kata laluan telah dihantar, seperti yang dipaparkan di bawah.',
'passwordreset-emailerror-capture' => 'E-mel set semula kata laluan telah dihasilkan, seperti yang dipaparkan di bawah, tetapi tidak berjaya dihantar kepada {{GENDER:$2|pengguna}} berkenaan: $1',

# Special:ChangeEmail
'changeemail' => 'Tukar alamat e-mel',
'changeemail-header' => 'Tukar alamat e-mel akaun',
'changeemail-text' => 'Lengkapkan borang ini untuk menukar alamat e-mel anda. Anda akan perlu mengisikan kata laluan untuk mengesahkan perubahan ini.',
'changeemail-no-info' => 'Anda hendaklah log masuk terlebih dahulu untuk mencapai laman ini secara terus.',
'changeemail-oldemail' => 'Alamat e-mel sekarang:',
'changeemail-newemail' => 'Alamat e-mel baru:',
'changeemail-none' => '(tiada)',
'changeemail-password' => 'Kata laluan anda di {{SITENAME}}:',
'changeemail-submit' => 'Tukar E-mel',
'changeemail-cancel' => 'Batalkan',

# Special:ResetTokens
'resettokens' => 'Set semula token',
'resettokens-text' => 'Anda boleh mengeset semula token yang membolehkan akses kepada data peribadi tertentu yang berkaitan dengan akaun anda di sini.

Anda harus melakukannya jika anda tanpa sengaja mengongsinya dengan sesiapa ataupun akaun anda telah dikompromi.',
'resettokens-no-tokens' => 'Tiada token untuk diset semula.',
'resettokens-legend' => 'Set semula token',
'resettokens-tokens' => 'Token:',
'resettokens-token-label' => '$1 (nilai semasa: $2)',
'resettokens-watchlist-token' => 'Token untuk suapan sesawang (Atom/RSS) bagi [[Special:Watchlist|perubahan pada halaman dalam senarai pantau anda]]',
'resettokens-done' => 'Token diset semula.',
'resettokens-resetbutton' => 'Set semula token terpilih',

# Edit page toolbar
'bold_sample' => 'Teks tebal',
'bold_tip' => 'Teks tebal',
'italic_sample' => 'Teks condong',
'italic_tip' => 'Teks condong',
'link_sample' => 'Tajuk pautan',
'link_tip' => 'Pautan dalaman',
'extlink_sample' => 'http://www.example.com tajuk pautan',
'extlink_tip' => 'Pautan luar (ingat awalan http://)',
'headline_sample' => 'Teks tajuk',
'headline_tip' => 'Tajuk peringkat 2',
'nowiki_sample' => 'Masukkan teks tak berformat di sini',
'nowiki_tip' => 'Abaikan pemformatan wiki',
'image_sample' => 'Contoh.jpg',
'image_tip' => 'Imej terbenam',
'media_sample' => 'Contoh.ogg',
'media_tip' => 'Pautan fail media',
'sig_tip' => 'Tandatangan dengan cap waktu',
'hr_tip' => 'Garis melintang (gunakan dengan hemat)',

# Edit pages
'summary' => 'Ringkasan:',
'subject' => 'Tajuk:',
'minoredit' => 'Ini adalah suntingan kecil',
'watchthis' => 'Pantau laman ini',
'savearticle' => 'Simpan',
'preview' => 'Pralihat',
'showpreview' => 'Paparkan pralihat',
'showlivepreview' => 'Pralihat langsung',
'showdiff' => 'Lihat perubahan',
'anoneditwarning' => "'''Amaran:''' Anda tidak log masuk. Alamat IP anda akan direkodkan dalam sejarah suntingan laman ini.",
'anonpreviewwarning' => "''Anda belum log masuk. Jika anda menyimpan laman ini, alamat IP anda akan direkodkan dalam sejarah penyuntingan laman ini.''",
'missingsummary' => "'''Peringatan:''' Anda tidak menyatakan ringkasan suntingan. Klik '''Simpan''' sekali lagi untuk menyimpan suntingan ini tanpa ringkasan.",
'missingcommenttext' => 'Sila masukkan komen dalam ruangan di bawah.',
'missingcommentheader' => "'''Peringatan:''' Anda tidak menyatakan tajuk bagi komen ini. Klik '''{{int:savearticle}}''' sekali lagi untuk menyimpan suntingan ini tanpa tajuk.",
'summary-preview' => 'Pralihat ringkasan:',
'subject-preview' => 'Pralihat tajuk:',
'blockedtitle' => 'Pengguna disekat',
'blockedtext' => '\'\'\'Nama pengguna atau alamat IP anda telah disekat.\'\'\'

Sekatan ini dilakukan oleh $1 dengan sebab \'\'$2\'\'.

* Mula: $8
* Tamat: $6
* Pengguna sasaran: $7

Sila hubungi $1 atau [[{{MediaWiki:Grouppage-sysop}}|pentadbir]] yang lain untuk untuk berunding mengenai sekatan ini.

Anda tidak boleh menggunakan ciri "e-melkan pengguna ini" kecuali sekiranya anda telah menetapkan alamat e-mel yang sah dalam [[Special:Preferences|keutamaan]] anda dan anda tidak disekat daripada menggunakannya.

Alamat IP semasa anda ialah $3, dan ID sekatan ialah #$5. Sila sertakan maklumat-maklumat ini dalam pertanyaan nanti.',
'autoblockedtext' => 'Alamat IP anda telah disekat secara automatik kerana ia digunakan oleh pengguna lain yang disekat oleh $1.
Yang berikut ialah sebab yang dinyatakan:

:\'\'$2\'\'

* Mula: $8
* Tamat: $6
* Pengguna sasaran: $7

Anda boleh menghubungi $1 atau [[{{MediaWiki:Grouppage-sysop}}|pentadbir]] lain untuk berunding mengenai sekatan ini.

Sila ambil perhatian bahawa anda tidak boleh menggunakan ciri "e-melkan pengguna ini" kecuali sekiranya anda telah menetapkan alamat e-mel yang sah dalam [[Special:Preferences|laman keutamaan]] anda dan anda tidak disekat daripada menggunakannya.

Alamat IP semasa anda ialah $3, dan ID sekatan ialah #$5. Sila sertakan maklumat-maklumat ini dalam pertanyaan nanti.',
'blockednoreason' => 'tiada sebab diberikan',
'whitelistedittext' => 'Anda hendaklah $1 terlebih dahulu untuk menyunting laman.',
'confirmedittext' => 'Anda perlu mengesahkan alamat e-mel anda terlebih dahulu untuk menyunting mana-mana laman. Sila tetapkan dan sahkan alamat e-mel anda melalui [[Special:Preferences|laman keutamaan]].',
'nosuchsectiontitle' => 'Tidak ada bahagian ini',
'nosuchsectiontext' => 'Anda cuba untuk menyunting bahagian yang tidak wujud.
Ia mungkin telah dialih atau dihapus semasa anda melihat laman ini.',
'loginreqtitle' => 'Log masuk diperlukan',
'loginreqlink' => 'log masuk',
'loginreqpagetext' => 'Anda harus $1 untuk dapat melihat laman yang lain.',
'accmailtitle' => 'Kata laluan dikirim.',
'accmailtext' => "Kata laluan janaan rawak untuk [[User talk:$1|$1]] telah dikirim kepada $2. Anda boleh menukarnya di halaman ''[[Special:ChangePassword|tukar kata laluan]]'' sebaik sahaja log masuk.",
'newarticle' => '(Baru)',
'newarticletext' => "Anda telah mengikuti pautan ke laman yang belum wujud.
Untuk mencipta laman ini, sila taip dalam kotak di bawah
(lihat [[{{MediaWiki:Helppage}}|laman bantuan]] untuk maklumat lanjut).
Jika anda tiba di sini secara tak sengaja, hanya klik butang '''back''' pada pelayar anda.",
'anontalkpagetext' => "----''Ini ialah laman perbincangan bagi pengguna tanpa nama yang belum membuka akaun atau tidak log masuk.
Oleh itu kami terpaksa menggunakan alamat IP untuk mengenal pasti pengguna tersebut. Alamat IP ini boleh dikongsi oleh ramai pengguna.
Sekiranya anda adalah seorang pengguna tanpa nama dan berasa bahawa komen yang tidak kena mengena telah ditujukan kepada anda, sila [[Special:UserLogin/signup|buka akaun baru]] atau [[Special:UserLogin|log masuk]] untuk mengelakkan sebarang kekeliruan dengan pengguna tanpa nama yang lain.''",
'noarticletext' => 'Tiada teks dalam laman ini pada masa sekarang. Anda boleh [[Special:Search/{{PAGENAME}}|mencari tajuk bagi laman ini]] dalam laman-laman lain, <span class="plainlinks">[{{fullurl:{{#Special:Log}}|page={{FULLPAGENAMEE}}}} mencari log-log yang berkaitan], atau [{{fullurl:{{FULLPAGENAME}}|action=edit}} menyunting laman ini]</span>.',
'noarticletext-nopermission' => 'Tiada teks dalam laman ini ketika ini.
Anda boleh [[Special:Search/{{PAGENAME}}|mencari tajuk laman ini]] dalam laman lain,
atau <span class="plainlinks">[{{fullurl:{{#Special:Log}}|page={{FULLPAGENAMEE}}}} mencari log yang berkaitan]</span>.',
'missing-revision' => 'Semakan #$1 pada halaman "{{PAGENAME}}" tidak wujud.

Hal ini biasanya disebabkan oleh pautan sejarah yang lapuk ke halaman yang sudah dihapuskan.
Butirannya boleh didapati di [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} log penghapusan].',
'userpage-userdoesnotexist' => 'Akaun pengguna "<nowiki>$1</nowiki>" tidak berdaftar. Sila pastikan sama ada anda mahu mencipta/menyunting laman ini.',
'userpage-userdoesnotexist-view' => 'Akaun pengguna "$1" tidak berdaftar.',
'blocked-notice-logextract' => 'Pengguna ini sedang disekat.
Masukan log sekatan terakhir disediakan di bawah sebagai rujukan:',
'clearyourcache' => "'''Catatan:''' Selepas menyimpan laman ini, anda mungkin perlu membersihkan cache pelayar web anda terlebih dahulu untuk mengenakan perubahan.
*'''Firefox/Safari:''' Tekan terus ''Shift'' sambil klik ''Reload'', atau tekan ''Ctrl+F5'' atau tekan ''Ctrl+R''  (''⌘+R'' bagi Mac)
*'''Google Chrome:''' Tekan ''Ctrl+Shift+R''  (''⌘+Shift+R'' bagi Mac)
*'''Internet Explorer:''' Tekan terus ''Ctrl'' sambil klik ''Refresh'', atau tekan ''Ctrl+F5''
*'''Opera:''' Kosongkan cache di menu ''Tools → Preferences''",
'usercssyoucanpreview' => "'''Petua:''' Gunakan butang \"{{int:showpreview}}\" untuk menguji CSS baru anda sebelum menyimpan.",
'userjsyoucanpreview' => "'''Petua:''' Gunakan butang \"{{int:showpreview}}\" untuk menguji JavaScript baru anda sebelum menyimpan.",
'usercsspreview' => "'''Ingat bahawa anda hanya sedang melihat pralihat CSS peribadi anda. Laman ini belum lagi disimpan!'''",
'userjspreview' => "'''Ingat bahawa anda hanya menguji/melihat pralihat JavaScript anda, ia belum lagi disimpan!'''",
'sitecsspreview' => "'''Ingat bahawa anda cuma melihat pralihat CSS ini.'''
'''Ia belum lagi disimpan!'''",
'sitejspreview' => "'''Ingat bahawa anda cuma mempralihat kod JavaScript ini.'''
'''Ia belum lagi disimpan!'''",
'userinvalidcssjstitle' => "'''Amaran:''' Rupa \"\$1\" tidak wujud. Ingat bahawa laman tempahan .css dan .js menggunakan tajuk berhuruf kecil, contohnya {{ns:user}}:Anu/vector.css tidak sama dengan {{ns:user}}:Anu/Vector.css.",
'updated' => '(Dikemas kini)',
'note' => "'''Catatan:'''",
'previewnote' => "'''Ingatlah bahawa ini hanya pralihat.'''
Perubahan anda belum disimpan!",
'continue-editing' => 'Pergi ke tempat menyunting',
'previewconflict' => 'Paparan ini merupakan teks di bahagian atas dalam kotak sunting teks. Teks ini akan disimpan sekiranya anda memilih berbuat demikian.',
'session_fail_preview' => "'''Kami tidak dapat memproses suntingan anda kerana kehilangan data sesi. Sila cuba lagi. Jika masalah ini berlanjutan, [[Special:UserLogout|log keluar]] dahulu, kemudian log masuk sekali lagi.'''",
'session_fail_preview_html' => "'''Kami tidak dapat memproses suntingan anda kerana kehilangan data sesi.'''

''Oleh sebab {{SITENAME}} membenarkan HTML mentah, ciri pralihat terpaksa disorokkan sebagai perlindungan daripada serangan JavaScript.''

'''Jika ini ialah penyuntingan yang sah, sila cuba lagi. Jika masalah ini berlanjutan, [[Special:UserLogout|log keluar]] dahulu, kemudian log masuk sekali lagi.'''",
'token_suffix_mismatch' => "'''Suntingan anda telah ditolak kerana pelanggan anda memusnahkan aksara tanda baca
dalam token suntingan. Suntingan tersebut telah ditolak untuk menghalang kerosakan teks laman.
Hal ini kadangkala berlaku apabila anda menggunakan khidmat proksi tanpa nama berdasarkan web yang bermasalah.'''",
'edit_form_incomplete' => "'''Beberapa bahagian dari bentuk edit tidak mencapai pelayan, periksa bahawa suntingan anda utuh dan cuba lagi'.'''",
'editing' => 'Menyunting $1',
'creating' => 'Membuat $1',
'editingsection' => 'Menyunting $1 (bahagian)',
'editingcomment' => 'Menyunting $1 (bahagian baru)',
'editconflict' => 'Percanggahan penyuntingan: $1',
'explainconflict' => "Pengguna lain telah menyunting laman ini ketika anda sedang menyuntingnya.
Kawasan teks di atas mengandungi teks semasa.
Perubahan anda dipaparkan dalam kawasan teks di bawah.
Anda perlu menggabungkan perubahan anda dengan teks semasa.
'''Hanya''' teks dalam kawasan teks di atas akan disimpan jika anda menekan \"{{int:savearticle}}\".",
'yourtext' => 'Teks anda',
'storedversion' => 'Versi yang disimpan',
'nonunicodebrowser' => "'''AMARAN: Pelayar anda tidak mematuhi Unicode. Aksara-aksara bukan ASCII akan dipaparkan dalam kotak sunting sebagai kod perenambelasan.'''",
'editingold' => "'''AMARAN: Anda sedang
menyunting sebuah semakan yang sudah ketinggalan zaman.
Jika anda menyimpannya, sebarang perubahan yang dibuat selepas tarikh semakan ini akan hilang.'''",
'yourdiff' => 'Perbezaan',
'copyrightwarning' => "Sila ambil perhatian bahawa semua sumbangan kepada {{SITENAME}} akan dikeluarkan di bawah $2 (lihat $1 untuk butiran lanjut). Jika anda tidak mahu tulisan anda disunting sewenang-wenangnya oleh orang lain dan diedarkan secara bebas, maka jangan kirim di sini.<br />
Anda juga berjanji bahawa ini adalah hasil kerja tangan anda sendiri, atau disalin daripada domain awam atau mana-mana sumber bebas lain.
'''JANGAN KIRIM KARYA HAK CIPTA ORANG LAIN TANPA KEBENARAN!'''",
'copyrightwarning2' => "Sila ambil perhatian bahawa semua sumbangan terhadap {{SITENAME}} boleh disunting, diubah, atau dipadam oleh penyumbang lain. Jika anda tidak mahu tulisan anda disunting sewenang-wenangnya, maka jangan kirim di sini.<br />
Anda juga berjanji bahawa ini adalah hasil kerja tangan anda sendiri, atau
disalin daripada domain awam atau mana-mana sumber bebas lain (lihat $1 untuk butiran lanjut).
'''JANGAN KIRIM KARYA HAK CIPTA ORANG LAIN TANPA KEBENARAN!'''",
'longpageerror' => "'''Ralat: Teks yang anda serahkan itu panjangnya {{PLURAL:$1|1|$1}} kilobait, iaitu lebih panjang daripada had maksimum {{PLURAL:$2|1|$2}} kilobait.'''
Oleh itu, ia tidak boleh disimpan.",
'readonlywarning' => "'''Amaran: Pangkalan data ini dikunci untuk tujuan penyelenggaraan , maka anda tidak akan dapat menyimpan suntingan anda buat sekarang.'''
Anda boleh menyalin tampal teks anda pada fail teks dan menyimpannya untuk lain kali.

Penyelia yang menguncinya memberikan penjelasan ini: $1",
'protectedpagewarning' => "'''Amaran: Laman ini telah dikunci supaya hanya mereka yang mempunyai keistimewaan penyelia boleh menyuntingnya.'''
Masukan log terakhir ditunjukkan di bawah untuk rujukan:",
'semiprotectedpagewarning' => "'''Nota:''' Laman ini telah dikunci agar hanya pengguna berdaftar sahaja boleh menyuntingnya.
Masukan log terakhir ditunjukkan di bawah untuk rujukan:",
'cascadeprotectedwarning' => "'''Amaran:''' Laman ini telah dikunci, oleh itu hanya penyelia boleh menyuntingnya. Ini kerana ia termasuk dalam {{PLURAL:$1|laman|laman-laman}} berikut yang dilindungi secara melata:",
'titleprotectedwarning' => "'''Amaran: Laman ini telah dikunci hingga [[Special:ListGroupRights|hak-hak tertentu]] diperlukan untuk menciptanya.'''
Masukan log terakhir ditunjukkan di bawah untuk rujukan:",
'templatesused' => '{{PLURAL:$1|Templat|Templat}} yang digunakan dalam laman ini:',
'templatesusedpreview' => '{{PLURAL:$1|Templat|Templat}} yang digunakan dalam pralihat ini:',
'templatesusedsection' => '{{PLURAL:$1|Templat|Templat}} digunakan dalam bahagian ini:',
'template-protected' => '(dilindungi)',
'template-semiprotected' => '(dilindungi separa)',
'hiddencategories' => 'Laman ini terdapat dalam $1 kategori tersembunyi:',
'edittools' => '<!-- Teks di sini akan ditunjukkan bawah borang sunting dan muat naik. -->',
'edittools-upload' => '-',
'nocreatetext' => 'Penciptaan laman baru dihadkan pada {{SITENAME}}.
Anda boleh berundur dan menyunting laman yang sedia ada, atau [[Special:UserLogin|log masuk]].',
'nocreate-loggedin' => 'Anda tidak mempunyai keizinan untuk mencipta laman baru.',
'sectioneditnotsupported-title' => 'Suntingan bahagian tidak disokong',
'sectioneditnotsupported-text' => 'Suntingan bahagian tidak disokong di laman ini.',
'permissionserrors' => 'Ralat kebenaran',
'permissionserrorstext' => 'Anda tidak mempunyai keizinan untuk berbuat demikian atas {{PLURAL:$1|sebab|sebab-sebab}} berikut:',
'permissionserrorstext-withaction' => 'Anda tidak mempunyai keizinan untuk $2, atas {{PLURAL:$1|sebab|sebab-sebab}} berikut:',
'recreate-moveddeleted-warn' => "'''Amaran: Anda sedang mencipta semula sebuah laman yang pernah dihapuskan.'''

Anda harus mempertimbangkan perlunya menyunting laman ini.
Untuk rujukan, yang berikut ialah log penghapusan bagi laman ini:",
'moveddeleted-notice' => 'Laman ini telah dihapuskan.
Log penghapusan bagi laman ini dilampirkan di bawah untuk rujukan.',
'log-fulllog' => 'Lihat log lengkap',
'edit-hook-aborted' => 'Suntingan anda telah dibatalkan oleh penyangkuk. Tiada sebab diberikan.',
'edit-gone-missing' => 'Laman tersebut telah dihapuskan dan tidak dapat dikemaskinikan.',
'edit-conflict' => 'Percanggahan penyuntingan.',
'edit-no-change' => 'Suntingan anda diabaikan kerana tiada perubahan dibuat pada teks tersebut.',
'postedit-confirmation' => 'Suntingan anda telah disimpan.',
'edit-already-exists' => 'Tidak dapat mencipta laman baru kerana ia telah wujud.',
'defaultmessagetext' => 'Teks mesej asal',
'content-failed-to-parse' => 'Kandungan $2 tidak dapat dihuraikan untuk model $1: $3',
'invalid-content-data' => 'Data kandungan tidak sah',
'content-not-allowed-here' => 'Kandungan "$1" tidak dibenarkan di halaman [[$2]]',
'editwarning-warning' => 'Meninggalkan laman ini mungkin akan menyebabkan sebarang perubahan yang telah anda lakukan hilang.
Jika anda sudah log masuk, anda boleh melumpuhkan amaran ini di bahagian "Menyunting" dalam keutamaan anda.',

# Content models
'content-model-wikitext' => 'wikiteks',
'content-model-text' => 'teks biasa',
'content-model-javascript' => 'JavaScript',
'content-model-css' => 'CSS',

# Parser/template warnings
'expensive-parserfunction-warning' => 'Amaran: Laman ini mengandungi terlalu banyak panggilan fungsi penghurai yang intensif.

Had panggilan ialah $2, sekarang terdapat $1 panggilan.',
'expensive-parserfunction-category' => 'Laman yang mengandungi terlalu banyak panggilan fungsi penghurai yang intensif',
'post-expand-template-inclusion-warning' => 'Amaran: Saiz penyertaan templat terlalu besar.
Sesetengah templat tidak akan disertakan.',
'post-expand-template-inclusion-category' => 'Laman-laman yang melebihi had saiz penyertaan templat',
'post-expand-template-argument-warning' => 'Amaran: Laman ini mengandungi sekurang-kurangnya satu argumen templat yang mempunyai saiz pengembangan yang terlalu besar.
Argumen-argumen ini telah ditinggalkan.',
'post-expand-template-argument-category' => 'Laman yang mengandungi templat dengan argumen yang tidak lengkap',
'parser-template-loop-warning' => 'Gelung templat dikesan: [[$1]]',
'parser-template-recursion-depth-warning' => 'Had pengulangan templat dilebihi ($1)',
'language-converter-depth-warning' => 'Had kedalaman penukar bahasa dilepasi ($1)',
'node-count-exceeded-category' => 'Laman yang melebihi had kiraan nod',
'node-count-exceeded-warning' => 'Laman terlebih kiraan nod',
'expansion-depth-exceeded-category' => 'Laman yang melebihi had kedalaman peluasan',
'expansion-depth-exceeded-warning' => 'Laman terlebih dalam peluasan',
'parser-unstrip-loop-warning' => 'Gelung unstrip dikesan',
'parser-unstrip-recursion-limit' => 'Had rekursi unstrip dilampaui ($1)',
'converter-manual-rule-error' => 'Ralat dikesan dalam aturan penukaran bahasa manual',

# "Undo" feature
'undo-success' => 'Suntingan ini boleh dibatalkan. Sila semak perbandingan di bawah untuk mengesahkan bahawa anda betul-betul mahu melakukan tindakan ini, kemudian simpan perubahan tersebut.',
'undo-failure' => 'Suntingan tersebut tidak boleh dibatalkan kerana terdapat suntingan pertengahan yang bercanggah.',
'undo-norev' => 'Suntingan tersebut tidak boleh dibatalkan kerana tidak wujud atau telah dihapuskan.',
'undo-summary' => 'Membatalkan semakan $1 oleh [[Special:Contributions/$2|$2]] ([[User talk:$2|Perbincangan]])',
'undo-summary-username-hidden' => 'Buat asal semakan $1 oleh pengguna tersembunyi',

# Account creation failure
'cantcreateaccounttitle' => 'Akaun tidak dapat dibuka',
'cantcreateaccount-text' => "Pembukaan akaun daripada alamat IP ini (<b>$1</b>) telah disekat oleh [[User:$3|$3]].

Sebab yang diberikan oleh $3 ialah ''$2''",

# History pages
'viewpagelogs' => 'Lihat log bagi laman ini',
'nohistory' => 'Tiada sejarah suntingan bagi laman ini.',
'currentrev' => 'Semakan semasa',
'currentrev-asof' => 'Semakan semasa pada $1',
'revisionasof' => 'Semakan pada $1',
'revision-info' => 'Semakan pada $1 oleh $2',
'previousrevision' => '←Semakan sebelumnya',
'nextrevision' => 'Semakan berikutnya→',
'currentrevisionlink' => 'Semakan semasa',
'cur' => 'kini',
'next' => 'berikutnya',
'last' => 'akhir',
'page_first' => 'awal',
'page_last' => 'akhir',
'histlegend' => "Pemilihan perbezaan: tandakan butang radio bagi versi-versi yang ingin dibandingkan dan tekan butang ''enter'' atau butang di bawah.<br />
Petunjuk: (kini) = perbezaan dengan versi terkini,
(akhir) = perbezaan dengan versi sebelumnya, K = suntingan kecil.",
'history-fieldset-title' => 'Lihat sejarah',
'history-show-deleted' => 'Dihapuskan sahaja',
'histfirst' => 'terawal',
'histlast' => 'terkini',
'historysize' => '($1 bait)',
'historyempty' => '(kosong)',

# Revision feed
'history-feed-title' => 'Sejarah semakan',
'history-feed-description' => 'Sejarah semakan bagi laman ini',
'history-feed-item-nocomment' => '$1 pada $2',
'history-feed-empty' => 'Laman yang diminta tidak wujud.
Mungkin ia telah dihapuskan atau namanya telah ditukar.
Cuba [[Special:Search|cari]] laman lain yang mungkin berkaitan.',

# Revision deletion
'rev-deleted-comment' => '(ringkasan suntingan dibuang)',
'rev-deleted-user' => '(nama pengguna dibuang)',
'rev-deleted-event' => '(entri dibuang)',
'rev-deleted-user-contribs' => '[nama pengguna atau alamat IP dibuang - suntingan disembunyikan daripada sumbangan]',
'rev-deleted-text-permission' => "Semakan laman ini telah '''dihapuskan'''.
Perinciannya mungkin ada di dalam [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} log penghapusan].",
'rev-deleted-text-unhide' => "Semakan laman ini telah '''dihapuskan'''.
Butiran lanjut boleh didapati dalam [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} log penghapusan].
Anda masih boleh [$1 melihat semakan ini] jika anda ingin teruskan.",
'rev-suppressed-text-unhide' => "Semakan laman ini telah '''diselindungkan'''.
Butiran lanjut boleh didapati dalam [{{fullurl:{{#Special:Log}}/suppress|page={{FULLPAGENAMEE}}}} log penyelindungan].
Anda masih boleh [$1 melihat semakan ini] jika anda ingin.",
'rev-deleted-text-view' => "Semakan laman ini telah '''dihapuskan'''.
Anda boleh melihatnya; butiran lanjut boleh didapati dalam [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} log penghapusan].",
'rev-suppressed-text-view' => "Semakan bagi laman ini telah '''diselindungkan'''.
Anda boleh melihatnya; butiran lanjut boleh didapati di [{{fullurl:{{#Special:Log}}/suppress|page={{FULLPAGENAMEE}}}} log penyelindungan].",
'rev-deleted-no-diff' => "Anda tidak boleh melihat perbezaan ini kerana salah satu daripada semakannya telah '''dihapuskan'''.
Mungkin terdapat butiran lanjut di dalam [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} log penghapusan].",
'rev-suppressed-no-diff' => "Anda tidak boleh melihat perbezaan ini kerana salah satu semakannya telah '''dihapuskan'''.",
'rev-deleted-unhide-diff' => "Salah satu semakan perbezaan ini telah '''dihapuskan'''.
Butiran lanjut boleh didapati dalam [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} log penghapusan].
Anda masih boleh [$1 melihat semakan ini] jika anda ingin teruskan.",
'rev-suppressed-unhide-diff' => "Salah satu semakan perbezaan ini telah '''diselindungkan'''.
Butiran lanjut boleh didapati dalam [{{fullurl:{{#Special:Log}}/suppress|page={{FULLPAGENAMEE}}}} log penyelindungan].
Anda masih boleh [$1 melihat perbezaan ini] jika anda ingin teruskan.",
'rev-deleted-diff-view' => "Salah satu semakan perbezaan ini telah '''dihapuskan'''.
Sebagai pentadbir anda boleh melihat perbezaan ini; butiran boleh didapati di [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} log penghapusan].",
'rev-suppressed-diff-view' => "Salah satu semakan perbezaan ini telah '''dipendam'''.
Anda boleh melihat perbezaan ini; butiran boleh didapati di [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} log penyelindungan].",
'rev-delundel' => 'tunjukkan/sorokkan',
'rev-showdeleted' => 'tunjukkan',
'revisiondelete' => 'Hapus/nyahhapus semakan',
'revdelete-nooldid-title' => 'Tiada semakan sasaran',
'revdelete-nooldid-text' => 'Anda tidak menyatakan semakan sasaran.',
'revdelete-nologtype-title' => 'Jenis log tidak diberi',
'revdelete-nologtype-text' => 'Anda tidak menyatakan jenis log untuk tindakan ini.',
'revdelete-nologid-title' => 'Entri log tidak sah',
'revdelete-nologid-text' => 'Anda tidak menyatakan peristiwa log sasaran perkara untuk melakukan fungsi ini atau entri ynag dinyatakan tidak wujud.',
'revdelete-no-file' => 'Fail yang dinyatakan tidak wujud.',
'revdelete-show-file-confirm' => 'Anda pasti anda mahu paparkan semakan yang telah dihapuskan bagi fail "<nowiki>$1</nowiki>" dari $2 pada $3?',
'revdelete-show-file-submit' => 'Ya',
'revdelete-selected' => "'''{{PLURAL:$2|Versi|Versi-versi}} '''$1''' yang dipilih:'''",
'logdelete-selected' => "'''{{PLURAL:$1|Peristiwa|Peristiwa-peristiwa}} log yang dipilih:'''",
'revdelete-text' => "'''Semakan dan peristiwa yang dihapuskan akan tetap muncul dalam sejarah laman dan log, tetapi kandungannya tidak boleh diakses awam.'''
Pentadbir {{SITENAME}} boleh melihat kandungan tersebut dan menyahhapuskannya semula melalui laman ini melainkan mempunyai batasan.",
'revdelete-confirm' => 'Sila sahkan bahawa anda bertujuan melakukan ini, bahawa anda faham akibatnya, dan anda melakukannya menurut [[{{MediaWiki:Policy-url}}| polisi]].',
'revdelete-suppress-text' => "Pembatasan ini '''hanya''' untuk digunakan dalam kes-kes berikut:
* Maklumat peribadi tidak sesuai
*: ''alamat rumah dan nombor telefon, nombor keselamatan sosial, dsbg.''",
'revdelete-legend' => 'Tetapkan batasan:',
'revdelete-hide-text' => 'Sembunyikan teks semakan',
'revdelete-hide-image' => 'Sembunyikan kandungan fail',
'revdelete-hide-name' => 'Sembunyikan tindakan dan sasaran',
'revdelete-hide-comment' => 'Sembunyikan komen suntingan',
'revdelete-hide-user' => 'Sembunyikan nama pengguna/IP penyunting',
'revdelete-hide-restricted' => 'Sekat data daripada penyelia dan pengguna lain',
'revdelete-radio-same' => '(jangan tukar)',
'revdelete-radio-set' => 'Ya',
'revdelete-radio-unset' => 'Tidak',
'revdelete-suppress' => 'Sekat data daripada semua pengguna, termasuk penyelia',
'revdelete-unsuppress' => 'Buang batasan pada semakan yang dipulihkan',
'revdelete-log' => 'Sebab:',
'revdelete-submit' => 'Kenakan ke atas {{PLURAL:$1|versi|versi}} yang dipilih',
'revdelete-success' => "'''Kebolehnampakan semakan berjaya ditetapkan.'''",
'revdelete-failure' => "'''Keterlihatan semakan tidak dapat dikemaskini:'''
$1",
'logdelete-success' => 'Kebolehnampakan peristiwa ditetapkan.',
'logdelete-failure' => "'''Log nampak tidak dapat diset:'''
$1",
'revdel-restore' => 'Tukar kebolehnampakan',
'revdel-restore-deleted' => 'semakan dihapuskan',
'revdel-restore-visible' => 'semakan nampak',
'pagehist' => 'Sejarah laman',
'deletedhist' => 'Sejarah yang dihapuskan',
'revdelete-hide-current' => 'Ralat menyembunyikan item bertarikh $2, $1: ini adalah versi semasa.
Ia tidak dapat disembunyikan.',
'revdelete-show-no-access' => 'Ralat menunjukkan item bertarikh $2, $1: item ini telah ditanda "larangan".
Anda tidak memiliki capaian padanya.',
'revdelete-modify-no-access' => 'Ralat menyunting item bertarikh $2, $1: item ini telah ditanda "larangan".
Anda tidak memiliki capaian padanya.',
'revdelete-modify-missing' => 'Ralat menyunting item ID $1: ia tiada dalam pangkalan data!',
'revdelete-no-change' => "'''Amaran:''' item bertarikh $2, $1 telah mempunyai aturan penglihatan yang diminta.",
'revdelete-concurrent-change' => 'Ralat ketika mengubahsuai item bertarikh $2, $1: kelihatan statusnya telah diubah oleh orang lain ketika anda cuba untuk mengubahsuainya.
Mohon semak log.',
'revdelete-only-restricted' => 'Ralat menyembunyikan item bertarikh $2, $1: anda tidak boleh menyekat item-item dari pandangan pentadbir-pentadbir tanpa memilih juga salah satu pilihan pandangan lain.',
'revdelete-reason-dropdown' => '*Sebab penghapusan yang biasa
** Pencabulan hak cipta
** Ulasan atau maklumat peribadi tidak sesuai
** Nama pengguna tidak sesuai
** Maklumat berkemungkinan fitnah',
'revdelete-otherreason' => 'Sebab lain/tambahan:',
'revdelete-reasonotherlist' => 'Sebab lain',
'revdelete-edit-reasonlist' => 'Ubah sebab-sebab hapus',
'revdelete-offender' => 'Pengarang semakan:',

# Suppression log
'suppressionlog' => 'Log penahanan',
'suppressionlogtext' => 'Berikut adalah daftar penghapusan dan sekatan yang melibatkan kandungan yang disembunyikan daripada pentadbir.
Lihat [[Special:BlockList|senarai sekatan]] untuk senarai larangan dan sekatan semasa.',

# History merging
'mergehistory' => 'Gabungkan sejarah laman',
'mergehistory-header' => "Anda boleh menggabungkan semua semakan dalam sejarah bagi sesebuah laman sumber ke dalam laman lain.
Sila pastikan bahawa perubahan ini akan mengekalkan kesinambungan sejarah laman.

'''Setidak-tidaknya semakan semasa bagi laman sumber akan ditinggalkan.'''",
'mergehistory-box' => 'Gabungkan semakan bagi dua laman:',
'mergehistory-from' => 'Laman sumber:',
'mergehistory-into' => 'Laman destinasi:',
'mergehistory-list' => 'Sejarah suntingan yang boleh digabungkan',
'mergehistory-merge' => 'Semakan-semakan bagi [[:$1]] yang berikut boleh digabungkan ke dalam [[:$2]]. Gunakan lajur butang radio sekiranya anda hanya mahu menggabungkan semakan-semakan yang dibuat pada dan sebelum waktu yang ditetapkan. Sila ambil perhatian bahawa penggunaan pautan-pautan navigasi akan mengeset semula lajur ini.',
'mergehistory-go' => 'Tunjukkan suntingan yang boleh digabungkan',
'mergehistory-submit' => 'Gabungkan semakan',
'mergehistory-empty' => 'Tiada semakan yang boleh digabungkan',
'mergehistory-success' => '$3 semakan bagi [[:$1]] telah digabungkan ke dalam [[:$2]].',
'mergehistory-fail' => 'Gagal melaksanakan penggabungan sejarah, sila semak semula laman tersebut dan parameter waktu.',
'mergehistory-no-source' => 'Laman sumber $1 tidak wujud.',
'mergehistory-no-destination' => 'Laman destinasi $1 tidak wujud.',
'mergehistory-invalid-source' => 'Laman sumber mestilah merupakan tajuk yang sah.',
'mergehistory-invalid-destination' => 'Laman destinasi mestilah merupakan tajuk yang sah.',
'mergehistory-autocomment' => 'Menggabungkan [[:$1]] dengan [[:$2]]',
'mergehistory-comment' => 'Menggabungkan [[:$1]] dengan [[:$2]]: $3',
'mergehistory-same-destination' => 'Laman sasaran tidak boleh sama dengan laman sumber',
'mergehistory-reason' => 'Sebab:',

# Merge log
'mergelog' => 'Log penggabungan',
'pagemerge-logentry' => 'menggabungkan [[$1]] ke dalam [[$2]] (semakan sehingga $3)',
'revertmerge' => 'Pisahkan',
'mergelogpagetext' => 'Yang berikut ialah senarai terkini bagi penggabungan sejarah sesebuah laman ke dalam lamana yang lain.',

# Diffs
'history-title' => 'Sejarah semakan bagi "$1"',
'difference-title' => 'Perbezaan antara semakan-semakan "$1"',
'difference-title-multipage' => 'Perbezaan antara laman "$1" dan "$2"',
'difference-multipage' => '(Perbezaan antara laman)',
'lineno' => 'Baris $1:',
'compareselectedversions' => 'Bandingkan versi-versi yang dipilih',
'showhideselectedversions' => 'Tunjukkan/sorokkan versi yang dipilih',
'editundo' => 'batal',
'diff-empty' => '(Tiada perbezaan)',
'diff-multi' => '($1 {{PLURAL:$1|semakan pertengahan|semakan pertengahan}} oleh $2 {{PLURAL:$2|pengguna|pengguna}} tidak dipaparkan)',
'diff-multi-manyusers' => '($1 {{PLURAL:$1|semakan pertengahan|semakan pertengahan}} oleh lebih daripada $2 {{PLURAL:$2|pengguna|pengguna}} tidak dipaparkan)',
'difference-missing-revision' => '{{PLURAL:$2|Satu semakan|$2 semakan}} bagi perbezaan ini ($1) tidak ditemui.

Hal ini biasanya disebabkan oleh pautan perbezaan yang lapuk ke halaman yang sudah dihapuskan.
Butirannya boleh didapati di [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} log penghapusan].',

# Search results
'searchresults' => 'Hasil carian',
'searchresults-title' => 'Hasil carian "$1"',
'searchresulttext' => 'Untuk maklumat lanjut tentang carian dalam {{SITENAME}}, sila lihat [[{{MediaWiki:Helppage}}|{{int:help}}]].',
'searchsubtitle' => 'Anda mencari \'\'\'[[$1]]\'\'\' ([[Special:Prefixindex/$1|semua laman dengan awalan "$1"]]{{int:pipe-separator}}[[Special:WhatLinksHere/$1|semua laman yang mengandungi pautan ke "$1"]])',
'searchsubtitleinvalid' => 'Untuk pertanyaan "$1"',
'toomanymatches' => 'Terlalu banyak padanan dipulangkan, sila cuba pertanyaan lain',
'titlematches' => 'Padanan tajuk laman',
'notitlematches' => 'Tiada tajuk laman yang sepadan',
'textmatches' => 'Padanan teks laman',
'notextmatches' => 'Tiada teks laman yang sepadan',
'prevn' => '{{PLURAL:$1|$1 sebelumnya}}',
'nextn' => '{{PLURAL:$1|$1 berikutnya}}',
'prevn-title' => '$1 hasil sebelumnya',
'nextn-title' => '$1 hasil berikutnya',
'shown-title' => 'Papar $1 hasil setiap laman',
'viewprevnext' => 'Lihat ($1 {{int:pipe-separator}} $2) ($3)',
'searchmenu-legend' => 'Pilihan carian',
'searchmenu-exists' => "* Laman '''[[$1]]'''",
'searchmenu-new' => "'''Cipta laman \"[[:\$1]]\" di wiki ini!'''",
'searchmenu-prefix' => '[[Special:PrefixIndex/$1|Senarai laman dengan awalan ini]]',
'searchprofile-articles' => 'Laman kandungan',
'searchprofile-project' => 'Laman bantuan dan projek',
'searchprofile-images' => 'Multimedia',
'searchprofile-everything' => 'Semua',
'searchprofile-advanced' => 'Maju',
'searchprofile-articles-tooltip' => 'Cari dalam $1',
'searchprofile-project-tooltip' => 'Cari dalam $1',
'searchprofile-images-tooltip' => 'Cari fail',
'searchprofile-everything-tooltip' => 'Cari semua kandungan (termasuk laman perbincangan)',
'searchprofile-advanced-tooltip' => 'Cari dalam ruang nama yang tersuai',
'search-result-size' => '$1 ({{PLURAL:$2|$2 patah perkataan}})',
'search-result-category-size' => '$1 {{PLURAL:$1|ahli|ahli}} ($2 {{PLURAL:$2|subkategori|subkategori}}, $3 {{PLURAL:$3|fail|fail}})',
'search-result-score' => 'Kaitan: $1%',
'search-redirect' => '(pelencongan $1)',
'search-section' => '(bahagian $1)',
'search-suggest' => 'Maksud anda, $1?',
'search-interwiki-caption' => 'Projek-projek lain',
'search-interwiki-default' => 'Keputusan daripada $1:',
'search-interwiki-more' => '(lagi)',
'search-relatedarticle' => 'Berkaitan',
'mwsuggest-disable' => 'Matikan ciri cadangan carian',
'searcheverything-enable' => 'Cari dalam semua ruang nama',
'searchrelated' => 'berkaitan',
'searchall' => 'semua',
'showingresults' => "Yang berikut ialah '''$1''' hasil bermula daripada yang {{PLURAL:$2|pertama|ke-'''$2'''}}.",
'showingresultsnum' => "Yang berikut ialah '''$3''' hasil bermula daripada yang {{PLURAL:$2|pertama|ke-'''$2'''}}.",
'showingresultsheader' => "{{PLURAL:$5|Keputusan '''$1''' daripada '''$3'''|Keputusan '''$1 - $2''' daripada '''$3'''}} untuk '''$4'''",
'nonefound' => "'''Catatan''': Hanya sesetengah ruang nama dicari secara asali.
Cuba berikan awalan ''all:'' untuk mencari semua kandungan (termasuk laman perbincangan, templat, dan lain-lain), atau gunakan ruang nama yang dikehendaki sebagai awalan.",
'search-nonefound' => 'Tiada hasil yang sepadan dengan pertanyaan.',
'powersearch' => 'Carian lanjutan',
'powersearch-legend' => 'Carian lanjutan',
'powersearch-ns' => 'Cari dalam ruang nama:',
'powersearch-redir' => 'Termasuk lencongan',
'powersearch-field' => 'Cari',
'powersearch-togglelabel' => 'Pilih:',
'powersearch-toggleall' => 'Semua',
'powersearch-togglenone' => 'Tiada',
'search-external' => 'Carian luar',
'searchdisabled' => 'Ciri pencarian dalam {{SITENAME}} dimatikan. Anda boleh mencari melalui Google. Sila ambil perhatian bahawa indeks dalam Google mungkin bukan yang terkini.',
'search-error' => 'Berlakunya ralat ketika mencari: $1',

# Preferences page
'preferences' => 'Keutamaan',
'mypreferences' => 'Keutamaan',
'prefs-edits' => 'Jumlah suntingan:',
'prefsnologin' => 'Belum log masuk',
'prefsnologintext' => 'Anda hendaklah <span class="plainlinks">[{{fullurl:{{#Special:UserLogin}}|returnto=$1}} log masuk]</span> terlebih dahulu untuk menetapkan keutamaan.',
'changepassword' => 'Tukar kata laluan',
'prefs-skin' => 'Rupa',
'skin-preview' => 'Pralihat',
'datedefault' => 'Tiada keutamaan',
'prefs-beta' => 'Ciri-ciri beta',
'prefs-datetime' => 'Tarikh dan waktu',
'prefs-labs' => 'Ciri-ciri makmal',
'prefs-user-pages' => 'Laman pengguna',
'prefs-personal' => 'Profil',
'prefs-rc' => 'Perubahan terkini',
'prefs-watchlist' => 'Senarai pantau',
'prefs-watchlist-days' => 'Had bilangan hari dalam senarai pantau:',
'prefs-watchlist-days-max' => 'Maksimum $1 hari',
'prefs-watchlist-edits' => 'Had maksimum perubahan untuk ditunjukkan dalam senarai pantau penuh:',
'prefs-watchlist-edits-max' => 'Had: 1000',
'prefs-watchlist-token' => 'Token senarai pantau:',
'prefs-misc' => 'Pelbagai',
'prefs-resetpass' => 'Tukar kata laluan',
'prefs-changeemail' => 'Tukar E-mel',
'prefs-setemail' => 'Tetapkan alamat e-mel',
'prefs-email' => 'Pilihan e-mel',
'prefs-rendering' => 'Penampilan',
'saveprefs' => 'Simpan',
'resetprefs' => 'Set semula',
'restoreprefs' => 'Pulihkan semua tetapan asali (dalam semua bahagian)',
'prefs-editing' => 'Menyunting',
'rows' => 'Baris:',
'columns' => 'Lajur:',
'searchresultshead' => 'Cari',
'resultsperpage' => 'Jumlah padanan bagi setiap halaman:',
'stub-threshold' => 'Ambang bagi pemformatan <a href="#" class="stub">pautan ke rencana ringkas</a> (bait):',
'stub-threshold-disabled' => 'Dimatikan',
'recentchangesdays' => 'Bilangan hari dalam perubahan terkini:',
'recentchangesdays-max' => '(had $1 hari)',
'recentchangescount' => 'Bilangan suntingan yang dipaparkan mengikut tetapan asali:',
'prefs-help-recentchangescount' => 'Ini termasuklah perubahan terkini, sejarah laman dan log.',
'prefs-help-watchlist-token2' => 'Inilah kunci rahsia kepada suapan web senarai pantau anda.
Sesiapa yang mengetahuinya akan boleh membaca senarai pantau anda, jadi jangan kongsinya.
[[Special:ResetTokens|Klik di sini jika anda perlu mengesetnya semula]].',
'savedprefs' => 'Keutamaan anda disimpan.',
'timezonelegend' => 'Zon waktu:',
'localtime' => 'Waktu tempatan:',
'timezoneuseserverdefault' => 'Gunakan tetapan sediaan wiki ($1)',
'timezoneuseoffset' => 'Lain-lain (nyatakan imbangan)',
'timezoneoffset' => 'Imbangan¹:',
'servertime' => 'Waktu pelayan:',
'guesstimezone' => 'Gunakan tetapan pelayar saya',
'timezoneregion-africa' => 'Afrika',
'timezoneregion-america' => 'Amerika',
'timezoneregion-antarctica' => 'Antartika',
'timezoneregion-arctic' => 'Artik',
'timezoneregion-asia' => 'Asia',
'timezoneregion-atlantic' => 'Lautan Atlantik',
'timezoneregion-australia' => 'Australia',
'timezoneregion-europe' => 'Eropah',
'timezoneregion-indian' => 'Lautan Hindi',
'timezoneregion-pacific' => 'Lautan Pasifik',
'allowemail' => 'Benarkan e-mel daripada pengguna lain',
'prefs-searchoptions' => 'Cari',
'prefs-namespaces' => 'Ruang nama',
'defaultns' => 'Jika tidak cari dalam ruang nama ini:',
'default' => 'asali',
'prefs-files' => 'Fail',
'prefs-custom-css' => 'CSS tempahan',
'prefs-custom-js' => 'JS tempahan',
'prefs-common-css-js' => 'CSS/JavaScript kongsi untuk semua rupa:',
'prefs-reset-intro' => 'Anda boleh menggunakan laman ini untuk menetapkan semula keutamaan anda kepada tetapan asali.
Tindakan ini tidak boleh dibatalkan.',
'prefs-emailconfirm-label' => 'Pengesahan e-mel:',
'youremail' => 'E-mel:',
'username' => '{{GENDER:$1|Nama pengguna}}:',
'uid' => 'ID {{GENDER:$1|Pengguna}}:',
'prefs-memberingroups' => '{{GENDER:$2|Ahli}} {{PLURAL:$1|kumpulan|kumpulan-kumpulan}}:',
'prefs-memberingroups-type' => '$1',
'prefs-registration' => 'Waktu pendaftaran:',
'prefs-registration-date-time' => '$1',
'yourrealname' => 'Nama sebenar:',
'yourlanguage' => 'Bahasa:',
'yourvariant' => 'Varian bahasa kandungan:',
'prefs-help-variant' => 'Varian atau ortografi pilihan anda untuk memaparkan laman-laman kandungan wiki anda.',
'yournick' => 'Nama samaran:',
'prefs-help-signature' => 'Komen di laman perbincangan harus ditandatangani dengan "<nowiki>~~~~</nowiki>" yang akan ditukar menjadi tandatangan anda dan cap waktu.',
'badsig' => 'Tandatangan mentah tidak sah; sila semak tag HTML.',
'badsiglength' => 'Tandatangan anda tidak boleh melebihi $1 aksara.',
'yourgender' => 'Jantina anda?',
'gender-unknown' => 'Tidak dinyatakan',
'gender-male' => 'Lelaki',
'gender-female' => 'Perempuan',
'prefs-help-gender' => 'Pilihan: Digunakan oleh perisian ini untuk merujuk jantina anda dengan betul. Maklumat ini akan didedahkan kepada awam.',
'email' => 'E-mel',
'prefs-help-realname' => 'Nama sebenar adalah tidak wajib. Jika dinyatakan, ia akan digunakan untuk mengiktiraf karya anda.',
'prefs-help-email' => 'Alamat e-mail adalah tidak wajib, tapi diperlukan untuk set semula kata laluan jika anda terlupa kata laluan anda.',
'prefs-help-email-others' => 'Anda juga boleh memilih untuk membiarkan pengguna lain menghubungi anda menerusi laman perbualan anda tanpa perlu mendedahkan identiti anda.',
'prefs-help-email-required' => 'Alamat e-mel adalah wajib.',
'prefs-info' => 'Maklumat asas',
'prefs-i18n' => 'Pengantarabangsaan',
'prefs-signature' => 'Tandatangan',
'prefs-dateformat' => 'Format tarikh',
'prefs-timeoffset' => 'Imbangan masa',
'prefs-advancedediting' => 'Pilihan am',
'prefs-editor' => 'Penyunting',
'prefs-preview' => 'Pralihat',
'prefs-advancedrc' => 'Pilihan lanjutan',
'prefs-advancedrendering' => 'Pilihan lanjutan',
'prefs-advancedsearchoptions' => 'Pilihan lanjutan',
'prefs-advancedwatchlist' => 'Pilihan lanjutan',
'prefs-displayrc' => 'Pilihan paparan',
'prefs-displaysearchoptions' => 'Pilihan paparan',
'prefs-displaywatchlist' => 'Pilihan paparan',
'prefs-diffs' => 'Beza',
'prefs-help-prefershttps' => 'Keutamaan inu akan berkuatkuasa pada lain kali anda log masuk.',

# User preference: email validation using jQuery
'email-address-validity-valid' => 'Alamat e-mel adalah sah',
'email-address-validity-invalid' => 'Sila masukkan alamat e-mel yang sah',

# User rights
'userrights' => 'Pengurusan hak pengguna',
'userrights-lookup-user' => 'Urus kumpulan pengguna',
'userrights-user-editname' => 'Masukkan nama pengguna:',
'editusergroup' => 'Sunting Kumpulan Pengguna',
'editinguser' => "Mengubah hak pengguna '''[[User:$1|$1]]''' $2",
'userrights-editusergroup' => 'Ubah kumpulan pengguna',
'saveusergroups' => 'Simpan Kumpulan Pengguna',
'userrights-groupsmember' => 'Ahli bagi:',
'userrights-groupsmember-auto' => 'Ahli automatik bagi:',
'userrights-groups-help' => 'Anda boleh mengubah keahlian kumpulan bagi pengguna ini:
* Petak yang bertanda bererti pengguna tersebut adalah ahli kumpulan itu.
* Petak yang tidak bertanda bererti bahawa pengguna tersebut bukan ahli kumpulan itu.
* Tanda bintang (*) menandakan bahawa anda tidak boleh melucutkan keahlian pengguna tersebut setelah anda melantiknya, dan begitulah sebaliknya.',
'userrights-reason' => 'Sebab:',
'userrights-no-interwiki' => 'Anda tidak mempunyai keizinan untuk mengubah hak-hak pengguna di wiki lain.',
'userrights-nodatabase' => 'Pangkalan data $1 tiada atau bukan tempatan.',
'userrights-nologin' => 'Anda mesti [[Special:UserLogin|log masuk]] dengan akaun pentadbir terlebih dahulu untuk memperuntukkan hak-hak pengguna.',
'userrights-notallowed' => 'Akuan anda tidak dibenarkan untuk menambah atau membuang hak pengguna.',
'userrights-changeable-col' => 'Kumpulan yang anda boleh ubah',
'userrights-unchangeable-col' => 'Kumpulan yang anda tak boleh ubah',
'userrights-irreversible-marker' => '$1*',
'userrights-conflict' => 'Percanggahan perubahan hak pengguna! Sila semak dan sahkan perubahan anda.',
'userrights-removed-self' => 'Anda telah berjaya menggugurkan hak-hak sendiri. Oleh yang demikian, anda tidak boleh mengakses halaman ini lagi.',

# Groups
'group' => 'Kumpulan:',
'group-user' => 'Pengguna',
'group-autoconfirmed' => 'Pengguna sah automatik',
'group-bot' => 'Bot',
'group-sysop' => 'Pentadbir',
'group-bureaucrat' => 'Birokrat',
'group-suppress' => 'Penyemak',
'group-all' => '(semua)',

'group-user-member' => '{{GENDER:$1|pengguna}}',
'group-autoconfirmed-member' => '{{GENDER:$1|pengguna sah automatik}}',
'group-bot-member' => '{{GENDER:$1|bot}}',
'group-sysop-member' => '{{GENDER:$1|pentadbir}}',
'group-bureaucrat-member' => '{{GENDER:$1|birokrat}}',
'group-suppress-member' => '{{GENDER:$1|penyemak}}',

'grouppage-user' => '{{ns:project}}:Pengguna',
'grouppage-autoconfirmed' => '{{ns:project}}:Pengguna yang disahkan secara automatik',
'grouppage-bot' => '{{ns:project}}:Bot',
'grouppage-sysop' => '{{ns:project}}:Pentadbir',
'grouppage-bureaucrat' => '{{ns:project}}:Birokrat',
'grouppage-suppress' => '{{ns:project}}:Penyemak',

# Rights
'right-read' => 'Membaca laman',
'right-edit' => 'Menyunting laman',
'right-createpage' => 'Mencipta laman (selain laman perbincangan)',
'right-createtalk' => 'Mencipta laman perbincangan',
'right-createaccount' => 'Membuka akaun pengguna baru',
'right-minoredit' => 'Menanda suntingan kecil',
'right-move' => 'Memindahkan laman',
'right-move-subpages' => 'Memindahkan laman berserta sublaman',
'right-move-rootuserpages' => 'Memindahkan laman induk pengguna',
'right-movefile' => 'Memindahkan fail',
'right-suppressredirect' => 'Memindahkan sesebuah laman tanpa mencipta lencongan',
'right-upload' => 'Memuat naik fail',
'right-reupload' => 'Menulis ganti fail sedia ada',
'right-reupload-own' => 'Menulis ganti fail sedia ada yang dimuat naik sendiri',
'right-reupload-shared' => 'Mengatasi fail di gedung media kongsi',
'right-upload_by_url' => 'Memuat naik fail daripada alamat URL',
'right-purge' => 'Membersihkan cache bagi sesebuah laman tanpa pengesahan',
'right-autoconfirmed' => 'Terkecuali dari had kadar berasaskan IP',
'right-bot' => 'Dianggap melakukan tugas-tugas automatik',
'right-nominornewtalk' => 'Suntingan kecil pada laman perbincangan seseorang pengguna tidak menghidupkan isyarat pesanan baru untuk pengguna itu',
'right-apihighlimits' => 'Meninggikan had dalam pertanyaan API',
'right-writeapi' => 'Menggunakan API tulis',
'right-delete' => 'Menghapuskan laman',
'right-bigdelete' => 'Menghapuskan laman bersejarah',
'right-deletelogentry' => 'Memadamkan dan memulihkan entri log tertentu',
'right-deleterevision' => 'Menghapuskan dan memulihkan semula mana-mana semakan bagi sesebuah laman',
'right-deletedhistory' => 'Melihat senarai entri sejarah yang telah dihapuskan, tetapi tanpa teks yang berkaitan',
'right-deletedtext' => 'Melihat teks yang telah dihapuskan dan perubahan antara semakan-semakan yang telah dihapuskan',
'right-browsearchive' => 'Mencari laman-laman yang telah dihapuskan',
'right-undelete' => 'Mengembalikan laman yang telah dihapuskan (nyahhapus)',
'right-suppressrevision' => 'Memeriksa dan memulihkan semakan yang terselindung daripada pentadbir',
'right-suppressionlog' => 'Melihat log rahsia',
'right-block' => 'Menyekat pengguna lain daripada menyunting',
'right-blockemail' => 'Menyekat pengguna lain daripada mengirim e-mel',
'right-hideuser' => 'Menyekat sesebuah nama pengguna, menyembunyikannya daripada orang ramai',
'right-ipblock-exempt' => 'Melangkau sekatan IP, sekatan automatik dan sekatan julat',
'right-proxyunbannable' => 'Melangkau sekatan proksi automatik',
'right-unblockself' => 'Menyahsekat diri sendiri',
'right-protect' => 'Mengubah tahap perlindungan serta menyunting halaman yang dilindungi lata',
'right-editprotected' => 'Menyunting halaman-halaman yang dilindungi sebagai "{{int:protect-level-sysop}}"',
'right-editsemiprotected' => 'Menyunting halaman-halaman yang dilindungi sebagai "{{int:protect-level-autoconfirmed}}"',
'right-editinterface' => 'Menyunting antara muka pengguna',
'right-editusercssjs' => 'Menyunting fail CSS dan JavaScript pengguna lain',
'right-editusercss' => 'Menyunting fail CSS pengguna lain',
'right-edituserjs' => 'Menyunting fail JavaScript pengguna lain',
'right-editmyusercss' => 'Menyunting fail CSS pengguna sendiri',
'right-editmyuserjs' => 'Menyunting fail JavaScript pengguna sendiri',
'right-viewmywatchlist' => 'Melihat senarai pantau sendiri',
'right-editmywatchlist' => 'Menyunting senarai pantau sendiri. Perhatian: sesetengah tindakan masih akan dapat menambah halaman walaupun tanpa hak ini.',
'right-viewmyprivateinfo' => 'Melihat data peribadi sendiri (cth. alamat e-mel, nama sebenar)',
'right-editmyprivateinfo' => 'Menyunting data peribadi sendiri (cth. alamat e-mel, nama sebenar)',
'right-editmyoptions' => 'Menyunting keutamaan sendiri',
'right-rollback' => 'Mengundurkan suntigan terakhir bagi laman tertentu',
'right-markbotedits' => 'Menanda suntingan yang diundurkan sebagai suntingan bot',
'right-noratelimit' => 'Tidak dikenakan had kadar penyuntingan',
'right-import' => 'Mengimport laman dari wiki lain',
'right-importupload' => 'Mengimport laman dengan memuat naik fail',
'right-patrol' => 'Memeriksa suntingan orang lain',
'right-autopatrol' => 'Suntingannya ditandakan sebagai telah diperiksa secara automatik',
'right-patrolmarks' => 'Melihat tanda pemeriksaan dalam senarai perubahan terkini',
'right-unwatchedpages' => 'Melihat senarai laman yang tidak dipantau',
'right-mergehistory' => 'Menggabungkan sejarah laman',
'right-userrights' => 'Menyerahkan dan menarik balik sebarang hak pengguna',
'right-userrights-interwiki' => 'Menyerahkan dan menarik balik hak pengguna di wiki lain',
'right-siteadmin' => 'Mengunci dan membuka kunci pangkalan data',
'right-override-export-depth' => 'Mengeksport laman termasuk laman dipaut sehingga kedalaman 5',
'right-sendemail' => 'Mengirim e-mel kepada pengguna-pengguna lain',
'right-passwordreset' => 'Lihat e-mel set semula kata laluan',

# Special:Log/newusers
'newuserlogpage' => 'Log akaun baru',
'newuserlogpagetext' => 'Yang berikut ialah log penciptaan pengguna.',

# User rights log
'rightslog' => 'Log hak pengguna',
'rightslogtext' => 'Ini ialah log perubahan terhadap hak pengguna.',

# Associated actions - in the sentence "You do not have permission to X"
'action-read' => 'membaca laman ini',
'action-edit' => 'menyunting laman ini',
'action-createpage' => 'mencipta laman',
'action-createtalk' => 'mencipta laman perbincangan',
'action-createaccount' => 'mencipta akaun pengguna ini',
'action-minoredit' => 'menanda suntingan ini sebagai suntingan kecil',
'action-move' => 'memindahkan laman ini',
'action-move-subpages' => 'memindahkan laman ini dan sublaman-sublamannya',
'action-move-rootuserpages' => 'memindahkan laman induk pengguna',
'action-movefile' => 'pindah fail ini',
'action-upload' => 'memuat naik fail ini',
'action-reupload' => 'menulis ganti fail ini',
'action-reupload-shared' => 'mengatasi fail dari gedung kongsi ini',
'action-upload_by_url' => 'memuat naik fail ini dari alamat URL',
'action-writeapi' => 'menggunakan API tulis',
'action-delete' => 'menghapuskan laman ini',
'action-deleterevision' => 'menghapuskan semakan ini',
'action-deletedhistory' => 'melihat sejarah yang telah dihapuskan bagi laman ini',
'action-browsearchive' => 'mencari laman-laman yang telah dihapuskan',
'action-undelete' => 'menyahhapuskan laman ini',
'action-suppressrevision' => 'menyemak semula dan memulihkan semakan tersembunyi ini',
'action-suppressionlog' => 'melihat log sulit ini',
'action-block' => 'menyekat pengguna ini daripada menyunting',
'action-protect' => 'mengubah aras perlindungan bagi laman ini',
'action-rollback' => 'mengundurkan suntingan-suntingan pengguna terkini yang menyunting laman tertentu dengan cepat',
'action-import' => 'mengimport halaman-halaman dari wiki lain',
'action-importupload' => 'mengimport halaman-halaman daripada memuat naik fail',
'action-patrol' => 'menanda ronda suntingan orang lain',
'action-autopatrol' => 'menanda ronda suntingan anda sendiri',
'action-unwatchedpages' => 'melihat senarai laman tidak dipantau',
'action-mergehistory' => 'menggabungkan sejarah laman ini',
'action-userrights' => 'mengubah semua hak pengguna',
'action-userrights-interwiki' => 'mengubah hak pengguna dari wiki lain',
'action-siteadmin' => 'mengunci atau membuka kunci pangkalan data wiki ini',
'action-sendemail' => 'menghantar e-mel',
'action-editmywatchlist' => 'menyunting senarai pantau sendiri',
'action-viewmywatchlist' => 'melihat senarai pantau sendiri',
'action-viewmyprivateinfo' => 'melihat maklumat peribadi sendiri',
'action-editmyprivateinfo' => 'menyunting maklumat peribadi sendiri',

# Recent changes
'nchanges' => '$1 perubahan',
'enhancedrc-since-last-visit' => '$1 {{PLURAL:$1|sejak lawatan terakhir}}',
'enhancedrc-history' => 'sejarah',
'recentchanges' => 'Perubahan terkini',
'recentchanges-legend' => 'Pilihan perubahan terkini',
'recentchanges-summary' => 'Jejaki perubahan terkini dalam {{SITENAME}} pada laman ini.',
'recentchanges-noresult' => 'Tiada perubahan dalam tempoh yang diberikan sepadan dengan kriteria ini.',
'recentchanges-feed-description' => 'Jejaki perubahan terkini dalam {{SITENAME}} pada suapan ini.',
'recentchanges-label-newpage' => 'Suntingan ini mencipta laman baru',
'recentchanges-label-minor' => 'Ini ialah suntingan kecil',
'recentchanges-label-bot' => 'Suntingan ini dilakukan oleh bot',
'recentchanges-label-unpatrolled' => 'Suntingan ini belum dirondai',
'rcnote' => "Yang berikut ialah '''$1''' perubahan terakhir sejak '''$2''' hari yang lalu sehingga $5, $4.",
'rcnotefrom' => 'Yang berikut ialah semua perubahan sejak <b>$2</b> (sehingga <b>$1</b>).',
'rclistfrom' => 'Papar perubahan sejak $1',
'rcshowhideminor' => '$1 suntingan kecil',
'rcshowhidebots' => '$1 bot',
'rcshowhideliu' => '$1 pengguna log masuk',
'rcshowhideanons' => '$1 pengguna tanpa nama',
'rcshowhidepatr' => '$1 suntingan dirondai',
'rcshowhidemine' => '$1 suntingan saya',
'rclinks' => 'Paparkan $1 perubahan terakhir sejak $2 hari yang lalu<br />$3',
'diff' => 'beza',
'hist' => 'sej',
'hide' => 'Sorokkan',
'show' => 'Tunjukkan',
'minoreditletter' => 'k',
'newpageletter' => 'B',
'boteditletter' => 'b',
'unpatrolledletter' => '!',
'number_of_watching_users_pageview' => '[$1 pemantau]',
'rc_categories' => 'Hadkan kepada kategori (asingkan dengan "|")',
'rc_categories_any' => 'Semua',
'rc-change-size' => '$1',
'rc-change-size-new' => '$1 bait selepas perubahan',
'newsectionsummary' => '/* $1 */ bahagian baru',
'rc-enhanced-expand' => 'Papar butiran (JavaScript diperlukan)',
'rc-enhanced-hide' => 'Sorokkan butiran',
'rc-old-title' => 'asalnya diwujudkan sebagai "$1"',

# Recent changes linked
'recentchangeslinked' => 'Perubahan berkaitan',
'recentchangeslinked-feed' => 'Perubahan berkaitan',
'recentchangeslinked-toolbox' => 'Perubahan berkaitan',
'recentchangeslinked-title' => 'Perubahan berkaitan dengan $1',
'recentchangeslinked-summary' => "Laman khas ini menyenaraikan perubahan terkini bagi laman-laman yang dipaut. Laman-laman yang terdapat dalam senarai pantau anda ditandakan dengan '''teks tebal'''.",
'recentchangeslinked-page' => 'Nama laman:',
'recentchangeslinked-to' => 'Paparkan perubahan pada laman yang mengandungi pautan ke laman yang diberikan',

# Upload
'upload' => 'Muat naik fail',
'uploadbtn' => 'Muat naik fail',
'reuploaddesc' => 'Kembali ke borang muat naik',
'upload-tryagain' => 'Serahkan keterangan fail yang telah diubah',
'uploadnologin' => 'Belum log masuk',
'uploadnologintext' => 'Anda mesti $1 untuk memuat naik fail.',
'upload_directory_missing' => 'Direktori muat naik ($1) hilang dan tidak dapat dicipta oleh pelayan web.',
'upload_directory_read_only' => 'Direktori muat naik ($1) tidak boleh ditulis oleh pelayan web.',
'uploaderror' => 'Ralat muat naik',
'upload-recreate-warning' => "'''Amaran: Sebuah fail dengan nama tersebut telah pun dihapuskan atau dipindahkan.'''

Log penghapusan dan pemindahan untuk laman ini disediakan di bawah ini untuk kemudahan:",
'uploadtext' => "Gunakan borang di bawah untuk memuat naik fail.
Untuk melihat atau mencari imej yang sudah dimuat naik, sila ke [[Special:FileList|senarai fail yang dimuat naik]]. Tindakan muat naik akan direkodkan dalam [[Special:Log/upload|log muat naik]], manakala penghapusan dalam [[Special:Log/delete|log penghapusan]].

Untuk menyertakan sebarang fail ke dalam sesebuah laman, gunakan pautan dengan satu daripada bentuk-bentuk berikut:
* '''<code><nowiki>[[</nowiki>{{ns:file}}<nowiki>:Fail.jpg]]</nowiki></code>''' untuk menggunakan versi penuh bagi fail itu
* '''<code><nowiki>[[</nowiki>{{ns:file}}<nowiki>:Fail.png|200px|thumb|left|teks alternatif]]</nowiki></code>''' untuk menggunakan lakaran 200 piksel lebar di dalam sebuah kotak yang diletakkan di jidar kiri dengan keterangan 'teks alternatif'
* '''<code><nowiki>[[</nowiki>{{ns:media}}<nowiki>:Fail.ogg]]</nowiki></code>''' untuk memaut secara terus tanpa memaparkan fail itu",
'upload-permitted' => 'Jenis fail yang dibenarkan: $1.',
'upload-preferred' => 'Jenis fail yang diutamakan: $1.',
'upload-prohibited' => 'Jenis fail yang dilarang: $1.',
'uploadlog' => 'log muat naik',
'uploadlogpage' => 'Log muat naik',
'uploadlogpagetext' => 'Yang berikut ialah senarai terkini bagi fail yang dimuat naik.',
'filename' => 'Nama fail',
'filedesc' => 'Ringkasan',
'fileuploadsummary' => 'Ringkasan:',
'filereuploadsummary' => 'Perubahan fail:',
'filestatus' => 'Status hak cipta:',
'filesource' => 'Sumber:',
'uploadedfiles' => 'Fail yang telah dimuat naik',
'ignorewarning' => 'Abaikan amaran dan simpan juga fail ini.',
'ignorewarnings' => 'Abaikan sebarang amaran',
'minlength1' => 'Panjang nama fail mestilah sekurang-kurangnya satu huruf.',
'illegalfilename' => 'Nama fail "$1" mengandungi aksara yang tidak dibenarkan dalam tajuk laman. Sila tukar nama fail ini dan muat naik sekali lagi.',
'filename-toolong' => 'Nama fail tidak boleh melebihi 240 bait.',
'badfilename' => 'Nama fail telah ditukar kepada "$1".',
'filetype-mime-mismatch' => 'Sambungan fail ".$1" tidak padan dengan jenis MIME fail ($2).',
'filetype-badmime' => 'Memuat naik fail jenis MIME "$1" adalah tidak dibenarkan.',
'filetype-bad-ie-mime' => 'Fail ini tidak boleh dimuat naik kerana Internet Explorer mengesannya sebagai fail jenis "$1" yang tidak dibenarkan dan berbahaya.',
'filetype-unwanted-type' => "'''\".\$1\"''' adalah jenis fail yang tidak dikehendaki. {{PLURAL:\$3|Jenis|Jenis-jenis}} fail yang diutamakan ialah \$2.",
'filetype-banned-type' => '\'\'\'".$1"\'\'\' adalah {{PLURAL:$4|jenis|jenis-jenis}} fail yang dilarang. {{PLURAL:$3|Jenis|Jenis-jenis}} fail yang dibenarkan ialah $2.',
'filetype-missing' => 'Fail ini tidak mempunyai sambungan (contohnya ".jpg").',
'empty-file' => 'Fail yang anda serahkan adalah kosong.',
'file-too-large' => 'Fail yang anda serahkan adalah terlalu besar.',
'filename-tooshort' => 'Nama fail ini terlalu pendek.',
'filetype-banned' => 'Fail jenis ini adalah dilarang.',
'verification-error' => 'Fail ini tidak lulus pengesahan fail.',
'hookaborted' => 'Pengubahsuaian yang anda buat telah disekat oleh sebuah cangkuk sambungan.',
'illegal-filename' => 'Nama fail tidak dibenarkan.',
'overwrite' => 'Menulis ganti fail yang telah wujud adalah tidak dibenarkan.',
'unknown-error' => 'Berlaku ralat yang tidak diketahui.',
'tmp-create-error' => 'Fail sementara tidak dapat dicipta.',
'tmp-write-error' => 'Fail sementara tidak dapat ditulis.',
'large-file' => 'Saiz fail ini ialah $2. Anda dinasihati supaya memuat naik fail yang tidak melebihi $1.',
'largefileserver' => 'Fail ini telah melebihi had muat naik pelayan web.',
'emptyfile' => 'Fail yang dimuat naik adalah kosong. Ini mungkin disebabkan oleh kesilapan menaip nama fail. Sila pastikan bahawa anda betul-betul mahu memuat naik fail ini.',
'windows-nonascii-filename' => 'Wiki ini tidak menyokong nama fail yang mengandungi aksara khas.',
'fileexists' => 'Sebuah fail dengan nama ini telah pun wujud.
Sila semak <strong>[[:$1]]</strong> sekiranya anda tidak pasti bahawa anda mahu menukarnya atau tidak.
[[$1|thumb]]',
'filepageexists' => 'Laman penerangan untuk fail ini telah pun dicipta di <strong>[[:$1]]</strong>, tetapi tiada fail dengan nama ini wujud.
Ringkasan yang anda masukkan tidak akan muncul di laman penerangan tersebut. Untuk memastikannya muncul, anda perlu menyuntingnya secara manual.
[[$1|thumb]]',
'fileexists-extension' => 'Sebuah fail dengan nama yang sama telah pun wujud: [[$2|thumb]]
* Nama fail yang dimuat naik: <strong>[[:$1]]</strong>
* Nama fail yang sedia ada: <strong>[[:$2]]</strong>
Sila pilih nama lain.',
'fileexists-thumbnail-yes' => "Fail ini kelihatan seperti sebuah imej yang telah dikecilkan ''(gambar kenit)''. [[$1|thumb]]
Sila semak fail <strong>[[:$1]]</strong>.
Jika fail yang disemak itu adalah sama dengan yang saiz asal, maka anda tidak perlu memuat naik gambar kenit tambahan.",
'file-thumbnail-no' => "Nama fail ini bermula dengan <strong>$1</strong>.
Barangkali ia adalah sebuah imej yang telah dikecilkan ''(gambar kenit)''.
Jika anda memiliki imej ini dalam leraian penuh, sila muat naik fail tersebut. Jika tidak, sila tukar nama fail ini.",
'fileexists-forbidden' => 'Sebuah fail dengan nama ini telah pun wujud, dan tidak boleh ditulis ganti. Jika anda masih mahu memuat naik fail ini, sila berundur dan muat naik fail ini dengan nama lain. [[File:$1|thumb|center|$1]]',
'fileexists-shared-forbidden' => 'Sebuah fail dengan nama ini telah pun wujud dalam gedung fail kongsi. Jika anda masih mahu memuat naik fail ini, sila kembali ke borang muat naik dan gunakan nama lain. [[File:$1|thumb|center|$1]]',
'file-exists-duplicate' => 'Fail ini adalah salinan bagi {{PLURAL:$1|fail|fail-fail}} berikut:',
'file-deleted-duplicate' => 'Sebuah fail yang serupa dengan fail ini ([[:$1]]) telah pun dihapuskan sebelum ini. Anda seharusnya memeriksa sejarah penghapusan fail itu terlebih dahulu sebelum memuat naiknya sekali lagi.',
'uploadwarning' => 'Amaran muat naik',
'uploadwarning-text' => 'Sila ubah keterangan fail di bawah dan cuba lagi.',
'savefile' => 'Simpan fail',
'uploadedimage' => 'memuat naik "[[$1]]"',
'overwroteimage' => 'memuat naik versi baru bagi "[[$1]]"',
'uploaddisabled' => 'Ciri muat naik dimatikan',
'copyuploaddisabled' => 'Ciri muat naik melalui URL telah dilumpuhkan.',
'uploadfromurl-queued' => 'Muat naik anda telah digilirkan.',
'uploaddisabledtext' => 'Ciri muat naik fail dimatikan.',
'php-uploaddisabledtext' => 'Pemuatnaikan fail PHP dilumpuhkan. Sila semak tetapan file_uploads.',
'uploadscripted' => 'Fail ini mengandungi kod HTML atau skrip yang boleh disalahtafsirkan oleh pelayar web.',
'uploadvirus' => 'Fail tersebut mengandungi virus! Butiran: $1',
'uploadjava' => 'Fail ini ialah fail ZIP yang mengandungi fail .class Java.
Memuat naik fail Java tidak dibenarkan, kerana boleh menyebabkan sekatan keselamatan dipintas.',
'upload-source' => 'Fail sumber',
'sourcefilename' => 'Nama fail sumber:',
'sourceurl' => 'Sumber URL:',
'destfilename' => 'Nama fail destinasi:',
'upload-maxfilesize' => 'Had saiz fail: $1',
'upload-description' => 'Keterangan fail',
'upload-options' => 'Pilihan muat naik',
'watchthisupload' => 'Pantau fail ini',
'filewasdeleted' => 'Sebuah fail dengan nama ini pernah dimuat naik, tetapi kemudiannya dihapuskan. Anda seharusnya menyemak $1 sebelum meneruskan percubaan untuk memuat naik fail ini.',
'filename-bad-prefix' => "Nama bagi fail yang dimuat naik bermula dengan '''\"\$1\"''', yang mana merupakan nama yang tidak deskriptif yang biasanya ditetapkan oleh kamera digital secara automatik. Sila berikan nama yang lebih deskriptif bagi fail tersebut.",
'filename-prefix-blacklist' => ' #<!-- biarkan baris ini seperti sediakala --> <pre>
# Sintaks adalah seperti berikut:
#   * Segalanya mulai aksara "#" hingga akhir baris ialah komen
#   * Setiap baris bukan kosong ialah awalan bagi nama-nama fail biasa yang ditetapkan secara automatik oleh kamera digital
CIMG # Casio
DSC_ # Nikon
DSCF # Fuji
DSCN # Nikon
DUW # sesetengah telefon bimbit
IMG # generik
JD # Jenoptik
MGP # Pentax
PICT # dll.
 #</pre> <!-- biarkan baris ini seperti sediakala -->',
'upload-success-subj' => 'Muat naik berjaya',
'upload-success-msg' => 'Muat naik anda dari [$2] berjaya. Ia ada di sini: [[:{{ns:file}}:$1]]',
'upload-failure-subj' => 'Masalah muat naik',
'upload-failure-msg' => 'Terdapat masalah dengan muat naik anda daripada [$2]:

$1',
'upload-warning-subj' => 'Amaran muat naik',
'upload-warning-msg' => 'Terdapat masalah dengan muat naik anda daripada [$2]. Anda boleh kembali ke [[Special:Upload/stash/$1|borang muat naik]] untuk mengatasi masalah ini.',

'upload-proto-error' => 'Protokol salah',
'upload-proto-error-text' => 'Muat naik jauh memerlukan URL yang dimulakan dengan <code>http://</code> atau <code>ftp://</code>.',
'upload-file-error' => 'Ralat dalaman',
'upload-file-error-text' => 'Ralat dalaman telah berlaku ketika cuba mencipta fail sementara pada komputer pelayan.
Sila hubungi [[Special:ListUsers/sysop|pentadbir sistem]].',
'upload-misc-error' => 'Ralat muat naik yang tidak diketahui',
'upload-misc-error-text' => 'Ralat yang tidak diketahui telah berlaku ketika muat naik. Sila pastikan bahawa URL tersebut sah dan boleh dicapai kemudian cuba lagi. Jika masalah ini berterusan, sila hubungi pentadbir sistem.',
'upload-too-many-redirects' => 'URL ini mengandungi terlalu banyak lencongan',
'upload-unknown-size' => 'Saiz tidak diketahui',
'upload-http-error' => 'Berlaku ralat HTTP: $1',
'upload-copy-upload-invalid-domain' => 'Muat naik salin tidak terdapat dari domain ini.',

# File backend
'backend-fail-stream' => 'Fail $1 tidak dapat distrimkan.',
'backend-fail-backup' => 'Fail $1 tidak dapat disandarkan.',
'backend-fail-notexists' => 'Fail $1 tidak wujud.',
'backend-fail-hashes' => 'Cincangan fail untuk perbandingan tidak dapat diperoleh.',
'backend-fail-notsame' => 'Satu fail yang tidak seiras sudah wujud di $1.',
'backend-fail-invalidpath' => '$1 bukan laluan storan yang sah.',
'backend-fail-delete' => 'Fail $1 tidak dapat dihapuskan.',
'backend-fail-describe' => 'Metadata untuk fail "$1" tidak dapat diubah.',
'backend-fail-alreadyexists' => 'Fail $1 sudah wujud.',
'backend-fail-store' => 'Fail $1 tidak dapat distorkan di $2.',
'backend-fail-copy' => 'Fail $1 tidak dapat disalin ke $2.',
'backend-fail-move' => 'Fail $1 tidak dapat dipindahkan ke $2.',
'backend-fail-opentemp' => 'Fail sementara tidak dapat dibuka.',
'backend-fail-writetemp' => 'Fail sementara tidak dapat ditulisi.',
'backend-fail-closetemp' => 'Fail sementara tidak dapat ditutup.',
'backend-fail-read' => 'Fail $1 tidak dapat dibaca.',
'backend-fail-create' => 'Fail $1 tidak dapat ditulis.',
'backend-fail-maxsize' => 'Fail $1 tidak boleh ditulis kerana melebihi $2 bait.',
'backend-fail-readonly' => 'Backend storan "$1" kini dalam mod baca sahaja. Sebab yang diberikan ialah: "$2"',
'backend-fail-synced' => 'Fail "$1" berada dalam keadaan yang tidak sejajar dalam backend storan dalaman',
'backend-fail-connect' => 'Tidak dapat bersambung dengan backend storan "$1".',
'backend-fail-internal' => 'Berlakunya ralat yang tidak dikenali dalam backend storan "$1".',
'backend-fail-contenttype' => 'Jenis kandungan fail untuk disimpan di "$1" tidak dapat ditentukan.',
'backend-fail-batchsize' => 'Backend storan diberi $1 operasi fail dalam satu kelompok; hadnya ialah $2 operasi.',
'backend-fail-usable' => 'Fail "$1" tidak boleh dibaca atau ditulis kerana kebenaran tidak memadai atau tertinggal direktori/penyimpan.',

# File journal errors
'filejournal-fail-dbconnect' => 'Tidak dapat bersambung dengan pangkalan data jurnal untuk backend storan "$1".',
'filejournal-fail-dbquery' => 'Pangkalan data jurnal untuk backend storan "$1" tidak dapat dikemaskinikan.',

# Lock manager
'lockmanager-notlocked' => '"$1" tidak dapat dibuka; ia tidak terkunci.',
'lockmanager-fail-closelock' => 'Fail kunci untuk "$1" tidak dapat ditutup.',
'lockmanager-fail-deletelock' => 'Fail kunci untuk "$1" tidak dapat dihapuskan.',
'lockmanager-fail-acquirelock' => 'Kunci untuk "$1" tidak dapat diperoleh.',
'lockmanager-fail-openlock' => 'Fail kunci untuk "$1" tidak dapat dibuka.',
'lockmanager-fail-releaselock' => 'Kunci untuk "$1" tidak dapat dikeluarkan.',
'lockmanager-fail-db-bucket' => 'Di baldi $1 tidak dapat dihubungi pangkalan data selak yang secukupnya.',
'lockmanager-fail-db-release' => 'Selak-selak tidak dapat dikeluarkan di pangkalan data $1.',
'lockmanager-fail-svr-acquire' => 'Selak-selak tidak dapat diperoleh di pelayan $1.',
'lockmanager-fail-svr-release' => 'Selak-selak tidak dapat dikeluarkan di pelayan $1.',

# ZipDirectoryReader
'zip-file-open-error' => 'Wujud ralat ketika membuka fail untuk pemeriksaan ZIP.',
'zip-wrong-format' => 'Fail yang dinyatakan bukan fail ZIP.',
'zip-bad' => 'Fail ini adalah fail ZIP rosak atau tidak dapat dibaca.
Ia tidak dapat diperiksa dengan betul demi keselamatan.',
'zip-unsupported' => 'Fail ini adalah fail ZIP yang menggunakan ciri-ciri ZIP tidak disokong oleh MediaWiki. 
Ia tidak dapat diperiksa dengan betul demi keselamatan.',

# Special:UploadStash
'uploadstash' => 'Sorokan muat naik',
'uploadstash-summary' => 'Laman ini menyediakan capaian kepada fail-fail yang dimuat naik (atau sedang dimuat naik) tapi belum diterbitkan ke dalam wiki. Fail-fail ini tidak dapat dilihat oleh sesiapa melainkan pengguna yang memuatnaiknya.',
'uploadstash-clear' => 'Bersihkan fail-fail sorokan',
'uploadstash-nofiles' => 'Anda tiada sebarang fail sorokan.',
'uploadstash-badtoken' => 'Tindakan tadi tidak berjaya, mungkin kerana kelayakan menyunting anda telah luput. Cuba lagi.',
'uploadstash-errclear' => 'Gagal membersihkan fail-fail tersebut.',
'uploadstash-refresh' => 'Segarkan semula senarai fail',
'invalid-chunk-offset' => 'Ofset ketulan tidak sah',

# img_auth script messages
'img-auth-accessdenied' => 'Capaian ditolak',
'img-auth-nopathinfo' => 'PATH_INFO tertinggal.
Pelayan anda tidak ditetapkan untuk menyampaikan maklumat ini.
Ia barangkali berdasarkan CGI dan tidak boleh menyokong img_auth.
Rujuk https://www.mediawiki.org/wiki/Manual:Image_Authorization',
'img-auth-notindir' => 'Laluan yang diminta tiada dalam direktori muat naik yang telah dikonfigurasikan.',
'img-auth-badtitle' => 'Tajuk yang sah tidak dapat dibina daripada "$1".',
'img-auth-nologinnWL' => 'Anda belum log masuk dan "$1" tiada dalam senarai putih.',
'img-auth-nofile' => 'Fail "$1" tiada.',
'img-auth-isdir' => 'Anda telah mencuba mencapai direktori "$1". Hanya capaian fail dibenarkan.',
'img-auth-streaming' => '"$1" sedang disalurkan.',
'img-auth-public' => 'Fungsi img_auth.php ialah mengoutput fail-fail daripada wiki peribadi.
Wiki ini telah dikonfigurasikan sebagai wiki awam.
Untuk keselamatan optimum, img_auth.php telah dilumpuhkan.',
'img-auth-noread' => 'Pengguna tidak mempunyai capaian membaca "$1".',
'img-auth-bad-query-string' => 'URL ini ada rentetan pertanyaan yang tidak sah.',

# HTTP errors
'http-invalid-url' => 'URL tidak sah: $1',
'http-invalid-scheme' => 'URL dengan skema "$1" tidak disokong.',
'http-request-error' => 'Permintaan HTTP gagal kerana ralat yang tidak diketahui.',
'http-read-error' => 'Ralat baca HTTP.',
'http-timed-out' => 'Permintaan HTTP melebihi waktu tamat.',
'http-curl-error' => 'Ralat mendapatkan URL: $1',
'http-bad-status' => 'Berlaku masalah ketika permintaan HTTP: $1 $2',

# Some likely curl errors. More could be added from <http://curl.haxx.se/libcurl/c/libcurl-errors.html>
'upload-curl-error6' => 'URL tidak dapat dicapai',
'upload-curl-error6-text' => 'URL yang dinyatakan tidak dapat dicapai. Sila pastikan bahawa URL dan tapak web tersebut hidup.',
'upload-curl-error28' => 'Waktu henti muat naik',
'upload-curl-error28-text' => 'Tapak web tersebut terlalu lambat bertindak balas. Sila pastikan bahawa tapak web tersebut hidup, tunggu sebentar dan cuba lagi. Anda boleh mencuba lagi pada waktu yang kurang sibuk.',

'license' => 'Lesen:',
'license-header' => 'Perlesenan',
'nolicense' => 'Tidak dipilih',
'license-nopreview' => '(Tiada pralihat)',
'upload_source_url' => ' (URL yang boleh diakses oleh orang awam)',
'upload_source_file' => ' (fail dalam komputer anda)',

# Special:ListFiles
'listfiles-summary' => 'Laman khas ini memaparkan semua fail yang telah dimuat naik.',
'listfiles_search_for' => 'Cari nama imej:',
'imgfile' => 'fail',
'listfiles' => 'Senarai fail',
'listfiles_thumb' => 'Gambar kenit',
'listfiles_date' => 'Tarikh',
'listfiles_name' => 'Nama',
'listfiles_user' => 'Pengguna',
'listfiles_size' => 'Saiz',
'listfiles_description' => 'Keterangan',
'listfiles_count' => 'Versi',
'listfiles-show-all' => 'Masukkan versi lama imej',
'listfiles-latestversion' => 'Versi semasa',
'listfiles-latestversion-yes' => 'Ya',
'listfiles-latestversion-no' => 'Tidak',

# File description page
'file-anchor-link' => 'Fail',
'filehist' => 'Sejarah fail',
'filehist-help' => 'Klik pada tarikh/waktu untuk melihat rupa fail tersebut pada waktu silam.',
'filehist-deleteall' => 'hapuskan semua',
'filehist-deleteone' => 'hapuskan',
'filehist-revert' => 'balik',
'filehist-current' => 'semasa',
'filehist-datetime' => 'Tarikh/Waktu',
'filehist-thumb' => 'Gambar kenit',
'filehist-thumbtext' => 'Gambar kenit bagi versi pada $1',
'filehist-nothumb' => 'Tiada gambar kenit',
'filehist-user' => 'Pengguna',
'filehist-dimensions' => 'Ukuran',
'filehist-filesize' => 'Saiz fail',
'filehist-comment' => 'Komen',
'filehist-missing' => 'Fail tidak dapat dijumpai',
'imagelinks' => 'Penggunaan fail',
'linkstoimage' => '{{PLURAL:$1|Laman|$1 buah laman}} berikut mengandungi pautan ke fail ini:',
'linkstoimage-more' => 'Lebih daripada $1 laman mengandungi pautan ke fail ini.
Yang berikut ialah {{PLURAL:$1||$1}} pautan pertama ke fail ini.
Anda boleh melihat [[Special:WhatLinksHere/$2|senarai penuh]].',
'nolinkstoimage' => 'Tiada laman yang mengandungi pautan ke fail ini.',
'morelinkstoimage' => 'Lihat [[Special:WhatLinksHere/$1|semua pautan]] ke fail ini.',
'linkstoimage-redirect' => '$1 (lencongan fail) $2',
'duplicatesoffile' => '{{PLURAL:$1|Fail|$1 buah fail}} berikut adalah salinan bagi fail ini ([[Special:FileDuplicateSearch/$2|butiran lanjut]]):',
'sharedupload' => 'Fail ini daripada $1 dan boleh digunakan oleh projek lain.',
'sharedupload-desc-there' => 'Fail ini dari $1 dan mungkin digunakan oleh projek lain.
Sila lihat [$2 laman penerangan fail] untuk maklumat lanjut.',
'sharedupload-desc-here' => 'Fail ini dari $1 dan mungkin digunakan oleh projek lain.
Penerangan pada [$2 laman penerangan failnya] di sana ditunjukkan di bawah.',
'sharedupload-desc-edit' => 'Fail ini dari $1 dan mungkin digunakan oleh projek-projek yang lain.
Mungkin anda ingin menyunting keterangan pada [$2 laman penerangan failnya] di situ.',
'sharedupload-desc-create' => 'Fail ini dari $1 dan mungkin digunakan oleh projek-projek yang lain.
Mungkin anda ingin menyunting keterangan pada [$2 laman penerangan failnya] di situ.',
'filepage-nofile' => 'Fail dengan nama ini tidak wujud.',
'filepage-nofile-link' => 'Fail dengan nama ini tidak wujud, tetapi boleh [$1 dimuat naik].',
'uploadnewversion-linktext' => 'Muat naik versi baru bagi fail ini',
'shared-repo-from' => 'dari $1',
'shared-repo' => 'sebuah gedung kongsi',
'shared-repo-name-wikimediacommons' => 'Wikimedia Commons',
'filepage.css' => '/* CSS yang ditempatkan di sini disertakan pada laman keterangan fail, dan juga pada klien wiki asing */',
'upload-disallowed-here' => 'Anda tidak boleh menggantikan fail ini.',

# File reversion
'filerevert' => 'Balikkan $1',
'filerevert-legend' => 'Balikkan fail',
'filerevert-intro' => '<span class="plainlinks">Anda sedang menmbalikkan \'\'\'[[Media:$1|$1]]\'\'\' kepada [$4 versi pada $3, $2].</span>',
'filerevert-comment' => 'Sebab:',
'filerevert-defaultcomment' => 'Dibalikkan kepada versi pada $2, $1',
'filerevert-submit' => 'Balikkan',
'filerevert-success' => '<span class="plainlinks">\'\'\'[[Media:$1|$1]]\'\'\' telah dibalikkan kepada [$4 versi pada $3, $2].</span>',
'filerevert-badversion' => 'Tiada versi tempatan bagi fail ini dengan cap waktu yang dinyatakan.',

# File deletion
'filedelete' => 'Hapuskan $1',
'filedelete-legend' => 'Hapuskan fail',
'filedelete-intro' => "Anda sudah hendak menghapuskan fail '''[[Media:$1|$1]]''' berserta semua sejarahnya.",
'filedelete-intro-old' => '<span class="plainlinks">Anda sedang menghapuskan versi \'\'\'[[Media:$1|$1]]\'\'\' pada [$4 $3, $2].</span>',
'filedelete-comment' => 'Sebab:',
'filedelete-submit' => 'Hapuskan',
'filedelete-success' => "'''$1''' telah dihapuskan.",
'filedelete-success-old' => "Versi '''[[Media:$1|$1]]''' pada $3, $2 telah dihapuskan.",
'filedelete-nofile' => "'''$1''' tidak wujud.",
'filedelete-nofile-old' => "Tiada versi arkib bagi '''$1''' dengan sifat-sifat yang dinyatakan.",
'filedelete-otherreason' => 'Sebab lain/tambahan:',
'filedelete-reason-otherlist' => 'Sebab lain',
'filedelete-reason-dropdown' => '
*Sebab-sebab lazim
** Melanggar hak cipta
** Fail berulang',
'filedelete-edit-reasonlist' => 'Ubah sebab-sebab hapus',
'filedelete-maintenance' => 'Ciri penghapusan dan pemulihan fail telah dilumpuhkan buat sementara sepanjang proses penyenggaraan.',
'filedelete-maintenance-title' => 'Fail tidak boleh dihapuskan',

# MIME search
'mimesearch' => 'Carian MIME',
'mimesearch-summary' => 'Anda boleh menggunakan laman ini untuk mencari fail mengikut jenis MIME. Format input ialah "jenis/subjenis", contohnya <code>image/jpeg</code>.',
'mimetype' => 'Jenis MIME:',
'download' => 'muat turun',

# Unwatched pages
'unwatchedpages' => 'Laman tidak dipantau',

# List redirects
'listredirects' => 'Senarai lencongan',

# Unused templates
'unusedtemplates' => 'Templat tidak digunakan',
'unusedtemplatestext' => 'Yang berikut ialah senarai laman dalam ruang nama {{ns:template}} yang tidak disertakan dalam laman lain. Sila pastikan bahawa anda menyemak pautan lain ke templat-templat tersebut sebelum menghapuskannya.',
'unusedtemplateswlh' => 'pautan-pautan lain',

# Random page
'randompage' => 'Laman rawak',
'randompage-nopages' => 'Tiada laman dalam {{PLURAL:$2|ruang|ruang-ruang}} nama berikut: $1.',

# Random page in category
'randomincategory' => 'Halaman pilihan rawak dalam kategori',
'randomincategory-invalidcategory' => '"$1" bukan nama kategori yang sah.',
'randomincategory-nopages' => 'Tiada halaman di [[:Category:$1]].',
'randomincategory-selectcategory' => 'Dapatkan halaman pilihan rawak dari kategori: $1 $2.',
'randomincategory-selectcategory-submit' => 'Pergi',

# Random redirect
'randomredirect' => 'Lencongan rawak',
'randomredirect-nopages' => 'Tiada lencongan dalam ruang nama "$1".',

# Statistics
'statistics' => 'Statistik',
'statistics-header-pages' => 'Statistik halaman',
'statistics-header-edits' => 'Statistik suntingan',
'statistics-header-views' => 'Statistik pandangan',
'statistics-header-users' => 'Statistik pengguna',
'statistics-header-hooks' => 'Statistik lain',
'statistics-articles' => 'Laman kandungan',
'statistics-pages' => 'Laman',
'statistics-pages-desc' => 'Semua laman di wiki ini, termasuk laman perbincangan, lencongan, dan lain-lain.',
'statistics-files' => 'Fail dimuat naik',
'statistics-edits' => 'Suntingan laman sejak {{SITENAME}} dibuka',
'statistics-edits-average' => 'Purata suntingan bagi setiap laman',
'statistics-views-total' => 'Jumlah pandangan',
'statistics-views-total-desc' => 'Paparan ke laman-laman yang tidak wujud dan laman-laman khas tidak disertakan',
'statistics-views-peredit' => 'Pandangan setiap suntingan',
'statistics-users' => '[[Special:ListUsers|Pengguna]] berdaftar',
'statistics-users-active' => 'Pengguna aktif',
'statistics-users-active-desc' => 'Pengguna yang aktif sejak {{PLURAL:$1|semalam|$1 hari lalu}}',
'statistics-mostpopular' => 'Laman dilihat terbanyak',

'pageswithprop' => 'Halaman dengan sifat halaman',
'pageswithprop-legend' => 'Halaman dengan sifat halaman',
'pageswithprop-text' => 'Halaman ini menyenaraikan halaman-halaman yang menggunakan sifat halaman yang tertentu.',
'pageswithprop-prop' => 'Nama sifat:',
'pageswithprop-submit' => 'Pergi',
'pageswithprop-prophidden-long' => 'nilai sifat teks panjang tersorok ($1)',
'pageswithprop-prophidden-binary' => 'nilai sifat binari tersorok ($1)',

'doubleredirects' => 'Lencongan berganda',
'doubleredirectstext' => 'Yang berikut ialah senarai laman yang melencong ke laman lencongan lain. Setiap baris mengandungi pautan ke laman lencongan pertama dan kedua, serta baris pertama bagi teks lencongan kedua, lazimnya merupakan laman sasaran "sebenar", yang sepatutnya ditujui oleh lencongan pertama.
Masukan yang <del>dipotong</del> telah diselesaikan.',
'double-redirect-fixed-move' => '[[$1]] dilencongkan ke [[$2]]',
'double-redirect-fixed-maintenance' => 'Membetulkan dwilecongan daripada [[$1]] kepada [[$2]].',
'double-redirect-fixer' => 'Pembaiki lencongan',

'brokenredirects' => 'Lencongan rosak',
'brokenredirectstext' => 'Lencongan-lencongan berikut menuju ke laman yang tidak wujud:',
'brokenredirects-edit' => 'sunting',
'brokenredirects-delete' => 'hapuskan',

'withoutinterwiki' => 'Laman tanpa pautan bahasa',
'withoutinterwiki-summary' => 'Laman-laman berikut tidak mempunyai pautan ke versi bahasa lain:',
'withoutinterwiki-legend' => 'Awalan',
'withoutinterwiki-submit' => 'Tunjukkan',

'fewestrevisions' => 'Laman dengan semakan tersedikit',

# Miscellaneous special pages
'nbytes' => '{{PLURAL:$1|$1 bait}}',
'ncategories' => '$1 kategori',
'ninterwikis' => '$1 pautan antara wiki',
'nlinks' => '$1 pautan',
'nmembers' => '$1 ahli',
'nrevisions' => '$1 semakan',
'nviews' => 'Dilihat $1 kali',
'nimagelinks' => 'Digunakan pada {{PLURAL:$1|sebuah|$1 buah}} laman',
'ntransclusions' => 'digunakan pada {{PLURAL:$1|sebuah|$1 buah}} laman',
'specialpage-empty' => 'Tiada keputusan bagi laporan ini.',
'lonelypages' => 'Laman yatim',
'lonelypagestext' => 'Laman-laman berikut tidak dipaut atau disertakan dari laman lain dalam {{SITENAME}}.',
'uncategorizedpages' => 'Laman tanpa kategori',
'uncategorizedcategories' => 'Kategori tanpa kategori',
'uncategorizedimages' => 'Imej tanpa kategori',
'uncategorizedtemplates' => 'Templat tanpa kategori',
'unusedcategories' => 'Kategori tidak digunakan',
'unusedimages' => 'Imej tidak digunakan',
'popularpages' => 'Laman popular',
'wantedcategories' => 'Kategori dikehendaki',
'wantedpages' => 'Laman dikehendaki',
'wantedpages-badtitle' => 'Tajuk tidak sah dalam set keputusan: $1',
'wantedfiles' => 'Fail dikehendaki',
'wantedfiletext-cat' => 'Fail-fail yang berikut digunakan tetapi tidak wujud. Fail-fail dari repositori asing mungkin tersenarai walaupun wujud. Sebarang positif palsu sedemikian akan <del>dipotong</del>. Begitu juga, laman-laman yang terbenam fail-fail yang tidak wujud adalah tersenarai dalam [[:$1]].',
'wantedfiletext-nocat' => 'Fail-fail yang berikut digunakan tetapi tidak wujud. Fail-fail dari repositori asing mungkin tersenarai walaupun wujud. Sebarang positif palsu sedemikian akan <del>dipotong</del>.',
'wantedtemplates' => 'Templat dikehendaki',
'mostlinked' => 'Laman dipaut terbanyak',
'mostlinkedcategories' => 'Kategori dipaut terbanyak',
'mostlinkedtemplates' => 'Templat dipaut terbanyak',
'mostcategories' => 'Rencana dengan kategori terbanyak',
'mostimages' => 'Imej dipaut terbanyak',
'mostinterwikis' => 'Halaman yang paling banyak pautan antara wiki',
'mostrevisions' => 'Rencana dengan semakan terbanyak',
'prefixindex' => 'Indeks awalan',
'prefixindex-namespace' => 'Semua laman dengan awalan (ruang nama $1)',
'prefixindex-strip' => 'Gugurkan awalan dalam senarai',
'shortpages' => 'Laman pendek',
'longpages' => 'Laman panjang',
'deadendpages' => 'Laman buntu',
'deadendpagestext' => 'Laman-laman berikut tidak mengandungi pautan ke laman lain di {{SITENAME}}.',
'protectedpages' => 'Laman dilindungi',
'protectedpages-indef' => 'Perlindungan tanpa had sahaja',
'protectedpages-cascade' => 'Perlindungan separa sahaja',
'protectedpagestext' => 'Laman-laman berikut dilindungi daripada pemindahan dan penyuntingan',
'protectedpagesempty' => 'Tiada laman yang dilindungi dengan kriteria ini.',
'protectedtitles' => 'Tajuk dilindungi',
'protectedtitlestext' => 'Tajuk-tajuk berikut dilindungi daripada dicipta',
'protectedtitlesempty' => 'Tiada tajuk yang dilindungi yang sepadan dengan kriteria yang diberikan.',
'listusers' => 'Senarai pengguna',
'listusers-editsonly' => 'Hanya papar pengguna yang telah membuat suntingan',
'listusers-creationsort' => 'Susun mengikut tarikh penciptaan',
'listusers-desc' => 'Susun dalam turutan menurun',
'usereditcount' => '$1 suntingan',
'usercreated' => '{{GENDER:$3|Dibuat}} pada $1, $2',
'newpages' => 'Laman baru',
'newpages-username' => 'Nama pengguna:',
'ancientpages' => 'Laman lapuk',
'move' => 'Pindahkan',
'movethispage' => 'Pindahkan laman ini',
'unusedimagestext' => 'Fail-fail berikut wujud tetapi tidak digunakan dalam mana-mana laman.
Sila ambil perhatian bahawa mungkin terdapat tapak web lain yang memaut ke fail ini menggunakan URL langsung, dan masih disenaraikan di sini walapun berada dalam kegunaan aktif.',
'unusedcategoriestext' => 'Laman-laman kategori berikut wujud walaupun tiada laman atau kategori lain menggunakannya.',
'notargettitle' => 'Tiada sasaran',
'notargettext' => 'Anda tidak menyatakan laman atau pengguna sebagai sasaran bagi tindakan ini.',
'nopagetitle' => 'Laman sasaran tidak wujud',
'nopagetext' => 'Laman sasaran yang anda nyatakan tidak wujud.',
'pager-newer-n' => '{{PLURAL:$1|$1 berikutnya}}',
'pager-older-n' => '{{PLURAL:$1|$1 sebelumnya}}',
'suppress' => 'Kawalan',
'querypage-disabled' => 'Laman khas ini dilumpuhkan atas sebab-sebab prestasi.',

# Book sources
'booksources' => 'Sumber buku',
'booksources-search-legend' => 'Cari sumber buku',
'booksources-go' => 'Pergi',
'booksources-text' => 'Yang berikut ialah senarai pautan ke tapak web lain yang menjual buku baru dan terpakai,
serta mungkin mempunyai maklumat lanjut mengenai buku yang anda cari:',
'booksources-invalid-isbn' => 'ISBN yang dinyatakan tidak sah. Sila semak sekali lagi.',

# Special:Log
'specialloguserlabel' => 'Pelaku:',
'speciallogtitlelabel' => 'Sasaran (tajuk atau pengguna):',
'log' => 'Log',
'all-logs-page' => 'Semua log awam',
'alllogstext' => 'Yang berikut ialah gabungan bagi semua log yang ada bagi {{SITENAME}}. Anda boleh menapis senarai ini dengan memilih jenis log, nama pengguna (peka huruf besar), atau nama laman yang terjejas (juga peka huruf besar).',
'logempty' => 'Tiada item yang sepadan dalam log.',
'log-title-wildcard' => 'Cari semua tajuk yang bermula dengan teks ini',
'showhideselectedlogentries' => 'Tunjukkan/sorokkan entri-entri log yang terpilih',

# Special:AllPages
'allpages' => 'Semua laman',
'alphaindexline' => '$1 hingga $2',
'nextpage' => 'Halaman berikutnya ($1)',
'prevpage' => 'Halaman sebelumnya ($1)',
'allpagesfrom' => 'Tunjukkan laman bermula pada:',
'allpagesto' => 'Tunjukkan laman berakhir pada:',
'allarticles' => 'Semua laman',
'allinnamespace' => 'Semua laman (ruang nama $1)',
'allnotinnamespace' => 'Semua laman (bukan dalam ruang nama $1)',
'allpagesprev' => 'Sebelumnya',
'allpagesnext' => 'Berikutnya',
'allpagessubmit' => 'Pergi',
'allpagesprefix' => 'Tunjukkan laman dengan awalan:',
'allpagesbadtitle' => 'Tajuk laman yang dinyatakan tidak sah atau mempunyai awalam antara bahasa atau antara wiki. Ia mungkin mengandungi aksara yang tidak boleh digunakan dalam tajuk laman.',
'allpages-bad-ns' => '{{SITENAME}} tidak mempunyai ruang nama "$1".',
'allpages-hide-redirects' => 'Sorokkan lencongan',

# SpecialCachedPage
'cachedspecial-viewing-cached-ttl' => 'Anda sedang melihat versi dalam cache laman ini yang mungkin selama $1.',
'cachedspecial-viewing-cached-ts' => 'Anda sedang melihat versi dalam cache laman ini yang mungkin tidak lengkap sepenuhnya.',
'cachedspecial-refresh-now' => 'Lihat yang terkini.',

# Special:Categories
'categories' => 'Kategori',
'categoriespagetext' => '{{PLURAL:$1|Kategori|Kategori-kategori}} berikut mengandungi laman-laman atau media.
[[Special:UnusedCategories|Kategori yang tidak digunakan]] tidak dipaparkan di sini.
Lihat juga [[Special:WantedCategories|kategori yang dikehendaki]].',
'categoriesfrom' => 'Paparkan kategori bermula daripada:',
'special-categories-sort-count' => 'susun mengikut tertib bilangan',
'special-categories-sort-abc' => 'susun mengikut tertib abjad',

# Special:DeletedContributions
'deletedcontributions' => 'Sumbangan dihapuskan',
'deletedcontributions-title' => 'Sumbangan dihapuskan',
'sp-deletedcontributions-contribs' => 'sumbangan',

# Special:LinkSearch
'linksearch' => 'Carian pautan luar',
'linksearch-pat' => 'Corak carian:',
'linksearch-ns' => 'Ruang nama:',
'linksearch-ok' => 'Cari',
'linksearch-text' => 'Kad bebas seperti "*.wikipedia.org" dibenarkan.<br />
Memerlukan sekurang-kurangnya satu domain peringkat tinggi, cth. "*.org".<br />
{{PLURAL:$2|Protokol|Protokol-protokol}} yang disokong: <code>$1</code> (menjadi http:// jika tiada protokol dinyatakan).',
'linksearch-line' => '$1 dipaut dari $2',
'linksearch-error' => 'Kad bebas hanya boleh digunakan pada permulaan nama hos.',

# Special:ListUsers
'listusersfrom' => 'Tunjukkan pengguna bermula pada:',
'listusers-submit' => 'Tunjukkan',
'listusers-noresult' => 'Tiada pengguna dijumpai.',
'listusers-blocked' => '(disekat)',

# Special:ActiveUsers
'activeusers' => 'Senarai pengguna aktif',
'activeusers-intro' => 'Yang berikut ialah senarai pengguna yang bergiat sejak {{PLURAL:$1|semalam|$1 hari lalu}}.',
'activeusers-count' => '$1 tindakan sejak {{PLURAL:$3|semalam|$3 hari lalu}}',
'activeusers-from' => 'Tunjukkan pengguna bermula pada:',
'activeusers-hidebots' => 'Sorokkan bot',
'activeusers-hidesysops' => 'Sorokkan pentadbir',
'activeusers-noresult' => 'Tiada pengguna dijumpai.',

# Special:ListGroupRights
'listgrouprights' => 'Hak kumpulan pengguna',
'listgrouprights-summary' => 'Yang berikut ialah senarai kumpulan pengguna yang ditubuhkan di wiki ini dengan hak-hak masing-masing.
Anda boleh mengetahui [[{{MediaWiki:Listgrouprights-helppage}}|maklumat tambahan]] mengenai setiap hak.',
'listgrouprights-key' => 'Petunjuk:
* <span class="listgrouprights-granted">Hak ditunaikan</span>
* <span class="listgrouprights-revoked">Hak dibatalkan</span>',
'listgrouprights-group' => 'Kumpulan',
'listgrouprights-rights' => 'Hak',
'listgrouprights-helppage' => 'Help:Hak kumpulan',
'listgrouprights-members' => '(senarai ahli)',
'listgrouprights-addgroup' => 'Menambahkan {{PLURAL:$2|kumpulan|kumpulan}}: $1',
'listgrouprights-removegroup' => 'Membuang {{PLURAL:$2|kumpulan|kumpulan}}: $1',
'listgrouprights-addgroup-all' => 'Menambahkan semua kumpulan',
'listgrouprights-removegroup-all' => 'Membuang semua kumpulan',
'listgrouprights-addgroup-self' => 'Menyertai {{PLURAL:$2|kumpulan|kumpulan-kumpulan}}: $1',
'listgrouprights-removegroup-self' => 'Keluar daripada {{PLURAL:$2|kumpulan|kumpulan-kumpulan}}: $1',
'listgrouprights-addgroup-self-all' => 'Menyertai semua kumpulan',
'listgrouprights-removegroup-self-all' => 'Keluar daripada semua kumpulan',

# Email user
'mailnologin' => 'Tiada alamat e-mel',
'mailnologintext' => 'Anda perlu [[Special:UserLogin|log masuk]]
terlebih dahulu dan mempunyai alamat e-mel yang sah dalam
[[Special:Preferences|laman keutamaan]] untuk mengirim e-mel kepada pengguna lain.',
'emailuser' => 'Kirim e-mel kepada pengguna ini',
'emailuser-title-target' => 'E-mel {{GENDER:$1|pengguna}} ini',
'emailuser-title-notarget' => 'E-mel pengguna',
'emailpage' => 'E-mel pengguna',
'emailpagetext' => 'Gunakan borang berikut untuk mengirim pesanan e-mel kepada {{GENDER:$1|pengguna}} ini.

Alamat e-mel yang ditetapkan dalam [[Special:Preferences|keutamaan anda]] akan digunakan sebagai alamat "Daripada" dalam e-mel tersebut supaya si penerima boleh membalasnya.',
'usermailererror' => 'Objek Mail memulangkan ralat:',
'defemailsubject' => 'E-mel {{SITENAME}} daripada pengguna "$1"',
'usermaildisabled' => 'E-mel pengguna telah dilumpuhkan',
'usermaildisabledtext' => 'Anda tidak boleh mengirim e-mel kepada pengguna lain di wiki ini',
'noemailtitle' => 'Tiada alamat e-mel',
'noemailtext' => 'Pengguna ini tidak menetapkan alamat e-mel yang sah.',
'nowikiemailtitle' => 'E-mel tidak dibenarkan',
'nowikiemailtext' => 'Pengguna ini tidak mahu menerima e-mel daripada pengguna lain.',
'emailnotarget' => 'Nama pengguna penerima tidak wujud atau tidak sah.',
'emailtarget' => 'Isikan nama pengguna penerima',
'emailusername' => 'Nama pengguna:',
'emailusernamesubmit' => 'Hantar',
'email-legend' => 'Kirim e-mel kepada pengguna {{SITENAME}} lain',
'emailfrom' => 'Daripada:',
'emailto' => 'Kepada:',
'emailsubject' => 'Perkara:',
'emailmessage' => 'Pesanan:',
'emailsend' => 'Kirim',
'emailccme' => 'Kirim salinan mesej ini kepada saya.',
'emailccsubject' => 'Salinan bagi mesej anda kepada $1: $2',
'emailsent' => 'E-mel dikirim',
'emailsenttext' => 'E-mel anda telah dikirim.',
'emailuserfooter' => 'E-mel ini telah dikirim oleh $1 kepada $2 menggunakan alat "E-mel pengguna" di {{SITENAME}}.',

# User Messenger
'usermessage-summary' => 'Meninggalkan pesanan sistem.',
'usermessage-editor' => 'Utusan sistem',

# Watchlist
'watchlist' => 'Senarai pantau',
'mywatchlist' => 'Senarai pantau',
'watchlistfor2' => 'Bagi $1 $2',
'nowatchlist' => 'Tiada item dalam senarai pantau anda.',
'watchlistanontext' => 'Sila $1 terlebih dahulu untuk melihat atau menyunting senarai pantau anda.',
'watchnologin' => 'Belum log masuk',
'watchnologintext' => 'Anda mesti [[Special:UserLogin|log masuk]] terlebih dahulu untuk mengubah senarai pantau.',
'addwatch' => 'Tambahkan ke senarai pantau',
'addedwatchtext' => 'Halaman "[[:$1]]" telah dimasukkan ke dalam [[Special:Watchlist|senarai pantau anda]].
Perubahan-perubahan pada halaman ini dan halaman perbualannya pada masa akan datang akan tersenarai di dalam senarai itu.',
'removewatch' => 'Buang dari senarai pantau',
'removedwatchtext' => 'Laman "[[:$1]]" telah dibuang daripada [[Special:Watchlist|senarai pantau anda]].',
'watch' => 'Pantau',
'watchthispage' => 'Pantau laman ini',
'unwatch' => 'Nyahpantau',
'unwatchthispage' => 'Berhenti memantau',
'notanarticle' => 'Bukan laman kandungan',
'notvisiblerev' => 'Semakan ini telah dihapuskan',
'watchlist-details' => '$1 laman dipantau (tidak termasuk laman perbincangan).',
'wlheader-enotif' => 'Pemberitahuan melalui e-mel dibolehkan.',
'wlheader-showupdated' => "Laman-laman yang telah diubah sejak kunjungan terakhir anda dipaparkan dalam '''teks tebal'''.",
'watchmethod-recent' => 'menyemak laman yang dipantau dalam suntingan-suntingan terkini',
'watchmethod-list' => 'menyemak suntingan terkini pada laman-laman yang dipantau',
'watchlistcontains' => 'Terdapat $1 laman dalam senarai pantau anda.',
'iteminvalidname' => "Terdapat masalah dengan item '$1', nama tidak sah...",
'wlnote' => "Berikut ialah {{PLURAL:$1|perubahan|'''$1''' perubahan}} yang terkini dalam {{PLURAL:$2|sejam|'''$2''' jam}} yang lalu, tepat pada $3, $4.",
'wlshowlast' => 'Tunjukkan $1 jam / $2 hari yang lalu / $3.',
'watchlist-options' => 'Pilihan senarai pantau',

# Displayed when you click the "watch" button and it is in the process of watching
'watching' => 'Memantau...',
'unwatching' => 'Menyahpantau...',
'watcherrortext' => 'Ralat berlaku ketika menukar tetapan senarai pantau anda untuk "$1".',

'enotif_mailer' => 'Sistem Pemberitahuan {{SITENAME}}',
'enotif_reset' => 'Tandakan semua laman sebagai telah dikunjungi',
'enotif_impersonal_salutation' => 'Pengguna {{SITENAME}}',
'enotif_subject_deleted' => 'Halaman $1 di {{SITENAME}} telah dihapuskan oleh {{gender:$2|$2}}',
'enotif_subject_created' => 'Halaman $1 di {{SITENAME}} telah diwujudkan oleh {{gender:$2|$2}}',
'enotif_subject_moved' => 'Halaman $1 di {{SITENAME}} telah dipindahkan oleh {{gender:$2|$2}}',
'enotif_subject_restored' => 'Halaman $1 di {{SITENAME}} telah dipulihkan oleh {{gender:$2|$2}}',
'enotif_subject_changed' => 'Halaman $1 di {{SITENAME}} telah disunting oleh {{gender:$2|$2}}',
'enotif_body_intro_deleted' => 'Halaman $1 di {{SITENAME}} telah dihapuskan oleh {{gender:$2|$2}} pada $PAGEEDITDATE, sila rujuk $3.',
'enotif_body_intro_created' => 'Halaman $1 di {{SITENAME}} telah diwujudkan oleh {{gender:$2|$2}} pada $PAGEEDITDATE, sila rujuk $3 untuk semakan terkini.',
'enotif_body_intro_moved' => 'Halaman $1 di {{SITENAME}} telah dipindahkan oleh {{gender:$2|$2}} pada $PAGEEDITDATE, sila rujuk $3 untuk semakan terkini.',
'enotif_body_intro_restored' => 'Halaman $1 di {{SITENAME}} telah dipulihkan oleh {{gender:$2|$2}} pada $PAGEEDITDATE, sila rujuk $3 untuk semakan terkini.',
'enotif_body_intro_changed' => 'Halaman $1 di {{SITENAME}} telah disunting oleh {{gender:$2|$2}} pada $PAGEEDITDATE, sila rujuk $3 untuk semakan terkini.',
'enotif_lastvisited' => 'Lihat $1 untuk semua perubahan sejak kunjungan terakhir anda.',
'enotif_lastdiff' => 'Rujuk $1 untuk melihat perubahan ini.',
'enotif_anon_editor' => 'pengguna tanpa nama $1',
'enotif_body' => '$WATCHINGUSERNAME,

$PAGEINTRO $NEWPAGE

Ringkasan penyunting: $PAGESUMMARY $PAGEMINOREDIT

Hubungi penyunting:
mel: $PAGEEDITOR_EMAIL
wiki: $PAGEEDITOR_WIKI

Tiada lagi pemberitahuan lanjut sekiranya terdapat suntingan selanjutnya melainkan anda mengunjungi halaman berkenaan. Anda juga boleh menetapkan semula tanda-tanda pemberitahuan untuk kesemua halaman dalam senarai pantau anda.

			 Sistem pemberitahuan {{SITENAME}} yang mesra

--
Untuk mengubah tetapan pemberitahuan melalui e-mel anda, kunjungi
{{canonicalurl:{{#special:Preferences}}}}

Untuk mengubah tetapan senarai pantau anda, kunjungi
{{canonicalurl:{{#special:EditWatchlist}}}}

Untuk menggugurkan halaman ini daripada senarai pantau anda, kunjungi
$UNWATCHURL

Maklum balas dan bantuan selanjutnya:
{{canonicalurl:{{MediaWiki:Helppage}}}}',
'created' => 'dicipta',
'changed' => 'diubah',

# Delete
'deletepage' => 'Hapus laman',
'confirm' => 'Sahkan',
'excontent' => "kandungan: '$1'",
'excontentauthor' => "Kandungan: '$1' (dan satu-satunya penyumbang ialah '[[Special:Contributions/$2|$2]]')",
'exbeforeblank' => "kandungan sebelum pengosongan ialah: '$1'",
'exblank' => 'laman tersebut kosong',
'delete-confirm' => 'Hapus "$1"',
'delete-legend' => 'Hapuskan',
'historywarning' => "'''Amaran:''' Laman yang ingin anda hapuskan mengandungi sejarah dengan kira-kira $1 {{PLURAL:$1|semakan|semakan}}:",
'confirmdeletetext' => 'Anda sudah hendak menghapuskan sebuah laman berserta semua sejarahnya.
Sila sahkan bahawa anda memang hendak berbuat demikian, anda faham akan
akibatnya, dan perbuatan anda mematuhi [[{{MediaWiki:Policy-url}}|dasar kami]].',
'actioncomplete' => 'Tindakan berjaya',
'actionfailed' => 'Tindakan gagal',
'deletedtext' => '"$1" telah dihapuskan.
Sila lihat $2 untuk rekod penghapusan terkini.',
'dellogpage' => 'Log penghapusan',
'dellogpagetext' => 'Yang berikut ialah senarai penghapusan terkini.',
'deletionlog' => 'log penghapusan',
'reverted' => 'Dibalikkan kepada semakan sebelumnya',
'deletecomment' => 'Sebab:',
'deleteotherreason' => 'Sebab lain/tambahan:',
'deletereasonotherlist' => 'Sebab lain',
'deletereason-dropdown' => '* Sebab-sebab lazim
** Permintaan pengarang
** Melanggar hak cipta
** Vandalisme',
'delete-edit-reasonlist' => 'Ubah sebab-sebab hapus',
'delete-toobig' => 'Laman ini mempunyai sejarah yang besar, iaitu melebihi $1 jumlah semakan. Oleh itu, laman ini dilindungi daripada dihapuskan untuk mengelak kerosakan di {{SITENAME}} yang tidak disengajakan.',
'delete-warning-toobig' => 'Laman ini mempunyai sejarah yang besar, iaitu melebihi $1 jumlah semakan. Menghapuskannya boleh mengganggu perjalanan pangkalan data {{SITENAME}}. Sila berhati-hati.',

# Rollback
'rollback' => 'Undurkan suntingan.',
'rollback_short' => 'Undur',
'rollbacklink' => 'undur',
'rollbacklinkcount' => 'mengundurkan $1 {{PLURAL:$1|suntingan}}',
'rollbacklinkcount-morethan' => 'mengundurkan lebih daripada $1 {{PLURAL:$1|suntingan}}',
'rollbackfailed' => 'Pengunduran gagal',
'cantrollback' => 'Suntingan tersebut tidak dapat dibalikkan: penyumbang terakhir adalah satu-satunya pengarang bagi rencana ini.',
'alreadyrolled' => 'Suntingan terakhir bagi [[:$1]] oleh [[User:$2|$2]] ([[User talk:$2|Perbualan]]{{int:pipe-separator}}[[Special:Contributions/$2|{{int:contribslink}}]]) tidak dapat dibalikkan; terdapat pengguna lain yang telah menyunting atau membalikkan laman itu.

Suntingan terakhir telah dibuat oleh [[User:$3|$3]] ([[User talk:$3|Perbualan]]{{int:pipe-separator}}[[Special:Contributions/$3|{{int:contribslink}}]]).',
'editcomment' => "Ringkasan sutingan: \"''\$1''\".",
'revertpage' => 'Membalikkan suntingan oleh [[Special:Contributions/$2|$2]] ([[User talk:$2|Perbincangan]]) kepada versi terakhir oleh [[User:$1|$1]]',
'revertpage-nouser' => 'Membalikkan suntingan oleh seorang pengguna tersorok kepada semakan terakhir oleh {{GENDER:$1|[[User:$1|$1]]}}',
'rollback-success' => 'Membalikkan suntingan oleh $1 kepada versi terakhir oleh $2.',

# Edit tokens
'sessionfailure-title' => 'Kegagalan sesi',
'sessionfailure' => 'Terdapat sedikit masalah pada sesi log masuk anda.
Tindakan ini telah dibatalkan untuk mencegah perampasan sesi.
Sila tekan butang "back" dan muatkan semula laman yang telah anda kunjungi sebelum ini, kemudian cuba lagi.',

# Protect
'protectlogpage' => 'Log perlindungan',
'protectlogtext' => 'Berikut ialah senarai perubahan pada perlindungan laman.
Lihat [[Special:ProtectedPages|senarai laman terlindung]] untuk senarai laman-laman yang sedang dilindungi.',
'protectedarticle' => 'melindungi "[[$1]]"',
'modifiedarticleprotection' => 'menukar peringkat perlindungan bagi "[[$1]]"',
'unprotectedarticle' => '"[[$1]]" digugurkan perlindungannya',
'movedarticleprotection' => 'memindahkan tetapan perlindungan dari "[[$2]]" ke "[[$1]]"',
'protect-title' => 'Ubah tahap perlindungan bagi "$1"',
'protect-title-notallowed' => 'Lihat tahap perlindungan bagi "$1"',
'prot_1movedto2' => '[[$1]] dipindahkan ke [[$2]]',
'protect-badnamespace-title' => 'Ruang nama yang tidak boleh dilindungi',
'protect-badnamespace-text' => 'Laman-laman dalam ruang nama ini tidak boleh dilindungi.',
'protect-norestrictiontypes-text' => 'Halaman ini tidak boleh dilindungi kerana tiadanya jenis-jenis sekatan yang disediakan.',
'protect-norestrictiontypes-title' => 'Halaman tak terlindung',
'protect-legend' => 'Sahkan perlindungan',
'protectcomment' => 'Sebab:',
'protectexpiry' => 'Sehingga:',
'protect_expiry_invalid' => 'Waktu tamat tidak sah.',
'protect_expiry_old' => 'Waktu tamat telah berlalu.',
'protect-unchain-permissions' => 'Aktifkan pilihan perlindungan selanjutnya',
'protect-text' => "Anda boleh melihat dan menukar peringkat perlindungan bagi laman '''$1'''.",
'protect-locked-blocked' => "Anda telah disekat, justeru tidak boleh menukar peringkat perlindungan.
Ini adalah tetapan semasa bagi laman '''$1''':",
'protect-locked-dblock' => "Anda tidak boleh menukar peringkat perlindungan kerana pangkalan data sedang dikunci.
Ini adalah tetapan semasa bagi laman '''$1''':",
'protect-locked-access' => "Anda tidak mempunyai keizinan untuk menukar peringkat perlindungan.
Ini adalah tetapan semasa bagi laman '''$1''':",
'protect-cascadeon' => 'Laman ini dilindungi kerana ia terkandung dalam {{PLURAL:$1|laman|laman-laman}} berikut, yang dilindungi secara melata. Anda boleh menukar peringkat perlindunan laman ini, akan tetapi ia tidak akan menjejaskan perlindungan melata tersebut.',
'protect-default' => 'Benarkan semua pengguna',
'protect-fallback' => 'Benarkan pengguna yang berizin "$1" sahaja',
'protect-level-autoconfirmed' => 'Benarkan pengguna yang diautosahkan sahaja',
'protect-level-sysop' => 'Benarkan pentadbir sahaja',
'protect-summary-cascade' => 'melata',
'protect-expiring' => 'sehingga $1 (UTC)',
'protect-expiring-local' => 'luput $1',
'protect-expiry-indefinite' => 'tak terbatas',
'protect-cascade' => 'Lindungi semua laman yang terkandung dalam laman ini (perlindungan melata)',
'protect-cantedit' => 'Anda tidak dibenarkan menukar peringkat perlindungan bagi laman ini.',
'protect-othertime' => 'Waktu lain:',
'protect-othertime-op' => 'waktu lain',
'protect-existing-expiry' => 'Waktu tamat yang telah ditetapkan: $2, $3',
'protect-otherreason' => 'Sebab lain/tambahan:',
'protect-otherreason-op' => 'Sebab lain',
'protect-dropdown' => '*Sebab lazim
** Laku musnah berlebihan
** Spam berlebihan
** Perang sunting yang tidak membina
** Laman yang terlalu ramai pelawat',
'protect-edit-reasonlist' => 'Ubah sebab-sebab perlindungan',
'protect-expiry-options' => '1 jam:1 hour,1 hari:1 day,1 minggu:1 week,2 minggu:2 weeks,1 bulan:1 month,3 bulan:3 months,6 bulan:6 months,1 tahun:1 year,selama-lamanya:infinite',
'restriction-type' => 'Keizinan:',
'restriction-level' => 'Peringkat pembatasan:',
'minimum-size' => 'Saiz minimum',
'maximum-size' => 'Saiz maksimum',
'pagesize' => '(bait)',

# Restrictions (nouns)
'restriction-edit' => 'Sunting',
'restriction-move' => 'Pindahkan',
'restriction-create' => 'Cipta',
'restriction-upload' => 'Muat naik',

# Restriction levels
'restriction-level-sysop' => 'perlindungan penuh',
'restriction-level-autoconfirmed' => 'perlindungan separa',
'restriction-level-all' => 'semua peringkat',

# Undelete
'undelete' => 'Lihat laman yang dihapuskan',
'undeletepage' => 'Lihat dan pulihkan laman yang dihapuskan',
'undeletepagetitle' => "'''Yang berikut ialah semakan-semakan [[:$1|$1]] yang telah dihapuskan'''.",
'viewdeletedpage' => 'Lihat laman yang dihapuskan',
'undeletepagetext' => '{{PLURAL:$1|Laman|$1 laman}} berikut telah dihapuskan tetapi masih disimpan dalam arkib dan masih boleh dipulihkan. Arkib tersebut akan dibersihkan dari semasa ke semasa.',
'undelete-fieldset-title' => 'Pulihkan semakan',
'undeleteextrahelp' => "Untuk memulihkan keseluruhan sejarah laman, biarkan semua kotak semak tak tertanda dan klik '''''{{int:undeletebtn}}'''''. Untuk melaksanakan pemulihan tertentu, tandai setiap kotak yang bersebelahan dengan semakan untuk dipulihkan dan klik '''''{{int:undeletebtn}}'''''.",
'undeleterevisions' => '$1 semakan telah diarkibkan.',
'undeletehistory' => 'Jika anda memulihkan laman tersebut, semua semakan akan dipulihkan kepada sejarahnya. Jika sebuah laman baru yang mempunyai nama yang sama telah dicipta sejak penghapusan, semakan yang dipulihkan akan muncul dalam sejarah terdahulu.',
'undeleterevdel' => 'Penyahhapusan tidak akan dilaksanakan sekiranya ia menyebabkan sebahagian semakan puncak dihapuskan.
Dalam hal tersebut, anda perlu membuang semak atau menyemak semakan yang baru dihapuskan. Semakan fail
yang anda tidak dibenarkan melihatnya tidak akan dipulihkan.',
'undeletehistorynoadmin' => 'Rencana ini telah dihapuskan. Sebab penghapusan
ditunjukkan dalam ringkasan di bawah, berserta butiran bagi pengguna-pengguna yang telah menyunting laman ini
sebelum penghapusan. Teks sebenar bagi semua semakan yang dihapuskan hanya boleh dilihat oleh para pentadbir.',
'undelete-revision' => 'Menghapuskan semakan bagi $1 (pada $4, $5) oleh $3:',
'undeleterevision-missing' => 'Semakan tersebut tidak sah atau tidak dijumpai. Mungkin anda telah mengikuti pautan yang rosak
atau semakan tersebut telah dipulihkan atau dibuang daripada arkib.',
'undelete-nodiff' => 'Tiada semakan sebelumnya.',
'undeletebtn' => 'Pulihkan',
'undeletelink' => 'lihat/pulihkan',
'undeleteviewlink' => 'papar',
'undeletereset' => 'Set semula',
'undeleteinvert' => 'Kecualikan pilihan',
'undeletecomment' => 'Sebab:',
'undeletedrevisions' => '$1 semakan dipulihkan',
'undeletedrevisions-files' => '$1 semakan dan $2 fail dipulihkan',
'undeletedfiles' => '$1 fail dipulihkan',
'cannotundelete' => 'Penyahhapusan gagal: $1',
'undeletedpage' => "'''$1 telah dipulihkan'''

Sila rujuk [[Special:Log/delete|log penghapusan]] untuk rekod penghapusan terkini.",
'undelete-header' => 'Lihat [[Special:Log/delete|log penghapusan]] untuk laman-laman yang baru dihapuskan.',
'undelete-search-title' => 'Cari laman yang dihapuskan',
'undelete-search-box' => 'Cari laman yang dihapuskan',
'undelete-search-prefix' => 'Tunjukkan laman bermula dengan:',
'undelete-search-submit' => 'Cari',
'undelete-no-results' => 'Tiada laman yang sepadan dijumpai dalam arkib penghapusan.',
'undelete-filename-mismatch' => 'Semakan pada $1 tidak boleh dinyahhapuskan: nama fail tidak sepadan',
'undelete-bad-store-key' => 'Semakan pada $1 tidak boleh dinyahhapuskan: fail telah hilang.',
'undelete-cleanup-error' => 'Ralat ketika menyahhhapuskan fail "$1" dalam arkib yang tidak digunakan.',
'undelete-missing-filearchive' => 'Arkib fail dengan ID $1 tidak dapat dipulihkan kerana tiada dalam pangkalan data. Ia mungkin telah pun dinyahhapuskan.',
'undelete-error' => 'Ralat ketika menyahhapuskan laman',
'undelete-error-short' => 'Ralat ketika menyahhapuskan fail: $1',
'undelete-error-long' => 'Berlaku ralat ketika menyahhapuskan fail tersebut:

$1',
'undelete-show-file-confirm' => 'Betul anda mahu melihat semakan bagi fail "<nowiki>$1</nowiki>" yang telah dihapuskan pada $2, $3?',
'undelete-show-file-submit' => 'Ya',

# Namespace form on various pages
'namespace' => 'Ruang nama:',
'invert' => 'Kecualikan pilihan',
'tooltip-invert' => 'Tandai kotak ini untuk menyorokkan perubahan dalam ruang nama yang dipilih (dan ruang nama yang berkaitan jika ditandai)',
'namespace_association' => 'Ruang nama berkaitan',
'tooltip-namespace_association' => 'Tandai kotak ini untuk turut menyertakan ruang nama perbincangan atau subjek yang dikaitkan dengan ruang nama terpilih',
'blanknamespace' => '(Utama)',

# Contributions
'contributions' => 'Sumbangan {{GENDER:$1|pengguna}}',
'contributions-title' => 'Sumbangan oleh $1',
'mycontris' => 'Sumbangan',
'contribsub2' => 'Oleh $1 ($2)',
'nocontribs' => 'Tiada sebarang perubahan yang sepadan dengan kriteria-kriteria ini.',
'uctop' => '(terkini)',
'month' => 'Sebelum bulan:',
'year' => 'Sebelum tahun:',

'sp-contributions-newbies' => 'Tunjukkan sumbangan daripada akaun baru sahaja',
'sp-contributions-newbies-sub' => 'Bagi akaun-akaun baru',
'sp-contributions-newbies-title' => 'Sumbangan oleh pengguna baru',
'sp-contributions-blocklog' => 'Log sekatan',
'sp-contributions-deleted' => 'sumbangan dihapuskan',
'sp-contributions-uploads' => 'muat naik',
'sp-contributions-logs' => 'log',
'sp-contributions-talk' => 'perbincangan',
'sp-contributions-userrights' => 'pengurusan hak pengguna',
'sp-contributions-blocked-notice' => 'Pengguna ini sedang disekat. Masukan log sekatan terakhir disediakan di bawah sebagai rujukan:',
'sp-contributions-blocked-notice-anon' => 'Alamat IP ini sedang disekat. Masukan log sekatan terakhir disediakan di bawah sebagai rujukan:',
'sp-contributions-search' => 'Cari sumbangan',
'sp-contributions-username' => 'Alamat IP atau nama pengguna:',
'sp-contributions-toponly' => 'Hanya paparkan suntingan yang merupakan semakan terkini',
'sp-contributions-submit' => 'Cari',

# What links here
'whatlinkshere' => 'Pautan ke laman ini',
'whatlinkshere-title' => 'Laman yang mengandungi pautan ke "$1"',
'whatlinkshere-page' => 'Laman:',
'linkshere' => "Laman-laman berikut mengandungi pautan ke '''[[:$1]]''':",
'nolinkshere' => "Tiada laman yang mengandungi pautan ke '''[[:$1]]'''.",
'nolinkshere-ns' => "Tiada laman yang mengandungi pautan ke '''[[:$1]]''' dalam ruang nama yang dinyatakan.",
'isredirect' => 'laman lencongan',
'istemplate' => 'penyertaan',
'isimage' => 'pautan fail',
'whatlinkshere-prev' => '{{PLURAL:$1|sebelumnya|$1 sebelumnya}}',
'whatlinkshere-next' => '{{PLURAL:$1|berikutnya|$1 berikutnya}}',
'whatlinkshere-links' => '← pautan',
'whatlinkshere-hideredirs' => '$1 pelencongan',
'whatlinkshere-hidetrans' => '$1 penyertaan',
'whatlinkshere-hidelinks' => '$1 pautan',
'whatlinkshere-hideimages' => '$1 pautan fail',
'whatlinkshere-filters' => 'Penapis',

# Block/unblock
'autoblockid' => 'Sekat #$1 secara automatik',
'block' => 'Sekat pengguna',
'unblock' => 'Nyahsekat pengguna',
'blockip' => 'Sekat pengguna',
'blockip-title' => 'Sekat pengguna',
'blockip-legend' => 'Sekat pengguna',
'blockiptext' => 'Gunakan borang di bawah untuk menyekat
penyuntingan daripada alamat IP atau pengguna tertentu.
Tindakan ini perlu dilakukan untuk menentang vandalisme sahaja dan selaras
dengan [[{{MediaWiki:Policy-url}}|dasar {{SITENAME}}]].
Sila masukkan sebab sekatan di bawah (umpamannya, sebutkan laman yang telah
dirosakkan).',
'ipadressorusername' => 'Alamat IP atau nama pengguna:',
'ipbexpiry' => 'Tamat:',
'ipbreason' => 'Sebab:',
'ipbreasonotherlist' => 'Lain-lain',
'ipbreason-dropdown' => '*Sebab lazim
** Memasukkan maklumat palsu
** Membuang kandungan daripada laman
** Memasukkan pautan spam ke tapak web luar
** Memasukkan karut-marut ke dalam laman
** Mengugut/mengganggu pengguna lain
** Menyalahgunakan berbilang akaun
** Nama pengguna yang tidak sesuai',
'ipb-hardblock' => 'Cegah pengguna yang sudah log masuk daripada menyunting dari alamat IP ini',
'ipbcreateaccount' => 'Tegah pembukaan akaun',
'ipbemailban' => 'Halang pengguna tersebut daripada mengirim e-mel',
'ipbenableautoblock' => 'Sekat alamat IP terakhir dan mana-mana alamat berikutnya yang digunakan oleh pengguna ini secara automatik',
'ipbsubmit' => 'Sekat pengguna ini',
'ipbother' => 'Waktu lain:',
'ipboptions' => '2 jam:2 hours,1 hari:1 day,3 hari:3 days,1 minggu:1 week,2 minggu:2 weeks,1 bulan:1 month,3 bulan:3 months,6 bulan:6 months,1 tahun:1 year,selama-lamanya:infinite',
'ipbotheroption' => 'lain',
'ipbotherreason' => 'Sebab tambahan/lain:',
'ipbhidename' => 'Sembunyikan nama pengguna daripada senarai suntingan dan pengguna',
'ipbwatchuser' => 'Pantau laman pengguna dan laman perbincangan bagi pengguna ini',
'ipb-disableusertalk' => 'Halang pengguna ini daripada menyunting laman perbincangan sendiri apabila disekat',
'ipb-change-block' => 'Sekat semula pengguna tersebut dengan tetapan ini',
'ipb-confirm' => 'Sahkan sekatan',
'badipaddress' => 'Alamat IP tidak sah',
'blockipsuccesssub' => 'Sekatan berjaya',
'blockipsuccesstext' => '[[Special:Contributions/$1|$1]] telah disekat.
<br />Sila lihat [[Special:BlockList|senarai sekatan]] untuk menyemak sekatan.',
'ipb-blockingself' => 'Anda akan menyekat diri sendiri! Pastikah anda mahu berbuat demikian?',
'ipb-confirmhideuser' => 'Anda akan menyekat seorang pengguna yang menghidupkan "sorokkan pengguna". Ini akan menindaskan nama pengguna itu di semua senarai dan entri log. Pastikah anda mahu berbuat demikian?',
'ipb-edit-dropdown' => 'Sunting sebab sekatan',
'ipb-unblock-addr' => 'Nyahsekat $1',
'ipb-unblock' => 'Nyahsekat nama pengguna atau alamat IP',
'ipb-blocklist' => 'Lihat sekatan sedia ada',
'ipb-blocklist-contribs' => 'Sumbangan oleh $1',
'unblockip' => 'Nyahsekat pengguna',
'unblockiptext' => 'Gunakan borang di bawah untuk membuang sekatan bagialamat IP atau nama pengguna yang telah disekat.',
'ipusubmit' => 'Tarik balik sekatan ini',
'unblocked' => '[[User:$1|$1]] telah dinyahsekat',
'unblocked-range' => '$1 telah dinyahsekat',
'unblocked-id' => 'Sekatan $1 telah dibuang',
'blocklist' => 'Pengguna yang disekat',
'ipblocklist' => 'Alamat IP dan nama pengguna yang disekat',
'ipblocklist-legend' => 'Cari pengguna yang disekat',
'blocklist-userblocks' => 'Sorokkan sekatan akaun',
'blocklist-tempblocks' => 'Sorokkan sekatan sementara',
'blocklist-addressblocks' => 'Sorokkan sekatan IP tunggal',
'blocklist-rangeblocks' => 'Sorokkan sekatan julat',
'blocklist-timestamp' => 'Cop masa',
'blocklist-target' => 'Sasaran',
'blocklist-expiry' => 'Luput',
'blocklist-by' => 'Pentadbir sekatan',
'blocklist-params' => 'Parameter sekatan',
'blocklist-reason' => 'Sebab',
'ipblocklist-submit' => 'Cari',
'ipblocklist-localblock' => 'Sekatan tempatan',
'ipblocklist-otherblocks' => '{{PLURAL:$1|Sekatan|Sekatan-sekatan}} lain',
'infiniteblock' => 'selama-lamanya',
'expiringblock' => 'sehingga $1, $2',
'anononlyblock' => 'pengguna tanpa nama sahaja',
'noautoblockblock' => 'sekatan automatik dipadamkan',
'createaccountblock' => 'pembukaan akaun baru disekat',
'emailblock' => 'e-mail disekat',
'blocklist-nousertalk' => 'tidak boleh menyunting laman perbincangan sendiri',
'ipblocklist-empty' => 'Senarai sekatan adalah kosong.',
'ipblocklist-no-results' => 'Alamat IP atau nama pengguna tersebut tidak disekat.',
'blocklink' => 'sekat',
'unblocklink' => 'nyahsekat',
'change-blocklink' => 'ubah sekatan',
'contribslink' => 'sumb.',
'emaillink' => 'hantar e-mel',
'autoblocker' => 'Disekat secara automatik kerana baru-baru ini alamat IP anda digunakan oleh "[[User:$1|$1]]". Sebab sekatan $1 ialah: "$2"',
'blocklogpage' => 'Log sekatan',
'blocklog-showlog' => 'Pengguna ini pernah disekat sebelum ini. Log sekatan disediakan di bawah sebagai rujukan:',
'blocklog-showsuppresslog' => 'Pengguna ini pernah disekat dan tersembunyi sebelum ini.
Log sekatan disediakan di bawah sebagai rujukan:',
'blocklogentry' => 'menyekat [[$1]] sehingga $2 $3',
'reblock-logentry' => 'menukar tetapan sekatan [[$1]] yang tamat pada $2 $3',
'blocklogtext' => 'Ini adalah log bagi tindakan menyekat dan menyahsekat pengguna.
Alamat-alamat IP yang disekat secara automatik tidak disenaraikan di sini.
Sila lihat juga [[Special:BlockList|senarai sekatan]] untuk senarai larangan dan sekatan yang sedang berkuatkuasa.',
'unblocklogentry' => 'menyahsekat $1',
'block-log-flags-anononly' => 'pengguna tanpa nama sahaja',
'block-log-flags-nocreate' => 'pembukaan akaun dimatikan',
'block-log-flags-noautoblock' => 'sekatan automatik dimatikan',
'block-log-flags-noemail' => 'e-mail disekat',
'block-log-flags-nousertalk' => 'tidak boleh menyunting laman perbincangan sendiri',
'block-log-flags-angry-autoblock' => 'sekatan automatik tambahan diaktifkan',
'block-log-flags-hiddenname' => 'nama pengguna tersorok',
'range_block_disabled' => 'Kebolehan penyelia untuk membuat sekatan julat dimatikan.',
'ipb_expiry_invalid' => 'Waktu tamat tidak sah.',
'ipb_expiry_temp' => 'Sekatan nama pengguna terselindung sepatutnya kekal.',
'ipb_hide_invalid' => 'Tidak dapat menahan akaun ini; ia mungkin mempunyai terlalu banyak suntingan.',
'ipb_already_blocked' => '"$1" sudah disekat',
'ipb-needreblock' => '$1 telah pun disekat Adakah anda mahu menukar tetapan sekatan pengguna ini?',
'ipb-otherblocks-header' => '{{PLURAL:$1|Sekatan|Sekatan-sekatan}} lain',
'unblock-hideuser' => 'Anda tidak boleh menyahsekat pengguna ini kerana nama penggunanya telah disorok.',
'ipb_cant_unblock' => 'Ralat: ID sekatan $1 tidak dijumpai. Barangkali ia telah pun dinyahsekat.',
'ipb_blocked_as_range' => 'Ralat: IP $1 tidak boleh dinyahsekat kerana ia tidak disekat secara langsung. Sebaliknya, ia disekat kerana merupakan sebahagian daripada sekatan julat $2, yang mana boleh dinyahsekat.',
'ip_range_invalid' => 'Julat IP tidak sah.',
'ip_range_toolarge' => 'Sekatan julat yang lebih luas daripada /$1 adalah tidak dibenarkan.',
'proxyblocker' => 'Penyekat proksi',
'proxyblockreason' => 'Alamat IP anda telah disekat kerana ia merupakan proksi terbuka.
Sila hubungi penyedia perkhidmatan Internet anda atau pihak sokongan teknikal dan beritahu mereka mengenai masalah keselamatan yang berat ini.',
'sorbsreason' => 'Alamat IP anda telah disenaraikan sebagai proksi terbuka dalam DNSBL yang digunakan oleh {{SITENAME}}.',
'sorbs_create_account_reason' => 'Alamat IP anda telah disenaraikan sebagai proksi terbuka dalam DNSBL yang digunakan oleh {{SITENAME}}. Oleh itu, anda tidak dibenarkan membuka akaun baru.',
'xffblockreason' => 'Alamat IP yang terdapat dalam pengepala X-Forwarded-For, sama ada milik anda ataupun pelayan proksi yang anda gunakan, telah disekat. Sebab asal sekatan adalah: $1',
'cant-block-while-blocked' => 'Anda tidak boleh menyekat orang lain sedangkan anda disekat.',
'cant-see-hidden-user' => 'Pengguna yang anda cuba sekat telahpun disekat dan tersorok.
Memandangkan anda tidak mempunyai hak untuk menyorokkan pengguna, anda tidak boleh melihat atau menyunting sekatan pengguna tersebut.',
'ipbblocked' => 'Anda tidak boleh menyekat atau menyahsekat pengguna lain kerana anda sendiri telah disekat',
'ipbnounblockself' => 'Anda tidak dibenarkan menyahsekat diri sendiri',

# Developer tools
'lockdb' => 'Kunci pangkalan data',
'unlockdb' => 'Buka kunci pangkalan data.',
'lockdbtext' => 'Penguncian pangkalan data akan membekukan kebolehan semua
pengguna untuk menyunting laman, mengubah keutamaan, menyunting senarai
sekatan, dan perkara lain yang memerlukan perubahan dalam pangkalan data.
Sila sahkan bahawa anda memang berniat untuk melakukan tindakan ini, dan
bahawa anda akan membuka semula kunci pangkalan data ini setelah penyenggaraan selesai.',
'unlockdbtext' => 'Pembukaan kunci pangkalan data boleh
memulihkan kebolehan semua pengguna untuk menyunting laman, keutamaan, senarai
pantau dan sebagainya yang melibatkan perubahan dalam pangkalan data. Sila
sahkan bahawa anda betul-betul mahu melakukan tindakan ini.',
'lockconfirm' => 'Ya, saya mahu mengunci pangkalan data ini.',
'unlockconfirm' => 'Ya, saya betul-betul mahu membuka kunci pangkalan data.',
'lockbtn' => 'Kunci pangkalan data',
'unlockbtn' => 'Buka kunci pangkalan data',
'locknoconfirm' => 'Anda tidak meraitkan petak pengesahan.',
'lockdbsuccesssub' => 'Pangkalan data berjaya dikunci',
'unlockdbsuccesssub' => 'Kunci pangkalan data dibuka',
'lockdbsuccesstext' => 'Pangkalan data telah dikunci.
<br />Pastikan anda [[Special:UnlockDB|membukanya semula]] selepas penyelenggaraan selesai.',
'unlockdbsuccesstext' => 'Kunci pangkalan data {{SITENAME}} telah dibuka.',
'lockfilenotwritable' => 'Fail kunci pangkalan data tidak boleh ditulis. Untuk mengunci atau membuka kunci pangkalan data, fail ini perlu diubah suai supaya boleh ditulis oleh pelayan web ini.',
'databasenotlocked' => 'Pangkalan data tidak dikunci.',
'lockedbyandtime' => '(oleh $1 di $2 pada $3)',

# Move page
'move-page' => 'Pindahkan $1',
'move-page-legend' => 'Pindahkan laman',
'movepagetext' => "Menggunakan borang di bawah akan menukar nama halaman dan memindahkan segala sejarahnya kepada nama baru itu.

Tajuk yang lama akan menjadi halaman lencongan kepada tajuk baru.
Anda boleh mengemaskinikan lencongan yang menghala ke tajuk asal secara automatik.
Jika anda memilih untuk tidak berbuat demikian, tolong semak untuk mencari lencongan [[Special:DoubleRedirects|berganda]] atau [[Special:BrokenRedirects|terputus]].
Anda dipertanggungjawabkan untuk memastikan agar semua pautan tetap menghala ke tempat yang sepatutnya.

Sila ingat bahasa halaman '''tidak''' akan dipindahkan jika tajuk barunya sudah diambil oleh halaman yang sedia ada, melainkan halaman yang sedia ada tersebut merupakan lencongan tanpa sebarang sejarah suntingan.
Ertinya, anda boleh menukar kembali nama halaman ke nama yang sebelumnya jika anda terbuat silap, tetapi anda tidak boleh menulis ganti halaman yang sedia ada.

'''Amaran!'''
Tindakan ini boleh mendatangkan perubahan yang drastik dan tidak dijangka untuk halaman yang popular; sila pasti bahawa anda memahami akibatnya sebelum meneruskan.",
'movepagetext-noredirectfixer' => "Borang di bawah akan menamakan semula sesebuah laman, memindahkan kesemua sejarahnya ke nama baru.
Nama lamanya akan menjadi sebuah laman lencongan ke laman baru tadi.
Pastikan [[Special:DoubleRedirects|lencongan berganda]] atau [[Special:BrokenRedirects|rosak]] sudah diperiksa.
Anda bertanggungjawab memastikan pautan-pautan sampai ke tujuan yang sepatutnya.

Sila maklum bahawa laman tadi '''tidak''' akan dipindahkan sekiranya laman dengan tajuk yang baru tadi telah wujud, melainkan ia kosong atau sebuah pelencongan dan tiada sejarah suntingan lampau.
Ini bermakna anda boleh menamakan semula sesebuah laman balik kepada nama asalnya jika anda melakukan kesilapan, dan anda tidak boleh menulis ganti sebuah laman yang sudah wujud.

'''AMARAN!'''
Tindakan ini boleh menjadi perubahan yang tidak dijangka dan drastik bagi laman popular;
sila pastikan anda faham akibat yang mungkin timbul sebelum meneruskannya.",
'movepagetalktext' => "Laman perbincangan yang berkaitan, jika ada, akan dipindahkan bersama-sama laman ini secara automatik '''kecuali''':
* Sebuah laman perbincangan dengan nama baru telah pun wujud, atau
* Anda membuang tanda kotak di bawah.

Dalam kes tersebut, anda terpaksa melencongkan atau menggabungkan laman secara manual, jika perlu.",
'movearticle' => 'Pindahkan laman:',
'moveuserpage-warning' => "'''Amaran:''' Anda sudah hendak memindahkan suatu laman pengguna. Sila ambil perhatian bahawa hanya laman tersebut akan dipindahkan dan nama pengguna yang berkenaan ''tidak'' berubah.",
'movenologin' => 'Belum log masuk.',
'movenologintext' => 'Anda mesti [[Special:UserLogin|log masuk]] terlebih dahulu untuk memindahkan laman.',
'movenotallowed' => 'Anda tidak mempunyai keizinan untuk memindahkan laman.',
'movenotallowedfile' => 'Anda tidak mempunyai keizinan untuk memindahkan fail.',
'cant-move-user-page' => 'Anda tidak mempunyai keizinan untuk memindahkan laman pengguna (tidak termasuk sublaman-sublamannya).',
'cant-move-to-user-page' => 'Anda tidak mempunyai keizinan untuk memindahkan sesebuah laman ke mana-mana laman pengguna (kecuali sebagai sublamannya sahaja).',
'newtitle' => 'Ke tajuk baru:',
'move-watch' => 'Pantau laman ini',
'movepagebtn' => 'Pindahkan laman',
'pagemovedsub' => 'Pemindahan berjaya',
'movepage-moved' => '\'\'\'"$1" telah dipindahkan ke "$2"\'\'\'',
'movepage-moved-redirect' => 'Satu lencongan telah diwujudkan.',
'movepage-moved-noredirect' => 'Penciptaan lencongan telah dihalang.',
'articleexists' => 'Laman dengan nama tersebut telah pun wujud,
atau nama yang anda pilih tidak sah.
Sila pilih nama lain.',
'cantmove-titleprotected' => 'Anda tidak boleh memindah sebarang laman ke sini kerana tajuk ini telah dilindungi daripada dicipta',
'talkexists' => "'''Laman tersebut berjaya dipindahkan, akan tetapi laman perbincangannya tidak dapat dipindahkan kerana laman dengan tajuk baru tersebut telah pun wujud. Anda perlu menggabungkannya secara manual.'''",
'movedto' => 'dipindahkan ke',
'movetalk' => 'Pindahkan laman perbincangan yang berkaitan',
'move-subpages' => 'Pindahkan semua sublaman sekali (sehingga $1)',
'move-talk-subpages' => 'Pindahkan semua sublaman bagi laman perbincangan sekali (sehingga $1)',
'movepage-page-exists' => 'Laman $1 telah pun wujud dan tidak boleh ditulis ganti secara automatik.',
'movepage-page-moved' => 'Laman $1 telah dipindahkan ke $2.',
'movepage-page-unmoved' => 'Laman $1 tidak dapat dipindahkan ke $2.',
'movepage-max-pages' => 'Jumlah maksimum $1 laman telah dipindahkan secara automatik.',
'movelogpage' => 'Log pemindahan',
'movelogpagetext' => 'Yang berikut ialah senarai pemindahan laman.',
'movesubpage' => '{{PLURAL:$1|Sublaman|Sublaman}}',
'movesubpagetext' => 'Laman ini mempunyai $1 sublaman berikut.',
'movenosubpage' => 'Laman ini tiada sublaman.',
'movereason' => 'Sebab:',
'revertmove' => 'balik',
'delete_and_move' => 'Hapus dan pindah',
'delete_and_move_text' => '==Penghapusan diperlukan==

Laman destinasi "[[:$1]]" telah pun wujud. Adakah anda mahu menghapuskannya supaya laman ini dapat dipindahkan?',
'delete_and_move_confirm' => 'Ya, hapuskan laman ini',
'delete_and_move_reason' => 'Dihapuskan untuk membuka laluan untuk pemindahan dari "[[$1]]"',
'selfmove' => 'Tajuk sumber dan tajuk destinasi tidak boleh sama.',
'immobile-source-namespace' => 'Anda tidak boleh memindahkan laman dari ruang nama "$1"',
'immobile-target-namespace' => 'Anda tidak boleh memindahkan mana-mana laman ke dalam ruang nama "$1"',
'immobile-target-namespace-iw' => 'Pautan interwiki tidak boleh dijadikan sasaran untuk pemindahan laman.',
'immobile-source-page' => 'Anda tidak boleh memindahkan laman ini.',
'immobile-target-page' => 'Anda tidak boleh memindahkan laman ke tajuk itu.',
'bad-target-model' => 'Destinasi yang dikehendaki menggunakan model kandungan yang berlainan. $1 tidak dapat ditukar kepada $2.',
'imagenocrossnamespace' => 'Anda tidak boleh memindahkan fail ke ruang nama bukan fail',
'nonfile-cannot-move-to-file' => 'Laman bukan fail tidak boleh dipindahkan ke ruang nama fail',
'imagetypemismatch' => 'Sambungan baru fail tersebut tidak sepadan dengan jenisnya',
'imageinvalidfilename' => 'Nama fail sasaran tidak sah',
'fix-double-redirects' => 'Kemas kinikan semua lencongan yang menuju ke tajuk asal',
'move-leave-redirect' => 'Lencongkan ke tajuk baru',
'protectedpagemovewarning' => "'''Amaran:''' Laman ini telah dikunci supaya hanya mereka yang mempunyai keistimewaan penyelia boleh mengalihkannya.
Masukan log terakhir ditunjukkan di bawah untuk rujukan:",
'semiprotectedpagemovewarning' => "'''Nota:''' Laman ini telah dikunci agar hanya pengguna berdaftar sahaja boleh memindahkannya.
Masukan log terakhir ditunjukkan di bawah untuk rujukan:",
'move-over-sharedrepo' => '== Fail wujud ==
[[:$1]] telah wujud di gedung kongsi. Fail baru yang menggunakan tajuk ini akan mengatasi fail di gedung kongsi ini.',
'file-exists-sharedrepo' => 'Nama fail yang dipilih telah pun digunakan dalam gedung kongsi. Sila pilih nama lain.',

# Export
'export' => 'Eksport laman',
'exporttext' => 'Anda boleh mengeksport teks dan sejarah suntingan untuk laman-laman tertentu yang ke dalam fail XML.
Fail ini boleh diimport ke dalam wiki lain yang menggunakan perisian MediaWiki melalui [[Special:Import|laman import]].

Untuk mengeksport laman, masukkan tajuk dalam kotak teks di bawah (satu tajuk bagi setiap baris) dan pilih sama ada anda mahukan semua versi dan catatan sejarah atau hanya versi semasa berserta maklumat mengenai suntingan terakhir.

Dalam pilihan kedua tadi, anda juga boleh menggunakan pautan, umpamanya [[{{#Special:Export}}/{{MediaWiki:Mainpage}}]] untuk laman "[[{{MediaWiki:Mainpage}}]]".',
'exportall' => 'Eksport semua laman',
'exportcuronly' => 'Hanya eksport semakan semasa, bukan keseluruhan sejarah.',
'exportnohistory' => "----
'''Catatan:''' Ciri eksport sejarah penuh laman melalui borang ini telah dimatikan atas sebab-sebab prestasi.",
'exportlistauthors' => 'Sertakan senarai penuh penyumbang untuk setiap laman',
'export-submit' => 'Eksport',
'export-addcattext' => 'Tambahkan laman dari kategori:',
'export-addcat' => 'Tambahkan',
'export-addnstext' => 'Tambahkan laman dari ruang nama:',
'export-addns' => 'Tambahkan',
'export-download' => 'Simpan sebagai fail',
'export-templates' => 'Sertakan templat',
'export-pagelinks' => 'Sertakan laman-laman yang dipaut sedalam:',

# Namespace 8 related
'allmessages' => 'Pesanan sistem',
'allmessagesname' => 'Nama',
'allmessagesdefault' => 'Teks mesej asal',
'allmessagescurrent' => 'Teks pesanan semasa',
'allmessagestext' => 'Ini ialah senarai pesanan sistem yang terdapat dalam ruang nama MediaWiki.
Sila lawat [//www.mediawiki.org/wiki/Localisation Penyetempatan MediaWiki] dan [//translatewiki.net translatewiki.net] sekiranya anda mahu menyumbang dalam menyetempatkan dan menterjemah perisian MediaWiki.',
'allmessagesnotsupportedDB' => "'''{{ns:special}}:Allmessages''' tidak boleh digunakan kerana '''\$wgUseDatabaseMessages''' dipadamkan.",
'allmessages-filter-legend' => 'Penapisan',
'allmessages-filter' => 'Tapis berdasarkan keadaan penempahan:',
'allmessages-filter-unmodified' => 'Tidak diubah',
'allmessages-filter-all' => 'Semua',
'allmessages-filter-modified' => 'Diubah',
'allmessages-prefix' => 'Tapis berdasarkan awalan:',
'allmessages-language' => 'Bahasa:',
'allmessages-filter-submit' => 'Pergi',

# Thumbnails
'thumbnail-more' => 'Besarkan',
'filemissing' => 'Fail hilang',
'thumbnail_error' => 'Berlaku ralat ketika mencipta gambar kenit: $1',
'thumbnail_error_remote' => 'Mesej ralat dari $1: $2',
'djvu_page_error' => 'Laman DjVu di luar julat',
'djvu_no_xml' => 'Gagal mendapatkan data XML bagi fail DjVu',
'thumbnail-temp-create' => 'Fail gambar kenit sementara tidak dapat dibuat',
'thumbnail-dest-create' => 'Gambar kenit tidak dapat disimpan dalam destinasi',
'thumbnail_invalid_params' => 'Parameter gambar kenit tidak sah',
'thumbnail_dest_directory' => 'Direktori destinasi gagal diwujudkan',
'thumbnail_image-type' => 'Jenis imej tidak disokong',
'thumbnail_gd-library' => 'Tatarajah perpustakaan GD tidak lengkap: kehilangan fungsi $1',
'thumbnail_image-missing' => 'Fail ini nampaknya hilang: $1',

# Special:Import
'import' => 'Import laman',
'importinterwiki' => 'Import transwiki',
'import-interwiki-text' => 'Sila pilih wiki dan tajuk laman yang ingin diimport.
Semua tarikh semakan dan nama penyunting akan dikekalkan.
Semua tindakan import transwiki dicatatkan dalam [[Special:Log/import|log import]].',
'import-interwiki-source' => 'Sumber wiki/halaman:',
'import-interwiki-history' => 'Salin semua versi sejarah bagi laman ini',
'import-interwiki-templates' => 'Sertakan semua templat',
'import-interwiki-submit' => 'Import',
'import-interwiki-namespace' => 'Ruang nama destinasi:',
'import-interwiki-rootpage' => 'Halaman akar tujuan (tidak wajib):',
'import-upload-filename' => 'Nama fail:',
'import-comment' => 'Komen:',
'importtext' => 'Sila eksport fail daripada sumber wiki dengan menggunakan [[Special:Export|utiliti eksport]].
Simpan dalam komputer anda dan muat naiknya di sini.',
'importstart' => 'Mengimport laman...',
'import-revision-count' => '$1 semakan',
'importnopages' => 'Tiada laman untuk diimport.',
'imported-log-entries' => '$1 {{PLURAL:$1|entri log|entri log}} telah diimport.',
'importfailed' => 'Import gagal: $1',
'importunknownsource' => 'Jenis sumber import tidak dikenali',
'importcantopen' => 'Fail import tidak dapat dibuka',
'importbadinterwiki' => 'Pautan antara wiki rosak',
'importnotext' => 'Kosong atau tiada teks',
'importsuccess' => 'Import selesai!',
'importhistoryconflict' => 'Terdapat percanggahan semakan sejarah (mungkin laman ini pernah diimport sebelum ini)',
'importnosources' => 'Tiada sumber import transwiki ditentunkan dan ciri muat naik sejarah secara terus dimatikan.',
'importnofile' => 'Tiada fail import dimuat naik.',
'importuploaderrorsize' => 'Fail import tidak dapat dimuat naik kerana melebihi had muat naik yang dibenarkan.',
'importuploaderrorpartial' => 'Fail import tidak dapat dimuat naik kerana tidak dimuat naik sampai habis.',
'importuploaderrortemp' => 'Fail import tidak dapat dimuat naik kerana tiada direktori sementara.',
'import-parse-failure' => 'Gagal menghurai fail XML yang diimport',
'import-noarticle' => 'Tiada laman untuk diimport!',
'import-nonewrevisions' => 'Semua semakan telah pun diimport sebelum ini.',
'xml-error-string' => '$1 pada baris $2, lajur $3 (bait $4): $5',
'import-upload' => 'Muat naik data XML',
'import-token-mismatch' => 'Data sesi telah hilang. Sila cuba lagi.',
'import-invalid-interwiki' => 'Wiki yang dinyatakan tidak boleh diimport.',
'import-error-edit' => 'Laman "$1" tidak diimport kerana anda tidak dibenarkan untuk menyuntingnya.',
'import-error-create' => 'Laman "$1" tidak diimport kerana anda tidak dibenarkan untuk menciptanya.',
'import-error-interwiki' => 'Laman "$1" tidak diimport kerana namanya ditempah untuk pemautan luaran (antara wiki).',
'import-error-special' => 'Laman "$1" tidak diimport kerana ia tergolong dalam ruang nama khas yang tidak membenarkan laman.',
'import-error-invalid' => 'Laman "$1" tidak diimport kerana namanya tidak sah.',
'import-error-unserialize' => 'Semakan $2 dari halaman "$1" tidak dapat dinyahsirikan. Semakan ini dilaporkan telah menggunakan model kandungan $3 yang disirikan sebagai $4.',
'import-options-wrong' => '{{PLURAL:$2|Pilihan|Pilihan-pilihan}} salah: <nowiki>$1</nowiki>',
'import-rootpage-invalid' => 'Halaman akar yang dinyatakan adalah tidak sah.',
'import-rootpage-nosubpage' => 'Ruang nama "$1" halaman akar tidak membenarkan subhalaman.',

# Import log
'importlogpage' => 'Log import',
'importlogpagetext' => 'Senarai tindakan import laman dengan keseluruhan sejarah suntingannya daripada wiki lain.',
'import-logentry-upload' => 'mengimport [[$1]] dengan memuat naik fail',
'import-logentry-upload-detail' => '$1 semakan',
'import-logentry-interwiki' => '$1 dipindahkan ke wiki lain',
'import-logentry-interwiki-detail' => '$1 semakan daripada $2',

# JavaScriptTest
'javascripttest' => 'Ujian JavaScript',
'javascripttest-title' => 'Ujian $1 sedang dijalankan',
'javascripttest-pagetext-noframework' => 'Laman ini ditempah untuk menjalankan ujian JavaScript.',
'javascripttest-pagetext-unknownframework' => 'Kerangka "$1" tidak dikenali.',
'javascripttest-pagetext-frameworks' => 'Sila pilih salah satu kerangka yang berikut: $1',
'javascripttest-pagetext-skins' => 'Sila pilih satu kulit untuk menjalankan ujian:',
'javascripttest-qunit-intro' => 'Rujuk [$1 dokumentasi ujian] di mediawiki.org.',
'javascripttest-qunit-heading' => 'Suit ujian MediaWiki JavaScript QUnit',

# Tooltip help for the actions
'tooltip-pt-userpage' => 'Laman pengguna anda',
'tooltip-pt-anonuserpage' => 'Laman pengguna bagi alamat IP anda',
'tooltip-pt-mytalk' => 'Laman perbualan anda',
'tooltip-pt-anontalk' => 'Perbincangan mengenai penyuntingan daripada alamat IP anda',
'tooltip-pt-preferences' => 'Keutamaan saya',
'tooltip-pt-watchlist' => 'Senarai laman yang anda pantau',
'tooltip-pt-mycontris' => 'Senarai sumbangan anda',
'tooltip-pt-login' => 'Walaupun tidak wajib, anda digalakkan supaya log masuk.',
'tooltip-pt-anonlogin' => 'Walaupun tidak wajib, anda digalakkan supaya log masuk.',
'tooltip-pt-logout' => 'Log keluar',
'tooltip-ca-talk' => 'Perbincangan mengenai laman kandungan',
'tooltip-ca-edit' => "Anda boleh menyunting laman ini. Sila tekan butang 'pralihat' terlebih dahulu sebelum menyimpan.",
'tooltip-ca-addsection' => 'Buka bahagian baru',
'tooltip-ca-viewsource' => 'Laman ini dilindungi. Anda boleh melihat sumbernya.',
'tooltip-ca-history' => 'Versi-versi terdahulu bagi laman ini.',
'tooltip-ca-protect' => 'Lindungi laman ini',
'tooltip-ca-unprotect' => 'Ubah tahap perlindungan laman ini',
'tooltip-ca-delete' => 'Hapuskan laman ini',
'tooltip-ca-undelete' => 'Balikkan suntingan yang dilakukan kepada laman ini sebelum ia dihapuskan',
'tooltip-ca-move' => 'Pindahkan laman ini',
'tooltip-ca-watch' => 'Tambahkan laman ini ke dalam senarai pantau anda',
'tooltip-ca-unwatch' => 'Buang laman ini daripada senarai pantau anda',
'tooltip-search' => 'Cari dalam {{SITENAME}}',
'tooltip-search-go' => 'Pergi ke laman dengan nama tepat ini, jika ada',
'tooltip-search-fulltext' => 'Cari laman dengan teks ini',
'tooltip-p-logo' => 'Kunjungi laman utama',
'tooltip-n-mainpage' => 'Kunjungi Laman Utama',
'tooltip-n-mainpage-description' => 'Kunjungi laman utama',
'tooltip-n-portal' => 'Maklumat mengenai projek ini',
'tooltip-n-currentevents' => 'Cari maklumat latar belakang mengenai peristiwa semasa',
'tooltip-n-recentchanges' => 'Senarai perubahan terkini dalam wiki ini.',
'tooltip-n-randompage' => 'Buka laman rawak',
'tooltip-n-help' => 'Tempat mencari jawapan',
'tooltip-t-whatlinkshere' => 'Senarai laman wiki yang mengandungi pautan ke laman ini',
'tooltip-t-recentchangeslinked' => 'Perubahan terkini bagi semua laman yang dipaut dari laman ini',
'tooltip-feed-rss' => 'Suapan RSS bagi laman ini',
'tooltip-feed-atom' => 'Suapan Atom bagi laman ini',
'tooltip-t-contributions' => 'Lihat senarai sumbangan pengguna ini',
'tooltip-t-emailuser' => 'Kirim e-mel kepada pengguna ini',
'tooltip-t-upload' => 'Muat naik imej atau fail media',
'tooltip-t-specialpages' => 'Senarai laman khas',
'tooltip-t-print' => 'Versi boleh cetak bagi laman ini',
'tooltip-t-permalink' => 'Pautan kekal ke versi ini',
'tooltip-ca-nstab-main' => 'Lihat laman kandungan',
'tooltip-ca-nstab-user' => 'Lihat laman pengguna',
'tooltip-ca-nstab-media' => 'Lihat laman media',
'tooltip-ca-nstab-special' => 'Ini adalah sebuah laman khas, anda tidak boleh menyunting laman ini secara terus.',
'tooltip-ca-nstab-project' => 'Lihat laman projek',
'tooltip-ca-nstab-image' => 'Lihat laman imej',
'tooltip-ca-nstab-mediawiki' => 'Lihat pesanan sistem',
'tooltip-ca-nstab-template' => 'Lihat templat',
'tooltip-ca-nstab-help' => 'Lihat laman bantuan',
'tooltip-ca-nstab-category' => 'Lihat laman kategori',
'tooltip-minoredit' => 'Tandakan sebagai suntingan kecil',
'tooltip-save' => 'Simpan perubahan',
'tooltip-preview' => 'Semak perubahan yang anda lakukan terlebih dahulu, kemudian sila tekan butang ini sebelum menyimpan!',
'tooltip-diff' => 'Tunjukkan perubahan yang anda telah lakukan kepada teks ini.',
'tooltip-compareselectedversions' => 'Lihat perbezaan antara dua versi laman ini yang dipilih.',
'tooltip-watch' => 'Tambahkan laman ini ke dalam senarai pantau anda',
'tooltip-watchlistedit-normal-submit' => 'Gugurkan tajuk-tajuk',
'tooltip-watchlistedit-raw-submit' => 'Kemas kini senarai pantau',
'tooltip-recreate' => 'Cipta semula laman ini walaupun ia telah dihapuskan',
'tooltip-upload' => 'Muat naik',
'tooltip-rollback' => 'Balikkan semua suntingan oleh penyumbang terakhir pada laman ini dengan satu klik.',
'tooltip-undo' => 'Batalkan suntingan ini dan buka borang sunting dalam mod pralihat. Sebab boleh dinyatakan dalam ruangan ringkasan.',
'tooltip-preferences-save' => 'Simpan keutamaan',
'tooltip-summary' => 'Berikan ringkasan',

# Stylesheets
'common.css' => '/* CSS yang terletak di sini akan digunakan pada semua kulit */',
'cologneblue.css' => '/* CSS yang terletak di sini akan mempengaruhi pengguna kulit Cologne Blue */',
'monobook.css' => '/* CSS yang terletak di sini akan mempengaruhi pengguna kulit Monobook */',
'modern.css' => '/* CSS yang terletak di sini akan mempengaruhi pengguna kulit Moden */',
'vector.css' => '/* CSS yang terletak di sini akan mempengaruhi pengguna kulit Vector */',

# Metadata
'notacceptable' => 'Pelayan wiki ini tidak mampu menyediakan data dalam format yang boleh dibaca oleh pelanggan anda.',

# Attribution
'anonymous' => '{{PLURAL:$1|Pengguna|Pengguna-pengguna}} {{SITENAME}} tanpa nama',
'siteuser' => 'Pengguna {{SITENAME}}, $1',
'anonuser' => 'Pengguna {{SITENAME}} tanpa nama $1',
'lastmodifiedatby' => 'Laman ini diubah buat kali terakhir pada $2, $1 oleh $3.',
'othercontribs' => 'Berdasarkan karya $1.',
'others' => 'lain-lain',
'siteusers' => '{{PLURAL:$2|Pengguna|Pengguna-pengguna}} {{SITENAME}}, $1',
'anonusers' => '{{PLURAL:$2|Pengguna|Pengguna-pengguna}} {{SITENAME}} tanpa nama $1',
'creditspage' => 'Penghargaan',
'nocredits' => 'Tiada maklumat penghargaan bagi laman ini.',

# Spam protection
'spamprotectiontitle' => 'Penapis spam',
'spamprotectiontext' => 'Laman yang anda ingin simpan telah dihalang oleh penapis spam. Hal ini mungkin disebabkan oleh pautan ke tapak web luar yang telah disenaraihitamkan.',
'spamprotectionmatch' => 'Teks berikut dikesan oleh penapis spam kami: $1',
'spambot_username' => 'Pembersihan spam MediaWiki',
'spam_reverting' => 'Membalikkan kepada versi terakhir yang tidak mengandungi pautan ke $1',
'spam_blanking' => 'Mengosongkan semua semakan yang mengandungi pautan ke $1',
'spam_deleting' => 'Menghapuskan semua semakan yang mengandungi pautan ke $1',

# Info page
'pageinfo-title' => 'Maklumat untuk "$1"',
'pageinfo-not-current' => 'Maaf, maklumat ini tidak dapat disediakan untuk semakan lama.',
'pageinfo-header-basic' => 'Maklumat asas',
'pageinfo-header-edits' => 'Sunting sejarah',
'pageinfo-header-restrictions' => 'Perlindungan halaman',
'pageinfo-header-properties' => 'Sifat halaman',
'pageinfo-display-title' => 'Tajuk paparan',
'pageinfo-default-sort' => 'Kunci isih azali',
'pageinfo-length' => 'Kepanjangan halaman (bait)',
'pageinfo-article-id' => 'ID halaman',
'pageinfo-language' => 'Bahasa isi kandungan halaman',
'pageinfo-robot-policy' => 'Indeks oleh robot',
'pageinfo-robot-index' => 'Dibenarkan',
'pageinfo-robot-noindex' => 'Tidak dibenarkan',
'pageinfo-views' => 'Bilangan kunjungan',
'pageinfo-watchers' => 'Bilangan pemantau halaman',
'pageinfo-few-watchers' => 'Kurang daripada $1 orang pemantau',
'pageinfo-redirects-name' => 'Jumlah lencongan ke laman ini',
'pageinfo-subpages-name' => 'Subhalaman untuk halaman ini',
'pageinfo-subpages-value' => '$1 ($2 lencongan; $3 bukan lencongan)',
'pageinfo-firstuser' => 'Pembuat halaman',
'pageinfo-firsttime' => 'Tarikh halaman dibuat',
'pageinfo-lastuser' => 'Penyunting terkini',
'pageinfo-lasttime' => 'Tarikh suntingan terkini',
'pageinfo-edits' => 'Jumlah suntingan',
'pageinfo-authors' => 'Jumlah pengarang yang berlainan',
'pageinfo-recent-edits' => 'Bilangan suntingan terkini (dalam $1 yang lalu)',
'pageinfo-recent-authors' => 'Bilangan pengarang berbeza yang terkini',
'pageinfo-magic-words' => 'Kata sakti ($1)',
'pageinfo-hidden-categories' => 'Kategori tersembunyi ($1)',
'pageinfo-templates' => 'Templat tertransklusi ($1)',
'pageinfo-transclusions' => '{{PLURAL:$1|Halaman|Halaman-halaman}} yang tertransklusi pada ($1)',
'pageinfo-toolboxlink' => 'Maklumat halaman',
'pageinfo-redirectsto' => 'Melencong ke',
'pageinfo-redirectsto-info' => 'maklumat',
'pageinfo-contentpage' => 'Dikira sebagai halaman kandungan',
'pageinfo-contentpage-yes' => 'Ya',
'pageinfo-protect-cascading' => 'Perlindungan sedang melata dari sini',
'pageinfo-protect-cascading-yes' => 'Ya',
'pageinfo-protect-cascading-from' => 'Perlindungan sedang melata dari',
'pageinfo-category-info' => 'Keterangan kategori',
'pageinfo-category-pages' => 'Bilangan halaman',
'pageinfo-category-subcats' => 'Bilangan subkategori',
'pageinfo-category-files' => 'Bilangan fail',

# Skin names
'skinname-cologneblue' => 'Cologne Blue',
'skinname-monobook' => 'MonoBook',
'skinname-modern' => 'Moden',
'skinname-vector' => 'Vector',

# Patrolling
'markaspatrolleddiff' => 'Tanda ronda',
'markaspatrolledtext' => 'Tanda ronda laman ini',
'markedaspatrolled' => 'Tanda ronda',
'markedaspatrolledtext' => 'Semakan [[:$1]] tersebut telah ditanda sebagai telah diperiksa.',
'rcpatroldisabled' => 'Rondaan Perubahan Terkini dimatikan',
'rcpatroldisabledtext' => 'Ciri Rondaan Perubahan Terkini dimatikan.',
'markedaspatrollederror' => 'Tidak boleh menanda ronda',
'markedaspatrollederrortext' => 'Anda perlu menyatakan semakan untuk ditanda ronda.',
'markedaspatrollederror-noautopatrol' => 'Anda tidak dibenarkan menanda ronda perubahan anda sendiri.',
'markedaspatrollednotify' => 'Perubahan pada $1 ini telah ditandai sebagai dironda.',
'markedaspatrollederrornotify' => 'Penandaan sebagai dironda gagal.',

# Patrol log
'patrol-log-page' => 'Log pemeriksaan',
'patrol-log-header' => 'Yang berikut ialah log rondaan bagi semakan.',
'log-show-hide-patrol' => '$1 log rondaan',

# Image deletion
'deletedrevision' => 'Menghapuskan semakan lama $1.',
'filedeleteerror-short' => 'Ralat ketika menghapuskan fail: $1',
'filedeleteerror-long' => 'Berlaku ralat ketika menghapuskan fail tersebut:

$1',
'filedelete-missing' => 'Fail "$1" tidak boleh dihapuskan kerana ia tidak wujud.',
'filedelete-old-unregistered' => 'Semakan fail "$1" tiada dalam pangkalan data.',
'filedelete-current-unregistered' => 'Fail "$1" tiada dalam pangkalan data.',
'filedelete-archive-read-only' => 'Direktori arkib "$1" tidak boleh ditulis oleh pelayan web.',

# Browsing diffs
'previousdiff' => '← Suntingan sebelumnya',
'nextdiff' => 'Suntingan berikutnya →',

# Media information
'mediawarning' => "'''Amaran''': Fail jenis ini mungkin mengandungi kod berbahaya.
Dengan menjalankannya, komputer anda mungkin akan terjejas.",
'imagemaxsize' => "Had saiz imej:<br />''(untuk laman keterangan fail)''",
'thumbsize' => 'Saiz gambar kenit:',
'widthheight' => '$1 × $2',
'widthheightpage' => '$1 × $2, $3 halaman',
'file-info' => 'saiz file: $1, jenis MIME: $2',
'file-info-size' => '$1 × $2 piksel, saiz fail: $3, jenis MIME: $4',
'file-info-size-pages' => '$1 × $2 piksel, saiz fail: $3, jenis MIME: $4, $5 laman',
'file-nohires' => 'Tiada leraian lebih besar.',
'svg-long-desc' => 'Fail SVG, ukuran dasar $1 × $2 piksel, saiz fail: $3',
'svg-long-desc-animated' => 'Fail SVG animasi, ukuran dasar $1 × $2 piksel, saiz fail: $3',
'svg-long-error' => 'Fail SVG tidak sah: $1',
'show-big-image' => 'Leraian penuh',
'show-big-image-preview' => 'Saiz pralihat ini: $1.',
'show-big-image-other' => '{{PLURAL:$2|Leraian|Leraian-leraian}} lain: $1.',
'show-big-image-size' => '$1 × $2 piksel',
'file-info-gif-looped' => 'berulang',
'file-info-gif-frames' => '$1 bingkai',
'file-info-png-looped' => 'berulang',
'file-info-png-repeat' => 'dimainkan {{PLURAL:$1|sekali|sebanyak $1 kali}}',
'file-info-png-frames' => '$1 bingkai',
'file-no-thumb-animation' => "'''Perhatian: Disebabkan had teknikal, gambar kenit untuk fail ini tidak beranimasi.'''",
'file-no-thumb-animation-gif' => "''''''Perhatian: Disebabkan had teknikal, gambar kenit untuk imej GIF beresolusi tinggi seperti ini tidak beranimasi.'''",

# Special:NewFiles
'newimages' => 'Galeri fail baru',
'imagelisttext' => "Yang berikut ialah senarai bagi '''$1''' fail yang disusun secara $2.",
'newimages-summary' => 'Laman khas ini memaparkan senarai fail muat naik terakhir.',
'newimages-legend' => 'Penapis',
'newimages-label' => 'Nama fail (atau sebahagian daripadanya):',
'showhidebots' => '($1 bot)',
'noimages' => 'Tiada imej.',
'ilsubmit' => 'Cari',
'bydate' => 'mengikut tarikh',
'sp-newimages-showfrom' => 'Tunjukkan imej baru bermula daripada $2, $1',

# Video information, used by Language::formatTimePeriod() to format lengths in the above messages
'video-dims' => '$1, $2 × $3',
'hours-abbrev' => '$1j',
'days-abbrev' => '$1h',
'seconds' => '$1 saat',
'minutes' => '$1 minit',
'hours' => '$1 jam',
'days' => '$1 hari',
'weeks' => '$1 minggu',
'months' => '$1 bulan',
'years' => '$1 tahun',
'ago' => '$1 yang lalu',
'just-now' => 'tadi',

# Human-readable timestamps
'hours-ago' => '$1 jam yang lalu',
'minutes-ago' => '$1 minit yang lalu',
'seconds-ago' => '$1 saat yang lalu',
'monday-at' => 'Isnin $1',
'tuesday-at' => 'Selasa $1',
'wednesday-at' => 'Rabu $1',
'thursday-at' => 'Khamis $1',
'friday-at' => 'Jumaat $1',
'saturday-at' => 'Sabtu $1',
'sunday-at' => 'Ahad $1',
'yesterday-at' => 'Semalam $1',

# Bad image list
'bad_image_list' => 'Berikut adalah format yang digunakan:

Hanya item senarai (baris yang dimulakan dengan *) diambil kira. Pautan pertama pada sesebuah baris mestilah merupakan pautan ke sebuah imej rosak.
Sebarang pautan berikutnya pada baris yang sama dikira sebagai pengecualian (rencana yang dibenarkan disertakan imej).',

# Metadata
'metadata' => 'Metadata',
'metadata-help' => 'Fail ini mengandungi maklumat tambahan daripada kamera digital atau pengimbas yang digunakan untuk menghasilkannya. Jika fail ini telah diubah suai daripada rupa asalnya, beberapa butiran dalam maklumat ini mungkin sudah tidak relevan.',
'metadata-expand' => 'Tunjukkan butiran penuh',
'metadata-collapse' => 'Sembunyikan butiran penuh',
'metadata-fields' => 'Ruangan metadata EXIF yang disenaraikan dalam mesej ini akan ditunjukkan pada laman imej apabila jadual metadata dikecilkan.
Ruangan-ruangan yang lain pula akan disembunyikan pada asali.
* make
* model
* datetimeoriginal
* exposuretime
* fnumber
* isospeedratings
* focallength
* artist
* copyright
* imagedescription
* gpslatitude
* gpslongitude
* gpsaltitude',

# Exif tags
'exif-imagewidth' => 'Lebar',
'exif-imagelength' => 'Tinggi',
'exif-bitspersample' => 'Bit sekomponen',
'exif-compression' => 'Skema pemampatan',
'exif-photometricinterpretation' => 'Komposisi piksel',
'exif-orientation' => 'Haluan',
'exif-samplesperpixel' => 'Bilangan komponen',
'exif-planarconfiguration' => 'Penyusunan data',
'exif-ycbcrsubsampling' => 'Nisbah subpensampelan Y kepada C',
'exif-ycbcrpositioning' => 'Kedudukan Y dan C',
'exif-xresolution' => 'Leraian mengufuk',
'exif-yresolution' => 'Leraian menegak',
'exif-stripoffsets' => 'Lokasi data imej',
'exif-rowsperstrip' => 'Baris sejalur',
'exif-stripbytecounts' => 'Bait sejalur termampat',
'exif-jpeginterchangeformat' => 'Ofset ke SOI JPEG',
'exif-jpeginterchangeformatlength' => 'Jumlah bait bagi data JPEG',
'exif-whitepoint' => 'Kekromatan takat putih',
'exif-primarychromaticities' => 'Kekromatan warna primer',
'exif-ycbcrcoefficients' => 'Pekali matriks penukaran ruang warna',
'exif-referenceblackwhite' => 'Nilai rujukan pasangan hitam dan putih',
'exif-datetime' => 'Tarikh dan waktu fail diubah',
'exif-imagedescription' => 'Tajuk imej',
'exif-make' => 'Pengilang kamera',
'exif-model' => 'Model kamera',
'exif-software' => 'Perisian digunakan',
'exif-artist' => 'Artis',
'exif-copyright' => 'Pemegang hak cipta',
'exif-exifversion' => 'Versi exif',
'exif-flashpixversion' => 'Versi Flashpix yang disokong',
'exif-colorspace' => 'Ruang warna',
'exif-componentsconfiguration' => 'Maksud setiap komponen',
'exif-compressedbitsperpixel' => 'Mod pemampatan imej',
'exif-pixelydimension' => 'Lebar imej',
'exif-pixelxdimension' => 'Tinggi imej',
'exif-usercomment' => 'Komen pengguna',
'exif-relatedsoundfile' => 'Fail audio berkaitan',
'exif-datetimeoriginal' => 'Tarikh dan waktu penjanaan data',
'exif-datetimedigitized' => 'Tarikh dan waktu pendigitan',
'exif-subsectime' => 'TarikhWaktu subsaat',
'exif-subsectimeoriginal' => 'TarikhWaktuAsal subsaat',
'exif-subsectimedigitized' => 'TarikhWaktuPendigitan subsaat',
'exif-exposuretime' => 'Tempoh pendedahan',
'exif-exposuretime-format' => '$1 saat ($2)',
'exif-fnumber' => 'Nombor F',
'exif-exposureprogram' => 'Atur cara pendedahan',
'exif-spectralsensitivity' => 'Kepekaan spektrum',
'exif-isospeedratings' => 'Penilaian kelajuan ISO',
'exif-shutterspeedvalue' => 'Kelajuan pengatup APEX',
'exif-aperturevalue' => 'Bukaan APEX',
'exif-brightnessvalue' => 'Kecerahan APEX',
'exif-exposurebiasvalue' => 'Kecenderungan pendedahan',
'exif-maxaperturevalue' => 'Bukaan tanah maksimum',
'exif-subjectdistance' => 'Jarak subjek',
'exif-meteringmode' => 'Mod permeteran',
'exif-lightsource' => 'Sumber cahaya',
'exif-flash' => 'Denyar',
'exif-focallength' => 'Panjang fokus kanta',
'exif-subjectarea' => 'Luas subjek',
'exif-flashenergy' => 'Tenaga denyar',
'exif-focalplanexresolution' => 'Leraian X satah fokus',
'exif-focalplaneyresolution' => 'Leraian Y satah fokus',
'exif-focalplaneresolutionunit' => 'Unit leraian satah fokus',
'exif-subjectlocation' => 'Lokasi subjek',
'exif-exposureindex' => 'Indeks pendedahan',
'exif-sensingmethod' => 'Kaedah penderiaan',
'exif-filesource' => 'Sumber fail',
'exif-scenetype' => 'Jenis latar',
'exif-customrendered' => 'Pemprosesan imej tempahan',
'exif-exposuremode' => 'Mod pendedahan',
'exif-whitebalance' => 'Imbangan warna putih',
'exif-digitalzoomratio' => 'Nisbah zum digital',
'exif-focallengthin35mmfilm' => 'Panjang fokus dalam filem 35 mm',
'exif-scenecapturetype' => 'Jenis penangkapan latar',
'exif-gaincontrol' => 'Kawalan latar',
'exif-contrast' => 'Kontras',
'exif-saturation' => 'Kepekatan',
'exif-sharpness' => 'Ketajaman',
'exif-devicesettingdescription' => 'Huraian tetapan peranti',
'exif-subjectdistancerange' => 'Julat jarak subjek',
'exif-imageuniqueid' => 'ID unik imej',
'exif-gpsversionid' => 'Versi label GPS',
'exif-gpslatituderef' => 'Latitud utara atau selatan',
'exif-gpslatitude' => 'Latitud',
'exif-gpslongituderef' => 'Logitud timur atau barat',
'exif-gpslongitude' => 'Longitud',
'exif-gpsaltituderef' => 'Rujukan ketinggian',
'exif-gpsaltitude' => 'Ketinggian',
'exif-gpstimestamp' => 'Waktu GPS (jam atom)',
'exif-gpssatellites' => 'Satelit yang digunakan untuk pengukuran',
'exif-gpsstatus' => 'Status penerima',
'exif-gpsmeasuremode' => 'Mod pengukuran',
'exif-gpsdop' => 'Kepersisan pengukuran',
'exif-gpsspeedref' => 'Unit kelajuan',
'exif-gpsspeed' => 'Kelajuan penerima GPS',
'exif-gpstrackref' => 'Rujukan bagi arah pergerakan',
'exif-gpstrack' => 'Arah pergerakan',
'exif-gpsimgdirectionref' => 'Rujukan bagi arah imej',
'exif-gpsimgdirection' => 'Arah imej',
'exif-gpsmapdatum' => 'Data ukur geodesi yang digunakan',
'exif-gpsdestlatituderef' => 'Rujukan bagi latitud destinasi',
'exif-gpsdestlatitude' => 'Latitud destinasi',
'exif-gpsdestlongituderef' => 'Rujukan bagi longitud destinasi',
'exif-gpsdestlongitude' => 'Longitud destinasi',
'exif-gpsdestbearingref' => 'Rujukan bagi bearing destinasi',
'exif-gpsdestbearing' => 'Bearing destinasi',
'exif-gpsdestdistanceref' => 'Rujukan bagi jarak destinasi',
'exif-gpsdestdistance' => 'Jarak destinasi',
'exif-gpsprocessingmethod' => 'Nama kaedah pemprosesan GPS',
'exif-gpsareainformation' => 'Nama kawasan GPS',
'exif-gpsdatestamp' => 'Tarikh GPS',
'exif-gpsdifferential' => 'Pembetulan pembezaan GPS',
'exif-jpegfilecomment' => 'Komen fail JPEG',
'exif-keywords' => 'Kata kunci',
'exif-worldregioncreated' => 'Kawasan dunia di mana gambar diambil',
'exif-countrycreated' => 'Negara di mana gambar diambil',
'exif-countrycodecreated' => 'Kod negara di mana gambar diambil',
'exif-provinceorstatecreated' => 'Wilayah atau negeri di mana gambar diambil',
'exif-citycreated' => 'Bandar di mana gambar diambil',
'exif-sublocationcreated' => 'Kawasan bandar di mana gambar diambil',
'exif-worldregiondest' => 'Kawasan dunia yang ditunjukkan',
'exif-countrydest' => 'Negara yang ditunjukkan',
'exif-countrycodedest' => 'Kod negara yang ditunjukkan',
'exif-provinceorstatedest' => 'Wilayah atau negeri yang ditunjukkan',
'exif-citydest' => 'Bandar yang ditunjukkan',
'exif-sublocationdest' => 'Kawasan bandar yang ditunjukkan',
'exif-objectname' => 'Tajuk ringkas',
'exif-specialinstructions' => 'Arahan khusus',
'exif-headline' => 'Tajuk berita',
'exif-credit' => 'Kredit/Pembekal',
'exif-source' => 'Sumber',
'exif-editstatus' => 'Status editorial imej',
'exif-urgency' => 'Kemustahakan',
'exif-fixtureidentifier' => 'Nama lekapan',
'exif-locationdest' => 'Lokasi yang digambarkan',
'exif-locationdestcode' => 'Kod lokasi yang digambarkan',
'exif-objectcycle' => 'Waktu untuk siarkan media',
'exif-contact' => 'Maklumat hubungan',
'exif-writer' => 'Penulis',
'exif-languagecode' => 'Bahasa',
'exif-iimversion' => 'Versi IIM',
'exif-iimcategory' => 'Kategori',
'exif-iimsupplementalcategory' => 'Kategori tambahan',
'exif-datetimeexpires' => 'Jangan gunakan selepas',
'exif-datetimereleased' => 'Keluar pada',
'exif-originaltransmissionref' => 'Kod lokasi transmisi asal',
'exif-identifier' => 'Pengenal',
'exif-lens' => 'Kanta yang digunakan',
'exif-serialnumber' => 'Nombor bersiri kamera',
'exif-cameraownername' => 'Pemilik kamera',
'exif-label' => 'Label',
'exif-datetimemetadata' => 'Tarikh kali terakhir metadata diubah',
'exif-nickname' => 'Nama timangan imej',
'exif-rating' => 'Nilai (daripada 5)',
'exif-rightscertificate' => 'Sijil pengurusan hak',
'exif-copyrighted' => 'Status hak cipta',
'exif-copyrightowner' => 'Pemilik hak cipta',
'exif-usageterms' => 'Terma-terma penggunaan',
'exif-webstatement' => 'Kenyataan hak cipta dalam talian',
'exif-originaldocumentid' => 'ID unik dokumen asli',
'exif-licenseurl' => 'URL untuk lesen hak cipta',
'exif-morepermissionsurl' => 'Maklumat pelesenan alternatif',
'exif-attributionurl' => 'Apabila menggunakan semula hasil kerja ini, tolong pautkannya ke',
'exif-preferredattributionname' => 'Apabila menggunakan semula hasil kerja ini, tolong berikan penghargaan kepada',
'exif-pngfilecomment' => 'Komen fail PNG',
'exif-disclaimer' => 'Penafian',
'exif-contentwarning' => 'Amaran kandungan',
'exif-giffilecomment' => 'Komen fail GIF',
'exif-intellectualgenre' => 'Jenis item',
'exif-subjectnewscode' => 'Kod subjek',
'exif-scenecode' => 'Kod pemandangan IPTC',
'exif-event' => 'Peristiwa yang digambarkan',
'exif-organisationinimage' => 'Pertubuhan yang digambarkan',
'exif-personinimage' => 'Tokoh yang digambarkan',
'exif-originalimageheight' => 'Ketinggian imej sebelum dipangkas',
'exif-originalimagewidth' => 'Lebar imej sebelum dipangkas',

# Exif attributes
'exif-compression-1' => 'Tak termampat',
'exif-compression-2' => 'Pengekodan panjang jalan Huffman Terubahsuai 1-Dimensi Kumpulan 3 CCITT',
'exif-compression-3' => 'Pengekodan faks Kumpulan 3 CCITT',
'exif-compression-4' => 'Pengekodan faks Kumpulan 4 CCITT',

'exif-copyrighted-true' => 'Berhak cipta',
'exif-copyrighted-false' => 'Status hak cipta tidak ditetapkan',

'exif-unknowndate' => 'Tarikh tidak diketahui',

'exif-orientation-1' => 'Normal',
'exif-orientation-2' => 'Dibalikkan secara mengufuk',
'exif-orientation-3' => 'Diputar 180°',
'exif-orientation-4' => 'Dibalikkan secara menegak',
'exif-orientation-5' => 'Diputarkan 90° melawan arah jam dan dibalikkan secara menegak',
'exif-orientation-6' => 'Diputarkan 90° mengikut arah jam',
'exif-orientation-7' => 'Diputarkan 90° mengikut arah jam dan dibalikkan secara menegak',
'exif-orientation-8' => 'Diputarkan 90° melawan arah jam',

'exif-planarconfiguration-1' => 'format besar',
'exif-planarconfiguration-2' => 'format satah',

'exif-colorspace-65535' => 'Tidak tertentukur',

'exif-componentsconfiguration-0' => 'tiada',

'exif-exposureprogram-0' => 'Tidak ditentukan',
'exif-exposureprogram-1' => 'Manual',
'exif-exposureprogram-2' => 'Atur cara normal',
'exif-exposureprogram-3' => 'Mengutamakan bukaan',
'exif-exposureprogram-4' => 'Mengutamakan pengatup',
'exif-exposureprogram-5' => 'Atur cara kreatif (cenderung kepada kedalaman lapangan)',
'exif-exposureprogram-6' => 'Atur cara aksi (cenderung kepada kelajuan pengatup yang tinggi)',
'exif-exposureprogram-7' => 'Mod potret (untuk foto jarak dekat dengan latar belakang kabur)',
'exif-exposureprogram-8' => 'Mod landskap (untuk foto landskap dengan latar belakang terfokus)',

'exif-subjectdistance-value' => '$1 meter',

'exif-meteringmode-0' => 'Tidak diketahui',
'exif-meteringmode-1' => 'Purata',
'exif-meteringmode-2' => 'Purata cenderung ke pusat',
'exif-meteringmode-3' => 'Titik',
'exif-meteringmode-4' => 'Berbilang titik',
'exif-meteringmode-5' => 'Corak',
'exif-meteringmode-6' => 'Separa',
'exif-meteringmode-255' => 'Lain-lain',

'exif-lightsource-0' => 'Tidak diketahui',
'exif-lightsource-1' => 'Cahaya siang',
'exif-lightsource-2' => 'Pendarfluor',
'exif-lightsource-3' => 'Tungsten (lampu pijar)',
'exif-lightsource-4' => 'Denyar',
'exif-lightsource-9' => 'Cuaca cerah',
'exif-lightsource-10' => 'Cuaca mendung',
'exif-lightsource-11' => 'Gelap',
'exif-lightsource-12' => 'Pendarfluor cahaya siang (D 5700 – 7100K)',
'exif-lightsource-13' => 'Pendarfluor putih siang (N 4600 – 5400K)',
'exif-lightsource-14' => 'Pendarfluor putih sejuk (W 3900 – 4500K)',
'exif-lightsource-15' => 'Pendarfluor putih (WW 3200 – 3700K)',
'exif-lightsource-17' => 'Cahaya standard A',
'exif-lightsource-18' => 'Cahaya standard B',
'exif-lightsource-19' => 'Cahaya standard C',
'exif-lightsource-24' => 'Tungsten studio ISO',
'exif-lightsource-255' => 'Sumber cahaya lain',

# Flash modes
'exif-flash-fired-0' => 'Denyar tidak bernyala',
'exif-flash-fired-1' => 'Denyar dinyalakan',
'exif-flash-return-0' => 'tiada pengesan pulangan strob',
'exif-flash-return-2' => 'cahaya pulang strob tidak dikesan',
'exif-flash-return-3' => 'cahaya pulang strob dikesan',
'exif-flash-mode-1' => 'nyalaan denyar wajib',
'exif-flash-mode-2' => 'tindasan denyar wajib',
'exif-flash-mode-3' => 'mod automatik',
'exif-flash-function-1' => 'Tiada fungsi denyar',
'exif-flash-redeye-1' => 'mod penurunan mata merah',

'exif-focalplaneresolutionunit-2' => 'inci',

'exif-sensingmethod-1' => 'Tidak ditentukan',
'exif-sensingmethod-2' => 'Penderia kawasan warna cip tunggal',
'exif-sensingmethod-3' => 'Penderia kawasan warna dwicip',
'exif-sensingmethod-4' => 'Penderia kawasan warna tricip',
'exif-sensingmethod-5' => 'Penderia kawasan warna berjujukan',
'exif-sensingmethod-7' => 'Penderia trilinear',
'exif-sensingmethod-8' => 'Penderia linear warna berjujukan',

'exif-filesource-3' => 'Kamera pegun digital',

'exif-scenetype-1' => 'Gambar yang diambil secara terus',

'exif-customrendered-0' => 'Proses biasa',
'exif-customrendered-1' => 'Proses tempahan',

'exif-exposuremode-0' => 'Pendedahan automatik',
'exif-exposuremode-1' => 'Pendedahan manual',
'exif-exposuremode-2' => 'Braket automatik',

'exif-whitebalance-0' => 'Imbangan warna putih automatik',
'exif-whitebalance-1' => 'Imbangan warna putih manual',

'exif-scenecapturetype-0' => 'Standard',
'exif-scenecapturetype-1' => 'Landskap',
'exif-scenecapturetype-2' => 'Potret',
'exif-scenecapturetype-3' => 'Malam',

'exif-gaincontrol-0' => 'Tiada',
'exif-gaincontrol-1' => 'Gandaan rendah atas',
'exif-gaincontrol-2' => 'Gandaan tinggi atas',
'exif-gaincontrol-3' => 'Gandaan rendah bawah',
'exif-gaincontrol-4' => 'Gandaan tinggi bawah',

'exif-contrast-0' => 'Normal',
'exif-contrast-1' => 'Lembut',
'exif-contrast-2' => 'Keras',

'exif-saturation-0' => 'Normal',
'exif-saturation-1' => 'Kepekatan rendah',
'exif-saturation-2' => 'Kepekatan tinggi',

'exif-sharpness-0' => 'Normal',
'exif-sharpness-1' => 'Lembut',
'exif-sharpness-2' => 'Keras',

'exif-subjectdistancerange-0' => 'Tidak diketahui',
'exif-subjectdistancerange-1' => 'Makro',
'exif-subjectdistancerange-2' => 'Pandangan dekat',
'exif-subjectdistancerange-3' => 'Pandangan jauh',

# Pseudotags used for GPSLatitudeRef and GPSDestLatitudeRef
'exif-gpslatitude-n' => 'Latitud utara',
'exif-gpslatitude-s' => 'Latitud selatan',

# Pseudotags used for GPSLongitudeRef and GPSDestLongitudeRef
'exif-gpslongitude-e' => 'Longitud timur',
'exif-gpslongitude-w' => 'Longitud barat',

# Pseudotags used for GPSAltitudeRef
'exif-gpsaltitude-above-sealevel' => '$1 meter di atas aras laut',
'exif-gpsaltitude-below-sealevel' => '$1 meter di bawah paras laut',

'exif-gpsstatus-a' => 'Pengukuran sedang dijalankan',
'exif-gpsstatus-v' => 'Interoperabiliti pengukuran',

'exif-gpsmeasuremode-2' => 'Pengukuran dua dimensi',
'exif-gpsmeasuremode-3' => 'Pengukuran tiga dimensi',

# Pseudotags used for GPSSpeedRef
'exif-gpsspeed-k' => 'Kilometer sejam',
'exif-gpsspeed-m' => 'Batu sejam',
'exif-gpsspeed-n' => 'Knot',

# Pseudotags used for GPSDestDistanceRef
'exif-gpsdestdistance-k' => 'Kilometer',
'exif-gpsdestdistance-m' => 'Batu',
'exif-gpsdestdistance-n' => 'Batu nautika',

'exif-gpsdop-excellent' => 'Cemerlang ($1)',
'exif-gpsdop-good' => 'Bagus ($1)',
'exif-gpsdop-moderate' => 'Sederhana ($1)',
'exif-gpsdop-fair' => 'Ala kadar ($1)',
'exif-gpsdop-poor' => 'Tidak memuaskan ($1)',

'exif-objectcycle-a' => 'Pagi sahaja',
'exif-objectcycle-p' => 'Petang sahaja',
'exif-objectcycle-b' => 'Pagi dan petang',

# Pseudotags used for GPSTrackRef, GPSImgDirectionRef and GPSDestBearingRef
'exif-gpsdirection-t' => 'Arah benar',
'exif-gpsdirection-m' => 'Arah magnet',

'exif-ycbcrpositioning-1' => 'Terpusat',
'exif-ycbcrpositioning-2' => 'Sama tapak',

'exif-dc-contributor' => 'Penyumbang',
'exif-dc-coverage' => 'Skop ruangan atau masa media',
'exif-dc-date' => 'Tarikh',
'exif-dc-publisher' => 'Penerbit',
'exif-dc-relation' => 'Media berkaitan',
'exif-dc-rights' => 'Hak',
'exif-dc-source' => 'Media sumber',
'exif-dc-type' => 'Jenis media',

'exif-rating-rejected' => 'Ditolak',

'exif-isospeedratings-overflow' => 'Melebihi 65535',

'exif-iimcategory-ace' => 'Seni, kebudayaan dan hiburan',
'exif-iimcategory-clj' => 'Jenayah dan undang-undang',
'exif-iimcategory-dis' => 'Bencana dan kemalangan',
'exif-iimcategory-fin' => 'Ekonomi dan perniagaan',
'exif-iimcategory-edu' => 'Pendidikan',
'exif-iimcategory-evn' => 'Alam sekitar',
'exif-iimcategory-hth' => 'Kesihatan',
'exif-iimcategory-hum' => 'Pesona',
'exif-iimcategory-lab' => 'Pekerja',
'exif-iimcategory-lif' => 'Gaya hidup dan santai',
'exif-iimcategory-pol' => 'Politik',
'exif-iimcategory-rel' => 'Agama dan kepercayaan',
'exif-iimcategory-sci' => 'Sains dan teknologi',
'exif-iimcategory-soi' => 'Isu sosial',
'exif-iimcategory-spo' => 'Sukan',
'exif-iimcategory-war' => 'Peperangan, konflik dan pergolakan',
'exif-iimcategory-wea' => 'Cuaca',

'exif-urgency-normal' => 'Biasa ($1)',
'exif-urgency-low' => 'Rendah ($1)',
'exif-urgency-high' => 'Tinggi ($1)',
'exif-urgency-other' => 'Keutamaan tentuan pengguna ($1)',

# External editor support
'edit-externally' => 'Sunting fail ini menggunakan perisian luar',
'edit-externally-help' => '(Lihat [//www.mediawiki.org/wiki/Manual:External_editors arahan pemasangan] untuk maklumat lanjut)',

# 'all' in various places, this might be different for inflected languages
'watchlistall2' => 'semua',
'namespacesall' => 'semua',
'monthsall' => 'semua',
'limitall' => 'semua',

# Email address confirmation
'confirmemail' => 'Sahkan alamat e-mel',
'confirmemail_noemail' => 'Anda belum menetapkan alamat e-mel yang sah dalam [[Special:Preferences|laman keutamaan]] anda.',
'confirmemail_text' => '{{SITENAME}} menghendaki supaya anda mengesahkan alamat e-mel anda sebelum menggunakan ciri-ciri e-mel.
Aktifkan butang di bawah untuk mengirim e-mel pengesahan kepada alamat e-mel
anda. E-mel tersebut akan mengandungi sebuah pautan yang mengandungi sebuah
kod; buka pautan tersebut di pelayar anda untuk mengesahkan bahawa alamat e-mel anda.',
'confirmemail_pending' => 'Sebuah kod pengesahan telah pun di-e-melkan kepada anda. Jika anda baru sahaja
membuka akaun, sila tunggu kehadiran e-mel tersebut selama beberapa minit
sebelum meminta kod baru.',
'confirmemail_send' => 'E-melkan kod pengesahan',
'confirmemail_sent' => 'E-mel pengesahan dikirim.',
'confirmemail_oncreate' => 'Sebuah kod pengesahan telah dikirim kepada alamat e-mel anda.
Kod ini tidak diperlukan untuk log masuk, akan tetapi anda perlu menyediakannya untuk
mengaktifkan ciri-ciri e-mel yang terdapat dalam wiki ini.',
'confirmemail_sendfailed' => '{{SITENAME}} tidak dapat menghantar e-mel pengesahan anda. Sila semak alamat e-mel tersebut.

Pelayan mel memulangkan: $1',
'confirmemail_invalid' => 'Kod pengesahan tidak sah. Kod tersebut mungkin sudah luput.',
'confirmemail_needlogin' => 'Anda perlu $1 terlebih dahulu untuk mengesahkan alamat e-mel anda.',
'confirmemail_success' => 'Alamat e-mel anda telah disahkan. Sekarang anda boleh melog masuk dan berseronok di wiki ini.',
'confirmemail_loggedin' => 'Alamat e-mel anda telah disahkan.',
'confirmemail_error' => 'Sesuatau yang tidak kena berlaku ketika kami menyimpan pengesahan anda.',
'confirmemail_subject' => 'Pengesahan alamat e-mel di {{SITENAME}}',
'confirmemail_body' => 'Seseorang, barangkali anda, dari alamat IP $1, telah mendaftarkan akaun "$2" dengan alamat e-mel ini di {{SITENAME}}.

Untuk mengesahkan bahawa akaun ini milik anda dan untuk mengaktifkan kemudahan e-mel di {{SITENAME}}, sila buka pautan ini dalam pelayar web anda:

$3

Jika anda tidak mendaftar di {{SITENAME}} (atau anda telah mendaftar menggunakan alamat e-mel lain), ikuti pautan ini untuk membatalkan pengesahan alamat e-mel:

$5

Kod pengesahan ini akan luput pada $4.',
'confirmemail_body_changed' => 'Seseorang, barangkali anda, dari alamat IP $1, telah menukarkan alamat e-mel bagi akaun "$2" menjadi alamat e-mel ini di {{SITENAME}}.

Untuk mengesahkan bahawa akaun ini milik anda dan untuk mengaktifkan semula kemudahan e-mel di {{SITENAME}}, sila buka pautan ini dalam pelayar web anda:

$3

Jika akaun ini *bukan* milik anda, ikuti pautan ini untuk membatalkan pengesahan alamat e-mel:

$5

Kod pengesahan ini akan luput pada $4.',
'confirmemail_body_set' => 'Seseorang, barangkali anda, dari alamat IP $1, telah set semula akaun "$2" kepada alamat ini di {{SITENAME}}.

Untuk mengesahkan bahawa akaun ini milik anda dan untuk mengaktifkan kemudahan e-mel di {{SITENAME}}, sila buka pautan ini dalam pelayar web anda:

$3

Jika akaun tersebut *bukan* kepunyaan anda, ikuti pautan ini untuk membatalkan pengesahan alamat e-mel:

$5

Kod pengesahan ini akan luput pada $4.',
'confirmemail_invalidated' => 'Pengesahan alamat e-mel telah dibatalkan',
'invalidateemail' => 'Batalkan pengesahan e-mel',

# Scary transclusion
'scarytranscludedisabled' => '[Penyertaan pautan interwiki dilumpuhkan]',
'scarytranscludefailed' => '[Gagal mendapatkan templat $1]',
'scarytranscludefailed-httpstatus' => '[Ambilan templat gagal untuk $1: HTTP $2]',
'scarytranscludetoolong' => '[URL terlalu panjang]',

# Delete conflict
'deletedwhileediting' => "'''Amaran''': Laman ini dihapuskan ketika anda sedang menyuntingnya!",
'confirmrecreate' => "Pengguna [[User:$1|$1]] ([[User talk:$1|perbincangan]]) telah menghapuskan laman ini ketika anda sedang menyunting atas sebab berikut:
: ''$2''
Sila sahkan bahawa anda mahu mencipta semula laman ini.",
'confirmrecreate-noreason' => 'Pengguna [[User:$1|$1]] ([[User talk:$1|bincang]]) menghapuskan laman ini selepas anda mulai menyunting. Sila sahkan bahawa anda betul-betul ingin mencipta semula laman ini.',
'recreate' => 'Cipta semula',

# action=purge
'confirm_purge_button' => 'OK',
'confirm-purge-top' => 'Kosongkan fail simpanan bagi laman ini?',
'confirm-purge-bottom' => 'Kosongkan cache dan papar versi semasa.',

# action=watch/unwatch
'confirm-watch-button' => 'OK',
'confirm-watch-top' => 'Tambahkan laman ini ke dalam senarai pantau anda?',
'confirm-unwatch-button' => 'OK',
'confirm-unwatch-top' => 'Buang laman ini daripada senarai pantau anda?',

# Multipage image navigation
'imgmultipageprev' => '← halaman sebelumnya',
'imgmultipagenext' => 'halaman berikutnya →',
'imgmultigo' => 'Pergi!',
'imgmultigoto' => 'Pergi ke halaman $1',

# Table pager
'ascending_abbrev' => 'menaik',
'descending_abbrev' => 'menurun',
'table_pager_next' => 'Muka berikutnya',
'table_pager_prev' => 'Muka sebelumnya',
'table_pager_first' => 'Muka pertama',
'table_pager_last' => 'Muka terakhir',
'table_pager_limit' => 'Papar $1 item setiap muka',
'table_pager_limit_label' => 'Bilangan item setiap laman:',
'table_pager_limit_submit' => 'Pergi',
'table_pager_empty' => 'Tiada hasil',

# Auto-summaries
'autosumm-blank' => 'Mengosongkan laman',
'autosumm-replace' => "Mengganti laman dengan '$1'",
'autoredircomment' => 'Melencong ke [[$1]]',
'autosumm-new' => "Mencipta laman baru dengan kandungan '$1'",

# Live preview
'livepreview-loading' => 'Memuatkan...',
'livepreview-ready' => 'Memuat … Sedia!',
'livepreview-failed' => 'Pralihat langsung gagal! Sila gunakan pralihat biasa.',
'livepreview-error' => 'Gagal membuat sambungan: $1 "$2". Sila gunakan pralihat biasa.',

# Friendlier slave lag warnings
'lag-warn-normal' => 'Sebarang perubahan baru yang melebihi $1 saat mungkin tidak ditunjukkan dalam senarai ini.',
'lag-warn-high' => 'Disebabkan oleh kelambatan pelayan pangkalan data, sebarang perubahan baru yang melebihi $1 saat mungkin tidak ditunjukkan dalam senarai ini.',

# Watchlist editor
'watchlistedit-numitems' => 'Senarai pantau anda mengandungi $1 tajuk (tidak termasuk laman perbincangan).',
'watchlistedit-noitems' => 'Tiada tajuk dalam senarai pantau anda.',
'watchlistedit-normal-title' => 'Sunting senarai pantau',
'watchlistedit-normal-legend' => 'Buang tajuk-tajuk ini dari senarai pantau',
'watchlistedit-normal-explain' => 'Tajuk-tajuk dalam senarai pantau anda ditunjukkan di bawah.
Untuk membuang mana-mana tajuk, tanda kotak yang terletak di sebelahnya, dan klik "Buang Tajuk". Anda juga boleh [[Special:EditWatchlist/raw|menyunting senarai mentah]].',
'watchlistedit-normal-submit' => 'Gugurkan tajuk-tajuk',
'watchlistedit-normal-done' => '$1 tajuk dibuang daripada senarai pantau anda:',
'watchlistedit-raw-title' => 'Sunting senarai pantau mentah',
'watchlistedit-raw-legend' => 'Sunting senarai pantau mentah',
'watchlistedit-raw-explain' => 'Tajuk-tajuk dalam senarai pantau anda dipaparkan di bawah, dan boleh disunting dengan menambah atau membuang daripada senarai tersebut;
satu tajuk bagi setiap baris.
Apabila selesai, klik "{{int:Watchlistedit-raw-submit}}".
Anda juga boleh [[Special:EditWatchlist|menggunakan penyunting piawai]].',
'watchlistedit-raw-titles' => 'Tajuk:',
'watchlistedit-raw-submit' => 'Kemas Kini Senarai Pantau',
'watchlistedit-raw-done' => 'Senarai pantau anda telah dikemaskinikan.',
'watchlistedit-raw-added' => '$1 tajuk ditambah:',
'watchlistedit-raw-removed' => '$1 tajuk telah dibuang:',

# Watchlist editing tools
'watchlisttools-view' => 'Lihat perubahan',
'watchlisttools-edit' => 'Sunting senarai pantau',
'watchlisttools-raw' => 'Sunting senarai pantau mentah',

# Hijri month names
'hijri-calendar-m1' => 'Muharam',
'hijri-calendar-m2' => 'Safar',
'hijri-calendar-m3' => 'Rabiulawal',
'hijri-calendar-m4' => 'Rabiulakhir',
'hijri-calendar-m5' => 'Jamadilawal',
'hijri-calendar-m6' => 'Jamadilakhir',
'hijri-calendar-m7' => 'Rejab',
'hijri-calendar-m8' => 'Syaaban',
'hijri-calendar-m9' => 'Ramadan',
'hijri-calendar-m10' => 'Syawal',
'hijri-calendar-m11' => 'Zulkaedah',
'hijri-calendar-m12' => 'Zulhijah',

# Signatures
'signature' => '[[{{ns:user}}:$1|$2]] ([[{{ns:user_talk}}:$1|bincang]])',

# Core parser functions
'unknown_extension_tag' => 'Tag penyambung "$1" tidak dikenali',
'duplicate-defaultsort' => '\'\'\'Amaran\'\'\': Kunci susunan asali "$2" membatalkan kunci susunan asali "$1" yang sebelumnya.',

# Special:Version
'version' => 'Versi',
'version-extensions' => 'Penyambung yang dipasang',
'version-specialpages' => 'Laman khas',
'version-parserhooks' => 'Penyangkuk penghurai',
'version-variables' => 'Pemboleh ubah',
'version-antispam' => 'Pencegahan spam',
'version-skins' => 'Rupa',
'version-other' => 'Lain-lain',
'version-mediahandlers' => 'Pengelola media',
'version-hooks' => 'Penyangkuk',
'version-parser-extensiontags' => 'Tag penyambung penghurai',
'version-parser-function-hooks' => 'Penyangkuk fungsi penghurai',
'version-hook-name' => 'Nama penyangkuk',
'version-hook-subscribedby' => 'Dilanggan oleh',
'version-version' => '(Versi $1)',
'version-license' => 'Lesen',
'version-poweredby-credits' => "Wiki ini dikuasakan oleh '''[//www.mediawiki.org/ MediaWiki]''', hak cipta © 2001-$1 $2.",
'version-poweredby-others' => 'penyumbang-penyumbang lain',
'version-poweredby-translators' => 'para penterjemah translatewiki.net',
'version-credits-summary' => 'Kami ingin mengucapkan sekalung budi kepada mereka yang berikut atas sumbangan mereka keada [[Special:Version|MediaWiki]].',
'version-license-info' => 'MediaWiki adalah perisian bebas; anda boleh mengedarkannya semula dan/atau mengubah suainya di bawah terma-terma Lesen Awam GNU sebagai mana yang telah diterbitkan oleh Yayasan Perisian Bebas, sama ada versi 2 bagi Lesen tersebut, atau (berdasarkan pilihan anda) mana-mana versi selepasnya.

MediaWiki diedarkan dengan harapan bahawa ia berguna, tetapi TANPA SEBARANG WARANTI; hatta waranti yang tersirat bagi KEBOLEHDAGANGAN mahupun KESESUAIAN UNTUK TUJUAN TERTENTU. Sila lihat Lesen Awam GNU untuk butiran lanjut.

Anda patut telah menerima [{{SERVER}}{{SCRIPTPATH}}/COPYING sebuah salinan bagi Lesen Awam GNU] bersama-sama dengan atur cara ini; jika tidak, tulis ke Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA atau [//www.gnu.org/licenses/old-licenses/gpl-2.0.html baca dalam talian].',
'version-software' => 'Perisian yang dipasang',
'version-software-product' => 'Produk',
'version-software-version' => 'Versi',
'version-entrypoints' => 'URL titik permulaan',
'version-entrypoints-header-entrypoint' => 'Titik permulaan',
'version-entrypoints-header-url' => 'URL',
'version-entrypoints-articlepath' => '[https://www.mediawiki.org/wiki/Manual:$wgArticlePath Laluan rencana]',
'version-entrypoints-scriptpath' => '[https://www.mediawiki.org/wiki/Manual:$wgScriptPath Laluan skrip]',

# Special:Redirect
'redirect' => 'Lencongkan mengikut fail, ID pengguna atau ID semakan',
'redirect-legend' => 'Lencongkan ke fail atau halaman',
'redirect-summary' => 'Halaman khas ini melencong kepada fail (dengan nama fail), halaman (dengan ID semakan) atau halaman pengguna (dengan ID pengguna berangka).',
'redirect-submit' => 'Pergi',
'redirect-lookup' => 'Cari:',
'redirect-value' => 'Nilai:',
'redirect-user' => 'ID Pengguna',
'redirect-revision' => 'Semakan halaman',
'redirect-file' => 'Nama fail',
'redirect-not-exists' => 'Nilai tidak dijumpai',

# Special:FileDuplicateSearch
'fileduplicatesearch' => 'Cari fail serupa',
'fileduplicatesearch-summary' => 'Anda boleh mencari fail serupa berdasarkan nilai cincangannya.',
'fileduplicatesearch-legend' => 'Cari fail serupa',
'fileduplicatesearch-filename' => 'Nama fail:',
'fileduplicatesearch-submit' => 'Cari',
'fileduplicatesearch-info' => '$1 × $2 piksel<br />Saiz fail: $3<br />Jenis MIME: $4',
'fileduplicatesearch-result-1' => 'Tiada fail yang serupa dengan "$1".',
'fileduplicatesearch-result-n' => 'Terdapat $2 fail yang serupa dengan "$1".',
'fileduplicatesearch-noresults' => 'Tidak ada gambar-gambar dengan nama "$1" dijumpai.',

# Special:SpecialPages
'specialpages' => 'Laman khas',
'specialpages-note' => '----
* Laman khas biasa.
* <span class="mw-specialpagerestricted">Laman khas terhad.</span>
* <span class="mw-specialpagecached">Laman khas tercache (mungkin lapuk).</span>',
'specialpages-group-maintenance' => 'Laporan penyenggaraan',
'specialpages-group-other' => 'Laman khas lain',
'specialpages-group-login' => 'Log masuk / buka akaun',
'specialpages-group-changes' => 'Perubahan terkini dan log',
'specialpages-group-media' => 'Laporan media dan muat naik',
'specialpages-group-users' => 'Pengguna dan hak',
'specialpages-group-highuse' => 'Laman popular',
'specialpages-group-pages' => 'Senarai laman',
'specialpages-group-pagetools' => 'Alatan laman',
'specialpages-group-wiki' => 'Data dan peralatan',
'specialpages-group-redirects' => 'Laman khas yang melencong',
'specialpages-group-spam' => 'Alatan spam',

# Special:BlankPage
'blankpage' => 'Laman kosong',
'intentionallyblankpage' => 'Laman ini sengaja dibiarkan kosong dan digunakan untuk kerja-kerja ujian dan sebagainya.',

# External image whitelist
'external_image_whitelist' => ' #Jangan ubah baris ini<pre>
#Letakkan senarai ungkapan nalar (tidak termasuk apitan //) di baris kosong di bawah
#Setiap ungkapan akan dipadankan dengan pautan imej luar
#Pautan yang sepadan sahaja akan dijadikan imej, jika tidak hanya pautan kepada imej akan muncul
#Baris yang bermula dengan aksara # diabaikan
#Ini sensitif kepada atur huruf

#Jangan letak ungkapan nalar di bawah baris ini dan jangan ubah baris ini</pre>',

# Special:Tags
'tags' => 'Label perubahan yang sah',
'tag-filter' => 'Tapis [[Special:Tags|label]]:',
'tag-filter-submit' => 'Tapis',
'tag-list-wrapper' => '([[Special:Tags|{{PLURAL:$1|Teg}}]]: $2)',
'tags-title' => 'Label',
'tags-intro' => 'Yang berikut ialah senarai label yang digunakan untuk menanda suntingan, berserta maknanya.',
'tags-tag' => 'Nama label',
'tags-display-header' => 'Rupa dalam senarai perubahan',
'tags-description-header' => 'Keterangan makna',
'tags-hitcount-header' => 'Perubahan',
'tags-edit' => 'sunting',
'tags-hitcount' => '$1 perubahan',

# Special:ComparePages
'comparepages' => 'Perbandingan laman',
'compare-selector' => 'Bandingkan semakan laman',
'compare-page1' => 'Laman 1',
'compare-page2' => 'Laman 2',
'compare-rev1' => 'Semakan 1',
'compare-rev2' => 'Semakan 2',
'compare-submit' => 'Bandingkan',
'compare-invalid-title' => 'Tajuk yang anda nyatakan tidak sah.',
'compare-title-not-exists' => 'Tajuk yang anda nyatakan tidak wujud.',
'compare-revision-not-exists' => 'Semakan yang anda nyatakan tidak wujud.',

# Database error messages
'dberr-header' => 'Wiki ini dilanda masalah',
'dberr-problems' => 'Harap maaf. Tapak web ini dilanda masalah teknikal.',
'dberr-again' => 'Cuba tunggu selama beberapa minit dan muat semula.',
'dberr-info' => '(Tidak dapat menghubungi pelayan pangkalan data: $1)',
'dberr-info-hidden' => '(Pelayan pangkalan data tidak dapat dihubungi)',
'dberr-usegoogle' => 'Buat masa ini, anda boleh cuba mencari melalui Google.',
'dberr-outofdate' => 'Sila ambil perhatian bahawa indeks mereka bagi kandungan kami mungkin sudah ketinggalan zaman.',
'dberr-cachederror' => 'Yang berikut ialah salinan bagi laman yang diminta yang diambil daripada cache, dan mungkin bukan yang terkini.',

# HTML forms
'htmlform-invalid-input' => 'Terdapat beberapa masalah dengan input anda',
'htmlform-select-badoption' => 'Nilai yang anda tentukan bukan satu pilihan yang sah.',
'htmlform-int-invalid' => 'Nilai yang anda tetapkan bukan satu integer.',
'htmlform-float-invalid' => 'Nilai yang anda nyatakan bukan nombor.',
'htmlform-int-toolow' => 'Nilai yang anda nyatakan berada di bawah minimum bagi $1',
'htmlform-int-toohigh' => 'Nilai yang anda nyatakan berada di atas maksimum bagi $1',
'htmlform-required' => 'Nilai ini adalah wajib',
'htmlform-submit' => 'Hantar',
'htmlform-reset' => 'Undur perubahan',
'htmlform-selectorother-other' => 'Lain-lain',
'htmlform-no' => 'Tidak',
'htmlform-yes' => 'Ya',
'htmlform-chosen-placeholder' => 'Pilih satu pilihan',

# SQLite database support
'sqlite-has-fts' => '$1 dengan sokongan carian teks penuh',
'sqlite-no-fts' => '$1 tanpa sokongan carian teks penuh',

# New logging system
'logentry-delete-delete' => '$1 telah {{GENDER:$2|menghapuskan}} halaman $3',
'logentry-delete-restore' => '$1 telah {{GENDER:$2|memulihkan}} halaman $3',
'logentry-delete-event' => '$1 telah {{GENDER:$2|mengubah}} keterlihatan $5 peristiwa log di $3: $4',
'logentry-delete-revision' => '$1 telah {{GENDER:$2|mengubah}} keterlihatan $5 semakan di halaman $3: $4',
'logentry-delete-event-legacy' => '$1 telah {{GENDER:$2|mengubah}} keterlihatan peristiwa log di $3',
'logentry-delete-revision-legacy' => '$1 telah {{GENDER:$2|mengubah}} keterlihatan semakan di halaman $3',
'logentry-suppress-delete' => '$1 telah {{GENDER:$2|menyekat}} halaman $3',
'logentry-suppress-event' => '$1 telah {{GENDER:$2|mengubah}} keterlihatan $5 peristiwa log di $3 secara senyap: $4',
'logentry-suppress-revision' => '$1 telah {{GENDER:$2|mengubah}} keterlihatan $5 semakan di halaman $3 secara senyap: $4',
'logentry-suppress-event-legacy' => '$1 telah {{GENDER:$2|mengubah}} keterlihatan peristiwa log di $3 secara senyap',
'logentry-suppress-revision-legacy' => '$1 telah {{GENDER:$2|mengubah}} keterlihatan semakan di halaman $3 secara senyap',
'revdelete-content-hid' => 'kandungan tersorok',
'revdelete-summary-hid' => 'ringkasan suntingan tersorok',
'revdelete-uname-hid' => 'nama pengguna tersorok',
'revdelete-content-unhid' => 'kandungan terdedah',
'revdelete-summary-unhid' => 'ringkasan suntingan terdedah',
'revdelete-uname-unhid' => 'nama pengguna terdedah',
'revdelete-restricted' => 'mengenakan sekatan pada penyelia',
'revdelete-unrestricted' => 'menarik sekatan daripada penyelia',
'logentry-move-move' => '$1 telah {{GENDER:$2|memindahkan}} halaman $3 ke $4',
'logentry-move-move-noredirect' => '$1 telah {{GENDER:$2|memindahkan}} halaman $3 ke $4 tanpa meninggalkan lencongan',
'logentry-move-move_redir' => '$1 telah {{GENDER:$2|memindahkan}} halaman $3 ke $4 melalui lencongan',
'logentry-move-move_redir-noredirect' => '$1 telah {{GENDER:$2|memindahkan}} halaman $3 ke $4 melalui lencongan tanpa meninggalkan lencongan',
'logentry-patrol-patrol' => '$1 telah {{GENDER:$2|menanda}} semakan $4 di halaman $3 sebagai dironda',
'logentry-patrol-patrol-auto' => '$1 telah {{GENDER:$2|menanda}} semakan $4 di halaman $3 sebagai dironda secara automatik',
'logentry-newusers-newusers' => 'Akaun pengguna $1 telah {{GENDER:$2|dibuka}}',
'logentry-newusers-create' => 'Akaun pengguna $1 telah {{GENDER:$2|dibuka}}',
'logentry-newusers-create2' => 'Akaun pengguna $3 telah {{GENDER:$2|dibuka}} oleh $1',
'logentry-newusers-byemail' => 'Akaun pengguna $3 telah {{GENDER:$2|dibuka}} oleh $1 dan kata laluannya dihantar melalui e-mel',
'logentry-newusers-autocreate' => 'Akaun pengguna $1 telah {{GENDER:$2|dibuka}} secara automatik',
'logentry-rights-rights' => '$1 telah {{GENDER:$2|menukar}} keahlian kumpulan untuk $3 dari $4 ke $5',
'logentry-rights-rights-legacy' => '$1 telah {{GENDER:$2|menukar}} keahlian kumpulan untuk $3',
'logentry-rights-autopromote' => '$1 telah {{GENDER:$2|dinaik pangkat}} secara automatik dari $4 ke $5',
'rightsnone' => '(tiada)',

# Feedback
'feedback-bugornote' => 'Jika anda bersedia untuk menerangkan masalah teknikal secara terperinci, sila [$1 laporkan pepijat]. 
Ataupun, anda boleh menggunakan borang yang mudah di bawah. Ulasan anda akan dicatatkan pada laman "[$3 $2]", beserta nama pengguna anda dan pelayar yang anda gunakan.',
'feedback-subject' => 'Perkara:',
'feedback-message' => 'Pesanan:',
'feedback-cancel' => 'Batalkan',
'feedback-submit' => 'Hantar Maklum Balas',
'feedback-adding' => 'Maklum balas sedang diisikan ke dalam laman...',
'feedback-error1' => 'Perhatian: Hasil dari API tidak dikenali',
'feedback-error2' => 'Perhatian: Penyuntingan gagal',
'feedback-error3' => 'Perhatian: Tiada gerak balas dari API',
'feedback-thanks' => 'Terima kasih! Maklum balas anda telah dicatatkan pada laman "[$2 $1]".',
'feedback-close' => 'Siap',
'feedback-bugcheck' => 'Bagus! Cuma pastikan itu bukan salah satu [$1 pepijat] yang sedia diketahui.',
'feedback-bugnew' => 'Saya dah semak. Laporkan pepijat baru',

# Search suggestions
'searchsuggest-search' => 'Cari',
'searchsuggest-containing' => 'mengandungi...',

# API errors
'api-error-badaccess-groups' => 'Anda tidak dibenarkan memuat naik fail di wiki ini.',
'api-error-badtoken' => 'Ralat dalaman: token tak elok.',
'api-error-copyuploaddisabled' => 'Ciri memuat naik melalui URL dimatikan di pelayan ini.',
'api-error-duplicate' => 'Di tapak ini sudah ada {{PLURAL:$1|[$2 satu fail lain]|[$2 fail-fail lain]}} yang sama kandungannya.',
'api-error-duplicate-archive' => 'Di tapak ini pernah ada {{PLURAL:$1|[$2 satu fail lain]|[$2 fail-fail lain]}} yang sama kandungannya, tetapi telah dihapuskan.',
'api-error-duplicate-archive-popup-title' => '{{PLURAL:$1|Fail|Fail-fail}} pendua yang sudah dihapuskan',
'api-error-duplicate-popup-title' => '{{PLURAL:$1|Fail|Fail-fail}} pendua',
'api-error-empty-file' => 'Fail yang anda serahkan adalah kosong.',
'api-error-emptypage' => 'Anda tidak dibenarkan membuat laman baru yang kosong.',
'api-error-fetchfileerror' => 'Ralat dalaman: ada malasah ketika mengambil fail itu.',
'api-error-fileexists-forbidden' => 'Fail bernama "$1" sudah wujud, dan tidak boleh ditulis ganti.',
'api-error-fileexists-shared-forbidden' => 'Fail bernama "$1" sudah wujud dalam repositori fail kongsian, dan tidak boleh ditulis ganti.',
'api-error-file-too-large' => 'Fail yang anda serahkan adalah terlalu besar.',
'api-error-filename-tooshort' => 'Nama fail ini terlalu pendek.',
'api-error-filetype-banned' => 'Fail jenis ini adalah dilarang.',
'api-error-filetype-banned-type' => '$1 merupakan {{PLURAL:$4|jenis|jenis-jenis}} fail yang dilarang. {{PLURAL:$3|Jenis|Jenis-jenis}} fail yang dibenarkan ialah $2.',
'api-error-filetype-missing' => 'Fail ini tiada sambungannya.',
'api-error-hookaborted' => 'Pengubahsuaian yang anda buat telah disekat oleh cangkuk sambungan.',
'api-error-http' => 'Ralat dalaman: tidak dapat bersambung dengan pelayan.',
'api-error-illegal-filename' => 'Nama fail ini tidak dibenarkan.',
'api-error-internal-error' => 'Ralat dalaman: ada masalah ketika memproseskan muat naik anda di wiki ini.',
'api-error-invalid-file-key' => 'Ralat dalaman: fail tidak dijumpai dalam storan sementara.',
'api-error-missingparam' => 'Ralat dalaman: kekosongan parameter pada permohonan.',
'api-error-missingresult' => 'Ralat dalaman: tidak dapat ditentukan sama ada penyalinan berjaya.',
'api-error-mustbeloggedin' => 'Anda mesti log masuk untuk memuat naik fail.',
'api-error-mustbeposted' => 'Ralat dalaman: permohonan memerlukan POST HTTP.',
'api-error-noimageinfo' => 'Muat naik berjaya, tetapi pelayan tidak memberi kita sebarang maklumat tentang fail itu.',
'api-error-nomodule' => 'Ralat dalaman: tiada modul muat naik yang ditetapkan.',
'api-error-ok-but-empty' => 'Ralat dalaman: tiada gerak balas dari pelayan.',
'api-error-overwrite' => 'Menulis ganti fail yang telah wujud adalah tidak dibenarkan.',
'api-error-stashfailed' => 'Ralat dalaman: pelayan tidak dapat menyimpan fail sementara.',
'api-error-publishfailed' => 'Ralat dalaman: Pelayan tidak dapat menerbitkan fail sementara.',
'api-error-timeout' => 'Pelayan tidak bergerak balas dalam tempoh yang diharapkan.',
'api-error-unclassified' => 'Berlakunya ralat yang tidak diketahui',
'api-error-unknown-code' => 'Ralat tidak diketahui: "$1"',
'api-error-unknown-error' => 'Ralat dalaman: ada masalah apabila cuba memuat naik fail anda.',
'api-error-unknown-warning' => 'Amaran tidak diketahui: $1',
'api-error-unknownerror' => 'Ralat tidak dikenali: "$1".',
'api-error-uploaddisabled' => 'Ciri muat naik dimatikan di wiki ini.',
'api-error-verification-error' => 'Fail ini mungkin tercemar atau tersalah sambungannya.',

# Durations
'duration-seconds' => '$1 saat',
'duration-minutes' => '$1 minit',
'duration-hours' => '$1 jam',
'duration-days' => '$1 hari',
'duration-weeks' => '$1 minggu',
'duration-years' => '$1 tahun',
'duration-decades' => '$1 dekad',
'duration-centuries' => '$1 abad',
'duration-millennia' => '$1 alaf',

# Image rotation
'rotate-comment' => 'Imej diputar sebanyak $1 {{PLURAL:$1|darjah|darjah}} mengikut arah jam',

# Limit report
'limitreport-title' => 'Data pemprofilan penghurai:',
'limitreport-cputime' => 'Penggunaan masa CPU',
'limitreport-cputime-value' => '$1 saat',
'limitreport-walltime' => 'Penggunaan masa nyata',
'limitreport-walltime-value' => '$1 saat',
'limitreport-ppvisitednodes' => 'Kiraan nod kunjungan pempraproses',
'limitreport-ppgeneratednodes' => 'Kiraan nod hasilan pempraproses',
'limitreport-postexpandincludesize' => 'Saiz selepas peluasan',
'limitreport-postexpandincludesize-value' => '$1/$2 {{PLURAL:$2|bait}}',
'limitreport-templateargumentsize' => 'Saiz parameter templat',
'limitreport-templateargumentsize-value' => '$1/$2 {{PLURAL:$2|bait}}',
'limitreport-expansiondepth' => 'Kedalaman peluasan terjauh',
'limitreport-expensivefunctioncount' => 'Kiraan fungsi penghurai muatan tinggi',

);
