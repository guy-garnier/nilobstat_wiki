<?php
/** Malagasy (Malagasy)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Alno
 * @author Hoo
 * @author Jagwar
 * @author The Evil IP address
 * @author Urhixidur
 * @author לערי ריינהארט
 */

$magicWords = array(
	'redirect'                  => array( '0', '#FIHODINANA', '#REDIRECTION', '#REDIRECT' ),
	'notoc'                     => array( '0', '__TSYASIANALAHATRA__', '__AUCUNSOMMAIRE__', '__AUCUNETDM__', '__NOTOC__' ),
	'nogallery'                 => array( '0', '__TSYASIANAGALLERY__', '__AUCUNEGALERIE__', '__NOGALLERY__' ),
	'forcetoc'                  => array( '0', '__TEREONYLAHATRA__', '__FORCERSOMMAIRE__', '__FORCERTDM__', '__FORCETOC__' ),
	'toc'                       => array( '0', '__LAHATRA__', '__LAHAT__', '__SOMMAIRE__', '__TDM__', '__TOC__' ),
	'noeditsection'             => array( '0', '__TSYAZOOVAINA__', '__SECTIONNONEDITABLE__', '__NOEDITSECTION__' ),
	'currentmonth'              => array( '1', 'VOLANA', 'MOISACTUEL', 'MOIS2ACTUEL', 'CURRENTMONTH', 'CURRENTMONTH2' ),
	'currentmonth1'             => array( '1', 'VOLANA1', 'MOIS1ACTUEL', 'CURRENTMONTH1' ),
	'currentmonthname'          => array( '1', 'ANARAMBOLANA', 'NOMMOISACTUEL', 'CURRENTMONTHNAME' ),
	'currentmonthnamegen'       => array( '1', 'ANARAMBOLANAGEN', 'ANARANAVOLANA', 'CURRENTMONTHNAME', 'NOMGENMOISACTUEL', 'CURRENTMONTHNAMEGEN' ),
	'currentmonthabbrev'        => array( '1', 'ANARAMBOLANAFOHY', 'ANARANAVOLANAFOHY', 'ABREVMOISACTUEL', 'CURRENTMONTHABBREV' ),
	'currentday'                => array( '1', 'ANDRO', 'JOURACTUEL', 'JOUR1ACTUEL', 'CURRENTDAY' ),
	'currentday2'               => array( '1', 'ANDRO2', 'JOUR2ACTUEL', 'CURRENTDAY2' ),
	'currentdayname'            => array( '1', 'ANARANANDRO', 'ANARANAANDRO', 'NOMJOURACTUEL', 'CURRENTDAYNAME' ),
	'currentyear'               => array( '1', 'TAONA', 'ANNEEACTUELLE', 'CURRENTYEAR' ),
	'currenttime'               => array( '1', 'LERA', 'HORAIREACTUEL', 'CURRENTTIME' ),
	'currenthour'               => array( '1', 'ORA', 'HEUREACTUELLE', 'CURRENTHOUR' ),
	'localmonth'                => array( '1', 'VOLANAANTOERANA', 'MOISLOCAL', 'MOIS2LOCAL', 'LOCALMONTH', 'LOCALMONTH2' ),
	'localmonth1'               => array( '1', 'VOLANAANTOERANA1', 'MOIS1LOCAL', 'LOCALMONTH1' ),
	'localmonthname'            => array( '1', 'ANARAMBOLANAANTOERANA', 'NOMMOISLOCAL', 'LOCALMONTHNAME' ),
	'localmonthnamegen'         => array( '1', 'ANARAMBOLANAANTOERANAGEN', 'NOMGENMOISLOCAL', 'LOCALMONTHNAMEGEN' ),
	'localmonthabbrev'          => array( '1', 'ANARAMBOLANAANTOERANAFOHY', 'ABREVMOISLOCAL', 'LOCALMONTHABBREV' ),
	'localday'                  => array( '1', 'ANDROANTOERANA', 'JOURLOCAL', 'JOUR1LOCAL', 'LOCALDAY' ),
	'localday2'                 => array( '1', 'ANDROANTOERANA2', 'JOUR2LOCAL', 'LOCALDAY2' ),
	'localdayname'              => array( '1', 'ANARANANDROANTOERANA', 'NOMJOURLOCAL', 'LOCALDAYNAME' ),
	'localyear'                 => array( '1', 'TAONAANTOERANA', 'ANNEELOCALE', 'LOCALYEAR' ),
	'localtime'                 => array( '1', 'LERAANTOERANA', 'HORAIRELOCAL', 'LOCALTIME' ),
	'localhour'                 => array( '1', 'ORAANTOERANA', 'HEURELOCALE', 'LOCALHOUR' ),
	'numberofpages'             => array( '1', 'ISAPEJY', 'NOMBREPAGES', 'NUMBEROFPAGES' ),
	'numberofarticles'          => array( '1', 'ISALAHATSORATRA', 'NOMBREARTICLES', 'NUMBEROFARTICLES' ),
	'numberoffiles'             => array( '1', 'ISARAKITRA', 'NOMBREFICHIERS', 'NUMBEROFFILES' ),
	'numberofusers'             => array( '1', 'ISAMPIKAMBANA', 'NOMBREUTILISATEURS', 'NUMBEROFUSERS' ),
	'numberofactiveusers'       => array( '1', 'ISAMPIKAMBANAMANOVA', 'NOMBREUTILISATEURSACTIFS', 'NUMBEROFACTIVEUSERS' ),
	'numberofedits'             => array( '1', 'ISAFANOVANA', 'NOMBREMODIFS', 'NUMBEROFEDITS' ),
	'numberofviews'             => array( '1', 'ISATOPIMASO', 'NOMBREVUES', 'NUMBEROFVIEWS' ),
	'pagename'                  => array( '1', 'ANARAMPEJY', 'ANARANAPEJY', 'NOMPAGE', 'PAGENAME' ),
	'pagenamee'                 => array( '1', 'ANARAMPEJYX', 'ANARANAPEJYX', 'NOMPAGEX', 'PAGENAMEE' ),
	'namespace'                 => array( '1', 'ANARANTSEHATRA', 'ANARANASEHATRA', 'ESPACENOMMAGE', 'NAMESPACE' ),
	'namespacee'                => array( '1', 'ANARANTSEHATRAX', 'ANARANASEHATRAX', 'ESPACENOMMAGEX', 'NAMESPACEE' ),
	'talkspace'                 => array( '1', 'PEJINDRESAKA', 'PEJYRESAKA', 'DINIKA', 'ESPACEDISCUSSION', 'TALKSPACE' ),
	'talkspacee'                => array( '1', 'PEJINDRESAKAX', 'PEJYRESAKAX', 'DINIKAX', 'ESPACEDISCUSSIONX', 'TALKSPACEE' ),
	'subjectspace'              => array( '1', 'TOERANALAHATSORATRA', 'ESPACESUJET', 'ESPACEARTICLE', 'SUBJECTSPACE', 'ARTICLESPACE' ),
	'subjectspacee'             => array( '1', 'TOERANNYLAHATSORATRA', 'ESPACESUJETX', 'ESPACEARTICLEX', 'SUBJECTSPACEE', 'ARTICLESPACEE' ),
	'fullpagename'              => array( '1', 'ANARAMPEJYFENO', 'ANARANAPEJYFENO', 'NOMPAGECOMPLET', 'FULLPAGENAME' ),
	'fullpagenamee'             => array( '1', 'ANARAMPEJYFENOX', 'ANARANAPEJYFENOX', 'NOMPAGECOMPLETX', 'FULLPAGENAMEE' ),
	'subpagename'               => array( '1', 'ANARANAZANAPEJY', 'ANARANJANAPEJY', 'NOMSOUSPAGE', 'SUBPAGENAME' ),
	'subpagenamee'              => array( '1', 'ANARANJANAPEJYX', 'ANARANAZANAPEJYX', 'NOMSOUSPAGEX', 'SUBPAGENAMEE' ),
	'basepagename'              => array( '1', 'ANARANAFOTOPEJY', 'ANARAMPOTOPEJY', 'NOMBASEDEPAGE', 'BASEPAGENAME' ),
	'basepagenamee'             => array( '1', 'ANARANAFOTOPEJYE', 'ANARAMPOTOPEJYE', 'NOMBASEDEPAGEX', 'BASEPAGENAMEE' ),
	'talkpagename'              => array( '1', 'ANARAMPEJINDRESAKA', 'ANARANAPEJINDRESAKA', 'NOMPAGEDISCUSSION', 'TALKPAGENAME' ),
	'img_right'                 => array( '1', 'ankavanana', 'droite', 'right' ),
	'img_left'                  => array( '1', 'ankavia', 'gauche', 'left' ),
	'img_none'                  => array( '1', 'tsymisy', 'néant', 'neant', 'none' ),
	'img_center'                => array( '1', 'ampivoany', 'anivony', 'centré', 'center', 'centre' ),
	'img_page'                  => array( '1', 'pejy $1', 'page=$1', 'page $1' ),
	'img_border'                => array( '1', 'sisiny', 'bordure', 'border' ),
	'img_top'                   => array( '1', 'ambony', 'haut', 'top' ),
	'img_middle'                => array( '1', 'anivo', 'milieu', 'middle' ),
	'img_bottom'                => array( '1', 'ambany', 'bas', 'bottom' ),
	'currentweek'               => array( '1', 'HERINANDRO', 'SEMAINEACTUELLE', 'CURRENTWEEK' ),
	'currentdow'                => array( '1', 'ALAHADY', 'JDSACTUEL', 'CURRENTDOW' ),
	'localweek'                 => array( '1', 'HERINANDROANTOERANA', 'SEMAINELOCALE', 'LOCALWEEK' ),
	'localdow'                  => array( '1', 'ALAHADYANTOERANA', 'JDSLOCAL', 'LOCALDOW' ),
	'fullurl'                   => array( '0', 'URLREHETRA:', 'URLCOMPLETE:', 'FULLURL:' ),
	'fullurle'                  => array( '0', 'URLREHETRAX:', 'URLCOMPLETEX:', 'FULLURLE:' ),
	'displaytitle'              => array( '1', 'ASEHOLOHATENY', 'AFFICHERTITRE', 'DISPLAYTITLE' ),
);

$fallback = 'fr';

$namespaceNames = array(
	NS_MEDIA            => 'Rakitra',
	NS_SPECIAL          => 'Manokana',
	NS_TALK             => 'Dinika',
	NS_USER             => 'Mpikambana',
	NS_USER_TALK        => 'Dinika_amin\'ny_mpikambana',
	NS_PROJECT_TALK     => 'Dinika_amin\'ny_$1',
	NS_FILE             => 'Sary',
	NS_FILE_TALK        => 'Dinika_amin\'ny_sary',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'Dinika_amin\'ny_MediaWiki',
	NS_TEMPLATE         => 'Endrika',
	NS_TEMPLATE_TALK    => 'Dinika_amin\'ny_endrika',
	NS_HELP             => 'Fanoroana',
	NS_HELP_TALK        => 'Dinika_amin\'ny_fanoroana',
	NS_CATEGORY         => 'Sokajy',
	NS_CATEGORY_TALK    => 'Dinika_amin\'ny_sokajy',
);

$namespaceAliases = array(
	'Média' => NS_MEDIA,
	'Discuter' => NS_TALK,
	'Utilisateur' => NS_USER,
	'Discussion_Utilisateur' => NS_USER_TALK,
	'Discussion_$1' => NS_PROJECT_TALK,
	'Discussion_Image' => NS_FILE_TALK,
	'Discussion_MediaWiki' => NS_MEDIAWIKI_TALK,
	'Modèle' => NS_TEMPLATE,
	'Discussion_Modèle' => NS_TEMPLATE_TALK,
	'Aide' => NS_HELP,
	'Discussion_Aide' => NS_HELP_TALK,
	'Fanampiana' => NS_HELP,
	'Dinika_amin\'ny_fanampiana' => NS_HELP_TALK,
	'Catégorie' => NS_CATEGORY,
	'Discussion_Catégorie' => NS_CATEGORY_TALK,
);

$specialPageAliases = array(
	'Activeusers'               => array( 'Mpikambana_mavitrika' ),
	'Allmessages'               => array( 'Hafatra_rehetra' ),
	'Allpages'                  => array( 'Pejy_rehetra' ),
	'Ancientpages'              => array( 'Pejy_antitra' ),
	'Blankpage'                 => array( 'Pejy_fotsy' ),
	'Block'                     => array( 'Hanakana' ),
	'Blockme'                   => array( 'Sakano_ahy' ),
	'Booksources'               => array( 'Boky_loharano' ),
	'BrokenRedirects'           => array( 'Fihodinana_tapaka' ),
	'Categories'                => array( 'Sokajy' ),
	'ChangePassword'            => array( 'Hiova_tenimiafina' ),
	'ComparePages'              => array( 'Fampitaha_pejy' ),
	'Confirmemail'              => array( 'Fankatoavana_ny_adiresy_imailaka' ),
	'Contributions'             => array( 'Fandraisan\'anjara' ),
	'CreateAccount'             => array( 'Hamorona_kaonty' ),
	'Deadendpages'              => array( 'Pejy_tsy_misy_rohy' ),
	'DeletedContributions'      => array( 'Fandraisan\'anjara_voafafa' ),
	'Disambiguations'           => array( 'Pejy_mitovy_anarana' ),
	'DoubleRedirects'           => array( 'Fihodinana_miroa' ),
	'EditWatchlist'             => array( 'Hanova_ny_pejy_arahana' ),
	'Emailuser'                 => array( 'Handefa_imailaka' ),
	'Export'                    => array( 'Hamoa-pejy' ),
	'Fewestrevisions'           => array( 'Pejy_vitsy_mpanova_indrindra' ),
	'FileDuplicateSearch'       => array( 'Fikarohan-drakitra_miroa' ),
	'Filepath'                  => array( 'Lalan-drakitra' ),
	'Import'                    => array( 'Hampidi-pejy' ),
	'BlockList'                 => array( 'Lisitry_ny_fanakanana' ),
	'LinkSearch'                => array( 'Fikarohan-drohy' ),
	'Listadmins'                => array( 'Lisitry_ny_mpandrindra' ),
	'Listbots'                  => array( 'Lisitry_ny_rôbô' ),
	'Listfiles'                 => array( 'Lisitran\'ny_rakitra' ),
	'Listgrouprights'           => array( 'Lisitry_ny_satam-pikambana' ),
	'Listredirects'             => array( 'Lisitry_ny_fihodinana' ),
	'Listusers'                 => array( 'Lisitran\'ny_mpikambana' ),
	'Lockdb'                    => array( 'Hanidy_ny_database' ),
	'Log'                       => array( 'Tatitr\'asa' ),
	'Lonelypages'               => array( 'Pejy_manirery' ),
	'Longpages'                 => array( 'Pejy_lavabe' ),
	'MergeHistory'              => array( 'Hampiaraka_ny_tantaram-pejy' ),
	'MIMEsearch'                => array( 'Fikarohana_MIME' ),
	'Mostcategories'            => array( 'Pejy_be_sokajy_indrindra' ),
	'Mostimages'                => array( 'Rakitra_voarohy_indrindra' ),
	'Mostlinked'                => array( 'Pejy_voarohy_indrindra' ),
	'Mostlinkedcategories'      => array( 'Sokajy_voarohy_indrindra' ),
	'Mostlinkedtemplates'       => array( 'Endrika_voarohy_indrindra' ),
	'Mostrevisions'             => array( 'Pejy_be_mpanova_indrindra' ),
	'Movepage'                  => array( 'Hanova_anaram-pejy' ),
	'Mycontributions'           => array( 'Fandraisan\'anjarako' ),
	'Mypage'                    => array( 'Pejiko' ),
	'Mytalk'                    => array( 'Pejin-dresako' ),
	'Newimages'                 => array( 'Sary_vaovao' ),
	'Newpages'                  => array( 'Pejy_vaovao' ),
	'Popularpages'              => array( 'Pejy_be_mpitsidika_indrindra' ),
	'Preferences'               => array( 'Safidy' ),
	'Prefixindex'               => array( 'Index' ),
	'Protectedpages'            => array( 'Pejy_voaaro' ),
	'Protectedtitles'           => array( 'Lohateny_voaaro' ),
	'Randompage'                => array( 'Kisendra' ),
	'Randomredirect'            => array( 'Fihodinana_kisendta' ),
	'Recentchanges'             => array( 'Fanovàna_farany' ),
	'Recentchangeslinked'       => array( 'Fanarahana_ny_rohy' ),
	'Revisiondelete'            => array( 'Santiôna_voafafa' ),
	'Search'                    => array( 'Fikarohana' ),
	'Shortpages'                => array( 'Pejy_fohy' ),
	'Specialpages'              => array( 'Pejy_manokana' ),
	'Statistics'                => array( 'Statistika' ),
	'Tags'                      => array( 'Balizy' ),
	'Unblock'                   => array( 'Hanala_ny_fanakanana' ),
	'Uncategorizedcategories'   => array( 'Sokajy_tsy_misy_sokajy' ),
	'Uncategorizedimages'       => array( 'Sary_tsy_misy_sokajy', 'Rakitra_tsy_misy_sokajy' ),
	'Uncategorizedpages'        => array( 'Pejy_tsy_misy_sokajy' ),
	'Uncategorizedtemplates'    => array( 'Endrika_tsy_misy_sokajy' ),
	'Undelete'                  => array( 'Hamerina' ),
	'Unlockdb'                  => array( 'Hanala_ny_hidin\'ny_database' ),
	'Unusedcategories'          => array( 'Sokajy_tsy_miasa' ),
	'Unusedimages'              => array( 'Rakitra_tsy_miasa', 'Sary_tsy_miasa' ),
	'Unusedtemplates'           => array( 'Endrika_tsy_misy_mpampiasa' ),
	'Unwatchedpages'            => array( 'Pejy_tsy_misy_mpanaraka' ),
	'Upload'                    => array( 'Hanafatra' ),
	'Userlogin'                 => array( 'Fidirana' ),
	'Userlogout'                => array( 'Fialàna' ),
	'Userrights'                => array( 'Fahefana' ),
	'Version'                   => array( 'Santiôna' ),
	'Wantedcategories'          => array( 'Sokajy_tadiavina' ),
	'Wantedfiles'               => array( 'Rakitra_tadiavina' ),
	'Wantedpages'               => array( 'Pejy_tadiavina' ),
	'Wantedtemplates'           => array( 'Endrika_tadiavina' ),
	'Watchlist'                 => array( 'Lisitry_ny_pejy_arahana' ),
	'Whatlinkshere'             => array( 'Pejy_mirohy' ),
	'Withoutinterwiki'          => array( 'Tsy_misy_interwiki' ),
);

$messages = array(
# User preference toggles
'tog-underline' => 'Hanipika ny rohy:',
'tog-justify' => 'Hanitsy ny andiany',
'tog-hideminor' => "Hanitsika ny fanovana madinika ao amin'ny fanovana farany",
'tog-hidepatrolled' => "Hanitrika ny fanovana voaara-maso ao amin'ny fanovana farany",
'tog-newpageshidepatrolled' => "Hanitsika ny pejy voaara-maso ao amin'ny pejy vaovao",
'tog-extendwatchlist' => 'Hanitatra ny lisitra fanaraham-pejy mba haneho ny fanovana rehetra fa tsy ny vaovao indrindra fotsiny',
'tog-usenewrc' => "Hamondrona ny fanovana araky ny pejy ao amin'ny fanovana farany ary ao amin'ny lisitry ny pejy arahana",
'tog-numberheadings' => 'Asio laharany ny lohateny',
'tog-showtoolbar' => 'Haneho ny toolbar fanovana',
'tog-editondblclick' => "Hanova pejy amin'ny alalan'ny tsindrim-boalavo roa misesy",
'tog-editsection' => "Ataovy mety ny fanovana fizaràna amin'ny alalan'ny rohy [hanova]",
'tog-editsectiononrightclick' => "Hampiasa ny fanovana fizarana amin'ny tsindry havanana eo amin'ny lohatenim-pizarana.",
'tog-showtoc' => "Asehoy ny fanoroan-takila (ho an'ny pejy misy lohateny mihoatra ny 3)",
'tog-rememberpassword' => "Tadidio ny tenimiafiko eto amin'ity solosaina ity (mandritry ny andro $1 fara-fahabetsany){{PLURAL:}}",
'tog-watchcreations' => 'Hanaraka ny pejy foronoko ary ny rakitra ampidiriko',
'tog-watchdefault' => 'Hanaraka ny pejy ary ny rakitra ovaiko',
'tog-watchmoves' => 'Hanaraka ny pejy ary ny rakitra ovaiko anarana',
'tog-watchdeletion' => 'Hanaraka ny pejy ary ny rakitra voafafako',
'tog-minordefault' => 'Mariho ho madinika foana aloha ny fanovana rehetra',
'tog-previewontop' => "Asehoy alohan'ny boaty fanovana ny tsipalotra",
'tog-previewonfirst' => "Asehoy ny tsipalotra amin'ny fanovana voalohany",
'tog-nocache' => 'Tsy alefa ny fanehoana ny pejy voasitriky ny mpitety',
'tog-enotifwatchlistpages' => 'Andefasana imailaka rehefa voaova ny pejy na ny rakitra arahako',
'tog-enotifusertalkpages' => 'Andefaso imailaka aho rehefa miova ny pejin-dresako',
'tog-enotifminoredits' => "Andefasana imailaka na dia fanovana madinika aza no atao amin'ny pejy sy ny rakitra",
'tog-enotifrevealaddr' => "Asehoy ny adiresy imailako any amin'ny imailaka fampilazana",
'tog-shownumberswatching' => "Asehoy ny isan'ny mpikambana manara-maso ny pejy",
'tog-oldsig' => "Topi-mason'ny sonia :",
'tog-fancysig' => 'Sonia tsotra (tsy misy rohy)',
'tog-uselivepreview' => 'Hampiasa ny topi-maso malakay (andramana)',
'tog-forceeditsummary' => 'Teneno ahy ra tsy nametraka ny ambangovangony',
'tog-watchlisthideown' => "Tsy ampiseho anatin'ny pejy fanaraha-maso ny zavatra nosoratako",
'tog-watchlisthidebots' => "Asitriho amin'ny lisitro ny fanovàna nataon'ny rôbô",
'tog-watchlisthideminor' => "Tsy aseho ny fisoloina kely anatin'ny pejy fanaraha-maso",
'tog-watchlisthideliu' => "Asitriho amin'ny lisitro ny fanovàna nataon'ny mpikambana hafa",
'tog-watchlisthideanons' => "Asitriho amin'ny lisitro ny fanovana nataon'ny IP",
'tog-watchlisthidepatrolled' => "Asitriho amin'ny lisitro ny fanovàna efa nojerena",
'tog-ccmeonemails' => "Andefaso tahaka ny imailaka alefako amin'ny mpikambana hafa",
'tog-diffonly' => "Aza ampiseho ny voatonin'ny pejy eo amban'ny diff",
'tog-showhiddencats' => 'Asehoy ny sokajy misitrika',
'tog-norollbackdiff' => 'Aza aseho ny diff rehefa avy namafa fanàvana iray',
'tog-useeditwarning' => 'Ampitandremo aho raha miala sady mamela pejy ovaiko nefa tsy notahiriziko',
'tog-prefershttps' => 'Fanohizana azo antoka foana no ampaisaina rehefa tafiditra',

'underline-always' => 'Foana foana',
'underline-never' => 'Tsy tsipihina mihitsy',
'underline-default' => "Izay itiavan'ny mpitety azy",

# Font style option in Special:Preferences
'editfont-style' => "soratra ampiasain'ny toerana isoratana :",
'editfont-default' => "Izay itiavan'ny mpitety azy",
'editfont-monospace' => 'soratra monospacé',
'editfont-sansserif' => 'soratra tsy misy tongony (sans-serif)',
'editfont-serif' => 'soratra misy tongony (serif)',

# Dates
'sunday' => 'Alahady',
'monday' => 'Alatsinainy',
'tuesday' => 'Talata',
'wednesday' => 'Alarobia',
'thursday' => 'Alakamisy',
'friday' => 'Zoma',
'saturday' => 'Sabotsy',
'sun' => 'Lah',
'mon' => 'Lat',
'tue' => 'Tal',
'wed' => 'Ala',
'thu' => 'Lak',
'fri' => 'Zom',
'sat' => 'Sab',
'january' => 'Janoary',
'february' => 'Febroary',
'march' => 'Martsa',
'april' => 'Aprily',
'may_long' => 'Mey',
'june' => 'Jiona',
'july' => 'Jolay',
'august' => 'Aogositra',
'september' => 'Septambra',
'october' => 'Oktobra',
'november' => 'Novambra',
'december' => 'Desambra',
'january-gen' => 'janoary',
'february-gen' => 'Febroary',
'march-gen' => 'Martsa',
'april-gen' => 'Aprily',
'may-gen' => 'Mey',
'june-gen' => 'Jiona',
'july-gen' => 'Jolay',
'august-gen' => 'Aogositra',
'september-gen' => 'Septambra',
'october-gen' => 'Oktobra',
'november-gen' => 'Novambra',
'december-gen' => 'Desambra',
'jan' => 'Jan',
'feb' => 'Feb',
'mar' => 'Mar',
'apr' => 'Apr',
'may' => 'Mey',
'jun' => 'Jiona',
'jul' => 'Jol',
'aug' => 'Aog',
'sep' => 'Sep',
'oct' => 'Okt',
'nov' => 'Nov',
'dec' => 'Des',
'january-date' => '$1 Janoary',
'february-date' => '$1 Febroary',
'march-date' => '$1 Martsa',
'april-date' => '$1 Aprily',
'may-date' => '$1 Mey',
'june-date' => '$1 Jiona',
'july-date' => '$1 Jolay',
'august-date' => '$1 Aogositra',
'september-date' => '$1 Septambra',
'october-date' => '$1 Oktobra',
'november-date' => '$1 Novambra',
'december-date' => '$1 Desambra',

# Categories related messages
'pagecategories' => '{{PLURAL:$1|Sokajy|Sokajy}}',
'category_header' => 'Ireo lahatsoratra ao amin\'ny sokajy "$1"',
'subcategories' => 'Zana-tsokajy',
'category-media-header' => "Fisy multimedia anatin'ny sokajy « $1 »",
'category-empty' => "''Tsy misy pejy, sokajy ambany na sary ao anatin'io sokajy io''",
'hidden-categories' => '{{PLURAL:$1|Sokajy misitrika|Sokajy misitrika}} $1',
'hidden-category-category' => 'Sokajy misitrika',
'category-subcat-count' => '{{PLURAL:$2|Ity sokajy ity|Ireo sokajy ireo}} dia manana {{PLURAL:$1|zana-tsokajy|zana-tsokajy}} $1 . Ny taotaliny dia $2',
'category-subcat-count-limited' => 'Misy zana-tsokajy $1 ity sokajy ity.{{PLURAL:}}',
'category-article-count' => "{{PLURAL:$2|Misy pejy $1 ity sokajy ity|Misy pejy $1 ity sokajy ity}}. Pejy $2 no anatin'ity sokajy ity",
'category-article-count-limited' => "Anatin'ity sokajy ity ireo pejy ireo pejy ireo ($1 ny tontaliny){{PLURAL:}}",
'category-file-count' => 'Misy rakitra $1 (tontaliny : rakitra $2) ireo ity sokajy ity{{PLURAL:}}',
'category-file-count-limited' => "Anatin'ity sokajy ity ireo rakitra ireo. ($1 no aseho) {{PLURAL:}}",
'listingcontinuesabbrev' => ' manaraka.',
'index-category' => 'pejy voasokajy',
'noindex-category' => 'Pejy tsy voasikajy',
'broken-file-category' => 'Pejy misy rohin-drakitra tapaka',

'about' => 'Mombamomba',
'article' => "Votoatin'ny pejy",
'newwindow' => '(sokafy anaty takila hafa)',
'cancel' => 'Aoka ihany',
'moredotdotdot' => 'Tohiny...',
'morenotlisted' => 'Tsy feno ity lisitra ity.',
'mypage' => 'Pejy',
'mytalk' => 'Dinika',
'anontalk' => "Resaka ho an'io adiresy IP io",
'navigation' => 'Fikarohana',
'and' => '&#32;sy',

# Cologne Blue skin
'qbfind' => 'Tadiavina',
'qbbrowse' => 'Tadiavina',
'qbedit' => 'Hanova',
'qbpageoptions' => 'Ity pejy ity',
'qbmyoptions' => 'Ny pejiko',
'qbspecialpages' => 'Pejy manokana',
'faq' => 'FMM',
'faqpage' => 'Project:FMM',

# Vector skin
'vector-action-addsection' => 'Hanampy lohahevitra',
'vector-action-delete' => 'Fafana',
'vector-action-move' => 'Hanolo anarana',
'vector-action-protect' => 'Arovy',
'vector-action-undelete' => 'Avereno',
'vector-action-unprotect' => 'Hanala ny fiarovana',
'vector-simplesearch-preference' => "Hampiasa ny bara fikarohana notsorina (ho an'ny skin Vector ihany)",
'vector-view-create' => 'Foronona',
'vector-view-edit' => 'Hanova',
'vector-view-history' => 'Hijery ny tantara',
'vector-view-view' => 'Hamaky',
'vector-view-viewsource' => 'Hijery fango',
'actions' => 'Tao',
'namespaces' => 'Valam-pejy',
'variants' => "Ny ''skin'' Voasintona",

'navigation-heading' => 'Meny fitetezana',
'errorpagetitle' => 'Tsy fetezana',
'returnto' => "Hiverina any amin'ny $1.",
'tagline' => "Avy amin'i {{SITENAME}}",
'help' => 'Fanoroana',
'search' => 'Tadiavo',
'searchbutton' => 'Tadiavo',
'go' => 'Ndao',
'searcharticle' => 'Tsidiho',
'history' => "Tantaran'ny pejy",
'history_short' => 'Tantara',
'updatedmarker' => 'niova hatry ny tsidiko farany',
'printableversion' => 'Ny votoatiny azo atonta printy',
'permalink' => 'Rohy maharitra',
'print' => 'Avoaka an-taratasy',
'view' => 'Hamaky',
'edit' => 'Ovaina',
'create' => 'Amboarina',
'editthispage' => 'Hanova ity pejy ity',
'create-this-page' => 'Forony ity pejy ity',
'delete' => 'Hamafa',
'deletethispage' => 'Fafao ity pejy ity',
'undeletethispage' => 'Hamerina ity pejy ity',
'undelete_short' => 'Famerenana fanovana {{PLURAL:$1|$1|$1}}',
'viewdeleted_short' => 'Hijery fanovana voafafa {{PLURAL:$1|tokana|$1}}',
'protect' => 'Hiaro',
'protect_change' => 'ovaina',
'protectthispage' => 'Hiaro ity pejy ity',
'unprotect' => 'Hanala ny fiarovana',
'unprotectthispage' => "Hanala idy an'ity pejy ity",
'newpage' => 'Pejy vaovao',
'talkpage' => 'Dinidinika momba ity pejy ity',
'talkpagelinktext' => 'Dinika',
'specialpage' => 'Pejy manokana',
'personaltools' => 'Fitaovana manokana',
'postcomment' => 'Hametraka fanamarihana',
'articlepage' => "Hijery ny votoatin'ny pejy",
'talk' => 'dinika',
'views' => 'Fijerena',
'toolbox' => 'Fitaovana',
'userpage' => "Hijery ny pejy manokan'ny mpikambana",
'projectpage' => 'Pejy meta',
'imagepage' => "Jereo ny pejin'ny sary",
'mediawikipage' => 'Hijery ny pejy misy io hafatra io',
'templatepage' => "Jereo ny pejin'ny endrika",
'viewhelppage' => "Jereo ny pejin'ny fanampiana",
'categorypage' => "Jereo ny pejin'ny sokajy",
'viewtalkpage' => 'Hijery pejin-dresaka',
'otherlanguages' => "Amin'ny tenim-pirenena hafa",
'redirectedfrom' => "(tonga teto avy amin'ny $1)",
'redirectpagesub' => 'Pejy fihodinana',
'lastmodifiedat' => "Voaova farany tamin'ny $1 amin'ny $2 ity pejy ity<br />",
'viewcount' => 'voastsidika in-$1 ity pejy ity.{{PLURAL:}}',
'protectedpage' => 'Pejy voaaro',
'jumpto' => 'Hanketo:',
'jumptonavigation' => 'Fikarohana',
'jumptosearch' => 'karohy',
'view-pool-error' => 'Azafady, be asa ny lohamilina ankehitriny.
Betsaka loatra ny mpikambana mitady hijery ity pejy ity.
Miandrasa kely, dia avereno.

$1',
'pool-timeout' => "Fe-potoana voahoatra ho an'ny hidy.",
'pool-queuefull' => 'Feno ny lisitry ny asa hatao',
'pool-errorunknown' => 'Tsi-fetezana tsy fantatra',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage).
'aboutsite' => 'Mombamomba ny {{SITENAME}}',
'aboutpage' => 'Project:Mombamomba',
'copyright' => 'Ny lisansa $1 no mamehy ny fampiasana ity voatoatiny ity.',
'copyrightpage' => '{{ns:project}}:Copyright',
'currentevents' => 'Ny vaovao',
'currentevents-url' => 'Project:Vaovao',
'disclaimers' => 'Fampitandremana',
'disclaimerpage' => 'Project:General disclaimer',
'edithelp' => 'Fanoroana',
'helppage' => 'Help:Fanoroana',
'mainpage' => 'Fandraisana',
'mainpage-description' => 'Fandraisana',
'policy-url' => 'Project:Fepetra',
'portal' => 'Toerana iraisana',
'portal-url' => 'Project:Fikambanana',
'privacy' => 'Fitsipika momba ny zavatra tsy sarababem-bahoaka',
'privacypage' => 'Project:Konfidansialite',

'badaccess' => 'Tsy manana alàlana',
'badaccess-group0' => 'Tsy afaka manantontosa ny asa nangatahinao ianao tompoko',
'badaccess-groups' => "Ny asa andramanao atao io dia voafetra amin'ny mpikambana ao amin'ny vondrona $1.{{PLURAL:$2|}}",

'versionrequired' => "
Mitaky version $1-n'i MediaWiki",
'versionrequiredtext' => "Mitaky version $1-n'i MediaWiki ny fampiasana ity pejy ity. Jereo [[Special:Version]].",

'ok' => 'Eka',
'pagetitle' => '$1 - {{SITENAME}}',
'retrievedfrom' => 'Hita tao amin\'ny "$1"',
'youhavenewmessages' => 'Manana $1 ($2).',
'newmessageslink' => 'hafatra vaovao',
'newmessagesdifflink' => 'fanovana farany',
'youhavenewmessagesfromusers' => "Manana $1 avy amin'ny mpikambana {{PLURAL:$3|hafa|$3}} ($2).",
'youhavenewmessagesmanyusers' => "Manana $1 avy amin'ny mpikambana maro ($2).",
'newmessageslinkplural' => '{{PLURAL:$1|hafatra iray|hafatra maro}}',
'newmessagesdifflinkplural' => 'fanovana farany{{PLURAL:$1}}',
'youhavenewmessagesmulti' => "Manana hafatra vaovao ianao eo amin'ny $1.",
'editsection' => 'hanova',
'editold' => 'hanova',
'viewsourceold' => 'hijery fango',
'editlink' => 'hanova',
'viewsourcelink' => 'hijery ny fango',
'editsectionhint' => 'Manova ny fizaràna : $1',
'toc' => 'Votoatiny',
'showtoc' => 'aseho',
'hidetoc' => 'afeno',
'collapsible-collapse' => 'Vonkinina',
'collapsible-expand' => 'Itarina',
'thisisdeleted' => 'Hojerena sa haverina i $1?',
'viewdeleted' => "Hijery an'i $1?",
'restorelink' => 'ny fanovàna voafafa $1{{PLURAL:}}',
'feedlinks' => 'Topaka',
'feed-invalid' => 'Endri-topaka tsy izy',
'feed-unavailable' => 'Mbola tsy vonona ny topa ny syndication',
'site-rss-feed' => 'Topaka RSS ny $1',
'site-atom-feed' => 'Topa Atom ny $1',
'page-rss-feed' => 'Topa RSS ny « $1 »',
'page-atom-feed' => 'Topa Atom ny « $1 »',
'red-link-title' => '$1 (mbola tsy misy)',
'sort-descending' => 'Fandaharana miiba',
'sort-ascending' => 'Fandaharana miabo',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-main' => 'Lahatsoratra',
'nstab-user' => 'Pejy ny mpikambana',
'nstab-media' => 'Pejy sary sy/na feo',
'nstab-special' => 'Pejy Manokana',
'nstab-project' => 'Tetikasa',
'nstab-image' => 'Rakitra',
'nstab-mediawiki' => 'Hafatra',
'nstab-template' => 'Endrika',
'nstab-help' => 'Fanoroana',
'nstab-category' => 'Sokajy',

# Main script and global functions
'nosuchaction' => 'Asa tsy fantatra',
'nosuchactiontext' => "Ny asa voafaritra tao amin'ny URL dia tsy fantatr'ity wiki ity",
'nosuchspecialpage' => 'Tsy misy io pejy manokana io',
'nospecialpagetext' => 'Nangataka pejy manokana tsy misy ianao, azonao jerena eto [[Special:SpecialPages|{{int:specialpages}}]] ny lisitry ny pejy manokana.',

# General errors
'error' => 'Tsy mety',
'databaseerror' => "Tsy fetezana eo amin'ny toby",
'databaseerror-text' => "Nisy hadisoana banky angona nitranga.
Mety maneho baogy ao amin'ny rindrankajy izany.",
'databaseerror-textcl' => 'Nisy hadisoana banky angona nitranga.',
'databaseerror-query' => 'Hataka: $1',
'databaseerror-function' => 'Lefa: $1',
'databaseerror-error' => 'Hadisoana: $1',
'laggedslavemode' => 'Fampitandremana: Mety ho tsy nisy fanovana vao haingana angamba io pejy io',
'readonly' => 'Mihidy ny banky angona',
'enterlockreason' => 'Manomeza antony hanidiana ny pejy, ahitana ny fotoana tokony hamahana izay fihidiana izay',
'readonlytext' => "
Mihidy vonjimaika aloha ny banky angona ka tsy afaka anaovana fanovana na fanampiana vaovao. Azo inoana fa asa fikolokoloana mahazatra ihany io ka rehefa vita izay asa izay dia hverina amin'ny laoniny izy.

Ny mpitantana nanidy azy dia nametraka ito fanazavana ito: $1",
'missing-article' => "Tsy hitan'ny banky angona ilay lahatsoratra pejy iray tokony ho hitany, mitondra ny lohateny  « $1 » $2.

Matetika, izany no mitranga rehefa manaraka rohy makany amina diff efa lany andro na efa makany amin'ny pejy tantaran'ny pejy voafafa iray.

Raha tsy izany, mety misy olana ao amin'ny rindrankajin'ny lohamilina.
Lazao any amin'ny  [[Special:ListUsers/sysop|mpandrindra]] io olana io ary aza adino no manome azy ny URL an'ilay rohy.",
'missingarticle-rev' => '(famerenana faha : $1)',
'missingarticle-diff' => '(diff : $1 ; $2)',
'readonly_lag' => "
Mihidy ho azy aloha ny banky angona mandra-pahatratran'ny serveur andevo ny tompony",
'internalerror' => "Tsy fetezana anatin'ny rindrankajy",
'internalerror_info' => 'Tsy fetezana ety anatiny : $1',
'fileappenderrorread' => 'Tsy afaka mamaky « $1 » nandritry ny fampidirana.',
'fileappenderror' => "Tsy afaka ampiana amin'ny « $2 »  « $1 ».",
'filecopyerror' => 'Tsy voadika ho "$2" ilay rakitra"$1".',
'filerenameerror' => 'Tsy voaova ho "$2" ny anaran\'ilay rakitra "$1".',
'filedeleteerror' => 'Tsy voafafa ilay rakitra "$1".',
'directorycreateerror' => "Tsy afaka amboarina ny petra-drakitra (''dossier, directory'') « $1 ».",
'filenotfound' => 'Tsy hita ilay rakitra "$1".',
'fileexistserror' => "Tsy afaka manoratra ao anatin'ilay dossier « $1 » : efa misy ilay fisy",
'unexpected' => 'Tsy nandrasana: "$1"="$2".',
'formerror' => 'Tsy mety: tsy lasa ny fisy',
'badarticleerror' => "Tsy azo atao eto amin'ity pejy ity io asa io.",
'cannotdelete' => "Tsy afaka fafàna ny pejy na ny rakitra « $1 ».
Mety efa nataon'ny hafa angamba ny famafàna.",
'cannotdelete-title' => 'Tsy afaka mamafa ny pejy "$1"',
'delete-hook-aborted' => "Famafana nofoanan'ny itatra.
Tsy nanome fanazavana.",
'no-null-revision' => 'Tsy nahaforona famerenana poaka aty ho an\'ny pejy "$1"',
'badtitle' => 'Tsy mety ny lohateny',
'badtitletext' => "Tsy mety io anaram-pejy nangatahinao io na tsy misy n'inon'inona na rohy dikan-teny vahiny misy diso tsipelina.",
'perfcached' => "Ao amin'ny voatakona ireo data manaraka ireo ary mety tsy voavao. $1{{PLURAL:}} ihany no isan'ireo zavatra voatahiry ao amin'ny voatakona",
'perfcachedts' => "Ao amin'ny voatakona (cache) ny data aseho, ary tamin'ny $1 izy no navaozina farany. $4{{PLURAL:}} no isan'ny valim-pikarohana ao amin'ilay voatakona.",
'querypage-no-updates' => "Tsy nalefa ny ''mise à jour'' (update) hoan'ity pejy ity.
Mety tsy misy fifandraisana amin'ny zavamisy ankehitriny ny zavamisy ao anatin'ity pejy ity..",
'wrong_wfQuery_params' => "Misy tsy fetezana amin'ny wfQuery()<br />
Asa : $1<br />
fangatahana : $2",
'viewsource' => 'Hijery fango',
'viewsource-title' => "Hijery ny fangon'i $1",
'actionthrottled' => 'Tao voafetra',
'actionthrottledtext' => "Mba hiady amin'ny spam, ny hatetika momba ny fanaovana io otao io dia ferana ho foifoy, ary niaotra io fetra io ianao.
Andramo indray afaka minitra vitsivitsy.",
'protectedpagetext' => 'Narovana mba tsy hisiana fanovana na tao hafa ity pejy ity.',
'viewsourcetext' => "Azonao atao no mijery sy mandrika ny votoatin'ity pejy ity :",
'viewyourtext' => "Azonao atao ny mijery ary mandika ny fangon'ny '''fanovanao''' tamin'ity pejy ity:",
'protectedinterface' => "Ity pejy ity dia manome ny lahatsoratra ho an'ny rindrankajy eto amin'ity Wiki ity, ary narovana mba tsy hisian'ny fanararaotana. Raha tia hanampy na hanova ny dikanteny ho an'ny wiki rehetra, ampiasao [//translatewiki.net/ translatewiki.net], izay tetikasa fandikanan ny rindrankajy Mediawiki.",
'editinginterface' => "'''Tandremo''' : Manova pejy ampiasaina amin'ny famoahana ny hafatray ny rindrankajy ianao io.

Hisy fiantraikany amin'ny fisehon'ny tranonkala amin'ny mpampiasa rehetra eto amin'ity wiki ity ny fanovana.

Raha hanampy dikanteny izay tokony hihatra amin'ny wiki rehetra, ampiaao ny tranonkala [//translatewiki.net/ translatewiki.net translatewiki.net], ny tetikasa fandikana an'i MediaWiki.",
'cascadeprotected' => 'Ankehitriny dia voaaro ity pejy ity satria misy pejy voaaro {{PLURAL:$1||$1}}1 mampiasa ity pejy ity. Io pejy io dia mampiasa ny fiarovana "en cascade" :

$2',
'namespaceprotected' => "Tsy manana alalàna manova ny toeran'anarana « '''$1''' » ianao.",
'customcssprotected' => "Tsy afaka manova ity pejy CSS ity ianao satria misy ny safidy manokan'ny mpikambana hafa.",
'customjsprotected' => "Tsy afaka manova ity pejy JavaScript ity inaao satria misy ny safidin'ny mpikambana hafa.",
'mycustomcssprotected' => 'Tsy manana ny alalana ahafahana manova ity pejy CSS ity ianao.',
'mycustomjsprotected' => 'Tsy manana ny alalana ahafahana manova ity pejy JavaScript ity ianao.',
'myprivateinfoprotected' => 'Tsy manana alalana ahafahana manova ny fampahalalana tsy sarababem-bahoakanao ianao.',
'mypreferencesprotected' => 'Tsy manana alalana ahafahana manova ny safidinao ianao.',
'ns-specialprotected' => "Tsy afaka ovaina ny pejy anatin'ny toeran'anarana « {{ns:special}} » .",
'titleprotected' => "Voaaron'i [[User:$1|$1]] ity lohateny ity mba tsy hamorona pejy mitondra ity anarana ity.
Ny antony napetraka dia : « ''$2'' ».",
'filereadonlyerror' => 'Tsy afaka manova ny rakitra "$1" satria famakiana ihany no tao azo atao amin\'i "$2".

Ny antony nomen\'ny mpandrindra nanidy azy: "$3".',
'invalidtitle-knownnamespace' => 'Lohateny tsy miady amin\'ny fepetra miaraka amin\'ny anaram-balam-pejy "$2" ary soratra "$3"',
'invalidtitle-unknownnamespace' => 'Lohateny tsy ekena miaraka amin\'ny laharana anaran-tsehatra $1 ary soratra "$2"',
'exception-nologin' => 'Tsy tafiditra',
'exception-nologin-text' => "Mila tafiditra eo amin'ilay wiki vao afaka manao ilay tao.",

# Virus scanner
'virus-badscanner' => "Diso : Tsy fantatray ny mpitady virus ''$1''",
'virus-scanfailed' => 'Tsy mety alefa ny fitadiavana (kaody $1)',
'virus-unknownscanner' => 'Tsy fantatra io Antivirus io :',

# Login and logout pages
'logouttext' => "'''Efa tafavoaka amin'izay ianao.'''

Fantaro fa mety mbola misy ireo pejy milaza anao fa mbola tafiditra raha tsy namafa ny pejy voatakona (cache) ianao.",
'welcomeuser' => 'Tonga soa, $1',
'welcomecreation-msg' => "Noforonina ny aontinao.
Aza adin ny manova ny [[Special:Preferences|safidinao ro amin'i{{SITENAME}}]].",
'yourname' => 'Solonanarana',
'userlogin-yourname' => 'Anaram-pikambana',
'userlogin-yourname-ph' => 'Atsofohy ny anaram-pikambanao',
'createacct-another-username-ph' => 'Atsofohy ny anaram-pikambana',
'yourpassword' => 'Tenimiafina',
'userlogin-yourpassword' => 'Tenimiafina',
'userlogin-yourpassword-ph' => 'Atsofohy ny tenimiafinao',
'createacct-yourpassword-ph' => 'Manatsofoha tenimiafina',
'yourpasswordagain' => 'Avereno ampidirina eto ny tenimiafina',
'createacct-yourpasswordagain' => 'Hamarino ny tenimiafinao',
'createacct-yourpasswordagain-ph' => 'Mbola ampidiro fanindroany ny tenimiafinao',
'remembermypassword' => '{{PLURAL:}}Tadidio ny tenimiafiko (mandritry ny $1 andro fara-fahabetsany)',
'userlogin-remembermypassword' => 'Tadidio aho',
'userlogin-signwithsecure' => "Fidirana amin'ny alalan'ny fanohizana azo antoka",
'yourdomainname' => 'faritra (domaine) misy anao',
'password-change-forbidden' => "Tsy afaka manova ny tenimiafina ianao eto amin'ity wiki ity.",
'externaldberror' => "Nisy tsy fetezana angamba teo amin'ny fanamarinana anao tamin'ny sehatra ivelan'ity wiki ity, na tsy manana alalana hanova ny kaontinao ivelany ianao.",
'login' => 'Midira',
'nav-login-createaccount' => 'Ampidiro ny solonanarana',
'loginprompt' => "
Mila manaiky cookies ianao raha te hiditra amin'ny {{SITENAME}}.",
'userlogin' => 'Hiditra na hanokatra kaonty',
'userloginnocreate' => 'hiditra',
'logout' => 'Hiala',
'userlogout' => 'Hiala',
'notloggedin' => 'Tsy tafiditra',
'userlogin-noaccount' => 'Tsy manana kaonty?',
'userlogin-joinproject' => "Midira ho mpikamban'i {{SITENAME}}",
'nologin' => "Tsy manana solonanarana? '''$1'''.",
'nologinlink' => 'Manokafa kaonty',
'createaccount' => 'Hamorona kaonty',
'gotaccount' => "Efa manana kaonty? '''$1'''.",
'gotaccountlink' => 'Midira',
'userlogin-resetlink' => "Adinonavo ve ny antsipihan'ny fidiranao ?",
'userlogin-resetpassword-link' => 'Hamerina ny tenimiafinao',
'helplogin-url' => 'Help:Fidirana',
'userlogin-helplink' => '[[{{MediaWiki:helplogin-url}}|Fanoroana mikasika ny fidirana]]',
'createacct-join' => 'Atsofohy eo ambany ny fampahalalana momba anao.',
'createacct-another-join' => "Atsofohy eo ambany ny fampahalalana vaovaon'ny kaonty",
'createacct-emailrequired' => 'Adiresy mailaka :',
'createacct-emailoptional' => 'Adiresy mailaka (azo tsy atao) :',
'createacct-email-ph' => 'Atsofohy ny adiresy mailakao',
'createacct-another-email-ph' => 'Atsofohy ny adiresy mailaka',
'createaccountmail' => "Hampiasa tenimiafina vonjimaika ary handefa azy eo amin'ny adiresy mailaka voalaza",
'createacct-realname' => 'Tena anarana (azo tsy atao)',
'createaccountreason' => 'Antony :',
'createacct-reason' => 'Antony',
'createacct-reason-ph' => 'Inona ny antony hamoronanao kaonty hafa',
'createacct-captcha' => 'Fitsapana ny antoka',
'createacct-imgcaptcha-ph' => 'Atsofohy ny teny hitanao eo ambony',
'createacct-submit' => 'Hamorona ny kaontinao',
'createacct-another-submit' => 'Hamorona kaonty vaovao',
'createacct-benefit-heading' => "Olona tahaka ianao no manoratra eo amin'i {{SITENAME}}",
'createacct-benefit-body1' => 'fanovana{{PLURAL:$1}}',
'createacct-benefit-body2' => 'pejy{{PLURAL:$1}}',
'createacct-benefit-body3' => 'mpandray anjara vao haingana{{PLURAL:$1}}',
'badretype' => 'Tsy mitovy ny tenimiafina nampidirinao.',
'userexists' => 'Efa miasa io anaram-pikambana natsofokao io.
Anarana hafa safidiana.',
'loginerror' => "Tsy fetezana teo amin'ny fidirana",
'createacct-error' => 'Hadisoana tam-pamoronana ny kaonty',
'createaccounterror' => 'Tsy afaka mamorona kaonty : $1',
'nocookiesnew' => "Voasikatra ny kaontim-pikambana, fa tsy tafiditra amin'ny kaontinao ianao.
Mampiasa cookies ny {{SITENAME}} ho an'ny fidirana amin'ny kaonty.
Tsy avelanao mandeha ny cookies.
Avelao mandeha ny fampidirana cookies, ary midira amin'ny kaontinao.",
'nocookieslogin' => 'Mampiasa cookies i {{SITENAME}} nefa ny mpiteti-tranonkalanao no tsy manaiky na mandà azy. Ovay mba hanaiky cookies aloha ny mpiteti-tranonkalanao dia aveo manandrama mihiditra ato indray.',
'nocookiesfornew' => "Tsy mbola noforonina ilay kaontim-pikambana, satria tsy afaka marinanay ilay loharanony.
Marino tsara raha mahazo mametraka cookie ao amin'ny kompioteranao ny sehata, dia havaozy ilay pejy",
'noname' => 'Tsy nanome solonanarana mety ianao.',
'loginsuccesstitle' => 'Tafiditra soa aman-tsara',
'loginsuccess' => "'''Tafiditra amin'ny {{SITENAME}} ianao ry \"\$1\".'''",
'nosuchuser' => 'Tsy misy mpikambana manana izany solonanarana "$1" izany. Hamarino ny tsipelina na manokafa kaonty vaovao.',
'nosuchusershort' => 'Tsy misy mpikambana hoe "$1". Hamarino ny tsipelina.',
'nouserspecified' => 'Tsy maintsy mampiditra solonanarana ianao.',
'login-userblocked' => 'Voasakana io mpikambana io. Fidirana tsy nahazoan-dalana.',
'wrongpassword' => 'Diso ny tenimiafina. Manandrama tenimiafina hafa azafady.',
'wrongpasswordempty' => 'Tsy nampiditra tenimiafina ianao, azafady mba avereno indray.',
'passwordtooshort' => '{{PLURAL:}}Fohy loatra io tenimiafina io.
Farafahakeliny tokony hisy litera $1 ny tenimiafina.',
'password-name-match' => 'Tsy maintsy samihafa ny solonanaranao sy ny tenimiafinao tompoko.',
'password-login-forbidden' => 'Norarana ny fampiasana io anaram-pikambana ary io tenimiafina io.',
'mailmypassword' => 'Alefaso imailaka ny tenimiafiko',
'passwordremindertitle' => "Fampatsiahivana tenimiafina avy amin'i {{SITENAME}}",
'passwordremindertext' => 'Nisy olona, izay ianao ihany angamba, avy tamin\'ny adiresy IP $1, nangataka
ny handefasanay tenimiafina vaovao ho an\'ny sehatra {{SITENAME}} ao amin\'ny
$4.
Lasa "$3" ankehitriny ny tenimiafin\'i "$2"
Afaka miditra ary ianao ankehitriny ary manova ny tenimiafinao.
Lany andro anatin\'ny $5 andro ny tenimiafinao

Raha olon-kafa io nangataka io, na tadidinao ihany ny tenimiafinao taloha ka
tsy irinao hovana intsony, dia fafao fotsiny ity hafatra ity dia ilay
tenimiafina taloha ihany no ampiasao.{{PLURAL:}}',
'noemail' => 'Tsy nanome adiresy imailaka i "$1".',
'noemailcreate' => 'Tsy maintsy misy ny adiresy imailaka ho atsofokao',
'passwordsent' => 'Nandefasana tenimiafina vaovao any amin\'ny adiresy imailak\'i "$1".
Azafady midira rehefa voarainao io imailaka io.',
'blocked-mailpassword' => "Voasakana ny adiresy IP-nao, nesorina aminao ny asa ''password recovery'' mba tsy hanararaotra.",
'eauthentsent' => "
Efa nandefasana imailaka fanamarinana ilay adiresy nomenao.
Alohan'ny handraisanao imailaka hafa, dia araho ny torolalana ao anatin'io imailaka io,
mba hanaporofoana fa anao io kaonty io.",
'throttled-mailpassword' => "Efa nandefasana mailaka famerenana tenimiafiana ianao tanatin'ny {{PLURAL:$1|ora|$1 ora}}.
Mba tsy hisian'ny fanararaotana dia mailaka famerenana tenimiafiana iray ihany no azo ampiasaina isaky ny adin'ny $1{{PLURAL:}}.",
'mailerror' => "Nisy olana tamin'ny fandefasana imailaka: $1",
'acct_creation_throttle_hit' => 'Miala tsiny, efa nanokatra kaonty miisa $1 ianao, ka tsy afaka mamorona hafa intsony.{{PLURAL:}}',
'emailauthenticated' => "Voamarina tamin'ny $2 $3 ny adiresy imailakao.",
'emailnotauthenticated' => "Tsy mbola voamarina ny adiresinao. Tsy mbola afaka mandefa hafatra ianao amin'ireto zavatra azo atao manaraka ireto.",
'noemailprefs' => 'Manomeza adiresy imailaka raha hampiasa ireo fitaovana ireo ianao.',
'emailconfirmlink' => 'Hamarino ny adiresy imailakao',
'invalidemailaddress' => 'Tsy mety io imailaka nalefanao io satria tsy manaraka ny firafitra tokony ho izy.
Azafady manomeza adiresy voasoratra tsara na avelao ho banga io toerana io.',
'cannotchangeemail' => "Tsy afaka ovaina eto amin'ity wiki ity ny adiresy imailaky ny kaonty.",
'emaildisabled' => 'Tsy afaka mandefa imailaka ity tranonkala ity.',
'accountcreated' => 'Kaonty voaforona',
'accountcreatedtext' => 'Voaforona ny kaontim-pikambana [[{{ns:User}}:$1|$1]] ([[{{ns:User talk}}:$1|dinika]])',
'createaccount-title' => "Fanokafana kaonty ho an'ny/i {{SITENAME}}",
'createaccount-text' => "Nisy olona nanokatra kaonty ho an'ny adiresy imailakao eo amin'ny {{SITENAME}} ($4) mitondra anarana « $2 » miaraka amin'ny tenimiafina « $3 ».<br />
Tokony miditra na manokatra kaonty ianao, ary ovay ny tenimiafinao dien-izao.

Aza mijery ity hafatra ity ianao raha voaforona an-tsifetezana ilay kaonty io.",
'usernamehasherror' => 'Ny anaram-pikambana dia tsy afaka manana soratra fanaovana hash.',
'login-throttled' => "Betsaka loatra ny andram-pidirana nataonao.

Andraso $1 alohan'ny mamerina.",
'login-abort-generic' => 'Tsy nahomby ny fanandramanao niditra',
'loginlanguagelabel' => 'fiteny : $1',
'suspicious-userlogout' => "Ny fangataham-pialanao dia tsy nekena satria ohatry ny nalfan'ny mpizahan-tsehatra simba izy na kasy ny proxy.",
'createacct-another-realname-tip' => "Azo tsy atsofoka ny tena anarana.
Raha misafidy ny hanome azy ianao, ho ampiasaina amin'ny fanehoana ny anjara asan'ilay mpikambana ilay izy.",

# Email sending
'php-mail-error-unknown' => "Hadisoana tsy fantatra tao amin'ny tao mial() an'i PHP.",
'user-mail-no-addy' => 'Nanandrana nandefa imailaka tsy misy adiresy imailaka.',
'user-mail-no-body' => 'Nanandrana nandefa mailaka babangoana na fohy loatra',

# Change password dialog
'resetpass' => 'Hanova ny tenimiafina',
'resetpass_announce' => "Nihiditra tenimiafina mailaka nalefanay tamin'ny imailaka ianao. Ampidiro ity tenimiafina ity mba hanapitra ny fampidirana.",
'resetpass_header' => "Hanova ny tenimiafin'ny kaonty",
'oldpassword' => 'Tenimiafina taloha:',
'newpassword' => 'Tenimiafina vaovao:',
'retypenew' => 'Avereno ampidirina ny tenimiafina vaovao:',
'resetpass_submit' => 'Ovay ny tenimiafina ary midira',
'changepassword-success' => 'Voaova soa aman-tsara ny tenimiafinao!',
'resetpass_forbidden' => 'Tsy afaka ovaina ny tenimiafina',
'resetpass-no-info' => "Tsy maintsy tafiditra ao amin'ny kaontinao ianao vao afaka mijery ity pejy ity.",
'resetpass-submit-loggedin' => 'Ovay ny tenimiafina',
'resetpass-submit-cancel' => 'Aoka ihany',
'resetpass-wrong-oldpass' => 'Tsy izy ny tenimiafinao (tsotra na miserana)
Mety efa nanova tenimiafina na nanontany tenimiafina miserana angamba ianao.',
'resetpass-temp-password' => 'Tenimiafina miserana :',
'resetpass-abort-generic' => "Nosakanan'ny itatra (extension) iray ny fanovana tenimiafina.",

# Special:PasswordReset
'passwordreset' => 'Famafana ary famerenana ny tenimiafina',
'passwordreset-text-one' => 'Fenoy ity fôrmiolera ity mba hamerenana ny tenimiafinao',
'passwordreset-text-many' => "Fenoy ny iray amin'ireo saha ireo mba hamerenana ny tenimiafinao{{PLURAL:$1}}",
'passwordreset-legend' => 'Famafana ary famerenana ny tenimiafina',
'passwordreset-disabled' => "Tsy nalefa ny fanovana tenimiafina adino eto amin'ity wiki ity.",
'passwordreset-emaildisabled' => "Tsy avela ny fampiasana mailaka eto amin'ity wiki ity.",
'passwordreset-username' => 'Anaram-pikambana :',
'passwordreset-domain' => 'Vala (domain) :',
'passwordreset-capture' => 'Hijery ny imailaka vokany ?',
'passwordreset-capture-help' => "Raha marihanao ity boaty ity, ny mailaka (miaraka amin'ilay tenimiafina vonjimaika) dia ho aseho aminao ary koa ho alefa amin'ilay mpikambana.",
'passwordreset-email' => 'Adiresy imailaka :',
'passwordreset-emailtitle' => "Antsipirihan'ny kaonty eo amin'i {{SITENAME}}",
'passwordreset-emailtext-ip' => "Nisy olona (izay mety ianao, avy amin'ny adiresy IP $1) nangataka ny hamerina ny tenimiafin'ny kaontim-pikambany ho an'i {{SITENAME}} ($4). Mampiasa ity adiresy mailaka ity {{PLURAL:$3|ity kaontim-pikambana mpikambana io|ireo kaontim-mpikambana ireo}}:

$2

Hitsahatra afaka $5 andro {{PLURAL:$3|io tenimiafina io|ireo tenimiafina ireo}}.
Tokony miditra ianao ary mifidy tenimiafina vaovao. Raha misy olon-kafa nanao ity hataka ity, na efa tadidinao indray ilay tenimiafinao taloha, ary raha tsy tia hanova azy intsony, azonao tsy raharahiana ity hafatra ity ary mitohy mampiasa ny tenimiafinao taloha.",
'passwordreset-emailtext-user' => "Nisy mpikambana mitondra anarana $1 eo amin'i {{SITENAME}} nangataka fampatsiahivana mikasika ny kaontinao eo amin'i {{SITENAME}} ($4). Manana io adiresy imailaka {{PLURAL:$3|io kaontim-pikambana io|ireo kaontim-pikambana ireo}} :

$2

Hitsahatra afaka {{PLURAL:$5|iray|$5}} andro {{PLURAL:$3|io|ireo}} tenimiafina {{PLURAL:$3|io|ireo}}. Mila miditra dien'izao ianao izao ary mifidy tenimiafina vaovao. Raha tsy avy aminao ity hataka ity na efa nahatadidy ny tenimiafinao taloha ianao, ary raha tsy tianao hovaina intsony ilay tenimiafinao, dia azonao tsy raharahiana ity hafatra ity ary mampiasa ny tenimiafinao taloha.",
'passwordreset-emailelement' => 'Anaram-pikambana : $1
Tenimiafina miserana : $2',
'passwordreset-emailsent' => 'Lasa ny mailaka famerenana tenimiafina.',
'passwordreset-emailsent-capture' => 'Lasa ilay mailaka famerenana tenimiafina, izay aseho eo ambany.',
'passwordreset-emailerror-capture' => "Nosoratana ilay mailaka famerenana tenimiafina, izay aseho eo ambany, fa tsy tafalefa tany amin'ilay mpikambana ilay izy : $1{{GENDER:$2}}",

# Special:ChangeEmail
'changeemail' => 'Hanova ny adiresy imailaka',
'changeemail-header' => "Hanova ny adiresy imailak'ilay kaonty",
'changeemail-text' => 'Fenoy ity pejy fenoina ity mba hanova ny adiresy imailakao. Ilainao atsofoka ny tenimiafinao mba hampihatra ilay fanovana.',
'changeemail-no-info' => 'Mila tafiditra ianao vao avaka mijery ity pejy ity.',
'changeemail-oldemail' => 'Adiresy imailaka ankehitriny :',
'changeemail-newemail' => 'Adiresy imailaka vaovao :',
'changeemail-none' => '(tsy misy)',
'changeemail-password' => "Tenimiafinao eo amin'i {{SITENAME}}:",
'changeemail-submit' => 'Hanova ny adiresy imailaka',
'changeemail-cancel' => 'Adinoy',

# Special:ResetTokens
'resettokens' => 'Hamerina ny token',
'resettokens-text' => "Azonao averina eto ny token izay hahafahana mitsidika ny fampahalalana tsy sarababem-bahoaka ao amin'ny kaontinao. Tokony ataonao izany raha voazara tsy fanahy iniana na raha nisy nangalatra ny kaontinao.",
'resettokens-no-tokens' => 'Tsy misy token ho averina',
'resettokens-legend' => 'Famerenana ny token',
'resettokens-tokens' => 'Token:',
'resettokens-token-label' => '$1 (sanda ankehitriny: $2)',
'resettokens-watchlist-token' => "Token ho an'ny fahna web (Atom/RSS) ho an'ny  [[Special:Watchlist|fanovana ny pejy ao amin'ny lisitry ny pejy arahanao]]",
'resettokens-done' => 'Natao reset ny token',
'resettokens-resetbutton' => 'Hanao reset ny token voafidy',

# Edit page toolbar
'bold_sample' => 'Soratra matavy',
'bold_tip' => 'Soratra matavy',
'italic_sample' => 'Sora-mandry',
'italic_tip' => 'Sora-mandry',
'link_sample' => "Soratra eo amin'ny rohy",
'link_tip' => 'Rohy anatiny',
'extlink_sample' => 'http://www.example.com rohy lohateny',
'extlink_tip' => 'Rohy ivelany (tadidio ny tovana http://)',
'headline_sample' => 'Lohateny anankiray',
'headline_tip' => 'Lohatena ambaratonga faha 2',
'nowiki_sample' => 'Apetraho eto ny lahatsoratra tsy manaraka format',
'nowiki_tip' => 'Aza ampiasaina ny formatage wiki',
'image_sample' => 'ohatra.jpg',
'image_tip' => 'sary',
'media_sample' => 'Ohatra.ogg',
'media_tip' => 'Rohy rakitra sary sy/na feo',
'sig_tip' => "Ny sonianao miaraka amin'ny daty",
'hr_tip' => 'Tsipika mitsivalana (aza anaranam-po loatra)',

# Edit pages
'summary' => 'Ambangovangony:',
'subject' => 'Lohateny:',
'minoredit' => 'Fanovàna kely',
'watchthis' => 'Araho maso ity pejy ity',
'savearticle' => 'Tehirizo',
'preview' => 'Topi-maso',
'showpreview' => 'Asehoy aloha',
'showlivepreview' => 'Topi-maso maikamaika',
'showdiff' => 'Asehoy ny fiovana',
'anoneditwarning' => "'''Tandremo''' : Tsy nisoratra tato amin'ny sehtatra ianao. Ho voatahiry ao amin'ny tantaram-pejy ny adiresy IP anao.",
'anonpreviewwarning' => "''Tsy niditra ianao. Hampitahiry ny adiresy IP anao ao amin'ny tantaram-panovan'ity pejy ity ny fitehirizana ny fanovana.''",
'missingsummary' => "'''Hafatra fampantsiahivana''' : tsy mbola nanome ny ambangovangom-panovanao ianao.
Raha mbola tsindriano fanindroany eo amin'ny bokotra {{int:savearticle}}, ho voatahiry tsy fanambarana ny fanovanao.",
'missingcommenttext' => 'Ampidiro ny ambangovangony azafady.',
'missingcommentheader' => "'''Fampahatsiahivana :''' Tsy nampiditra lohateny amin'ity resaka ity ianao.
Raha tsindrianao indray eo amin'ny « {{MediaWiki:Savearticle}} » ho voatahiry tsy misy lohateny ny fanovananao.",
'summary-preview' => "Topi-maso n'ilay ambangovangony :",
'subject-preview' => 'Topi maso ny lazaina :',
'blockedtitle' => 'Mpikambana voasakana',
'blockedtext' => "'''Voasakana ny solonanaranao na ny adiresy IP anao.'''

Nataon'i $1 ny fisakanana.
Ny antony : ''$2''.

* Fanombohan'ilay fisakanana : $8
* Farany : $6
* Kaonty voasakana : $7.

Afaka antsoinao i $1 na [[{{MediaWiki:Grouppage-sysop}}|ny mpandrindra]] mba hiresaka mombamomba n'izany.
Afaka andefasanao imailaka ra nampiditra ny adiresy imailakanao ianao ao anatin'ny [[Special:Preferences|mombamombanao]].
'''$3''' ny adiresy IP-nao ary ny ''identifiant de blocage''-nao dia #$5.
Asio ao anaty ny fangatahanao io adiresy io.",
'autoblockedtext' => "Voasakana ny adiresy IP anareo satria nampiasain'ny olon-kafa io adiresy ampiasainao io. Ary voasakan'i $1 ilay olona nampiasa ny adiresinao.<br />
Ity ny antony navoakany

:''$2''

* nanomboka tamin'ny $8 ilay fisakanana
* Amin'ny $6 ilay fisakanana no mijanona
* $7 no anaran'ilay kaonty voasakana

Afaka antsoinao i $1 na miantso ny [[{{MediaWiki:Grouppage-sysop}}|mpandrindra]] mba hiresaka momba ny fanakananao.

Jereo koa fa tsy afaka mampiasa ny asa ''emailuser'' ianao ra tsy nanometraka ny adiresy imailakao anatin'ny [[Special:Preferences|safidinao]]. Jereo koa ra tsy nesorinao ny asa ''emailuser''.

$3 izao ny adiresinao, ary ny isa ny fisakananai dia $5.
Soraty ireo fanoroana ireo anatin'ny fangatahana ataonao.",
'blockednoreason' => 'tsy nisy antony nomeny',
'whitelistedittext' => "Mila $1 aloha ianao vao afaka manova/mamorona pejy eto amin'ity wiki ity.",
'confirmedittext' => "Tsy maintsy marihina ny adiresy imailakao aloha no manova pejy.
Ampidiro sy Checkeo ny adiresy imailakao amin'ny [[Special:Preferences|safidinao]].",
'nosuchsectiontitle' => 'Tsy nahita ilay fizarana',
'nosuchsectiontext' => "Nanandrana nanova fizarana tsy nisy ianao.
Mety efa nakisaka angamba izy, na voafafa tamin' ianareo namaky ity pejy ity farany.",
'loginreqtitle' => 'Mila fidirana',
'loginreqlink' => 'miditra',
'loginreqpagetext' => 'Tokony $1 ianao raha te hijery pejy hafa.',
'accmailtitle' => 'Lasa ny tenimiafina.',
'accmailtext' => "Nalefa tany amin'i $2 ny tenimiafina kisendra ho an'ny kaonty [[User talk:$1|$1]]! Azo ovaina eo amin'i ''[[Special:ChangePassword|Manova tenimiafina]]'' izany amin'ny alalan'ny fidirana.",
'newarticle' => '(Vaovao)',
'newarticletext' => "Mbola tsy misy ity takelaka ity koa azonao atao ny mamorona azy eto ambany. Jereo ny [[{{MediaWiki:Helppage}}|Fanoroana]] raha misy fanazavana ilainao.

Raha toa moa ka tsy nieritreritra ny hamorona ity takelaka ity ianao dia miverena etsy amin'ny fandraisana.",
'anontalkpagetext' => "----<i>Ity pejy ity dia pejin-dresak'olona tsy nanokatra na tsy nampiasa ny kaontiny.
Noho izany dia ilainay ny mampiasa ny adiresy IP-ny hanondroana azy. Mety zarazarain'olona maro ny adiresy IP iray. Raha mpikambana tsy nisoratra anarana ianao, ka raha mahita resaka ts ho anao, azonao atao ny [[Special:UserLogin/signup|manokatra kaonty]], na [[Special:UserLogin|miditra]] mba tsy ho voafangarao amin'ny mpikambana hafa tsy nisoratra anarana.</i>",
'noarticletext' => "'''Tsy mbola nisy namorona io lahatsoratra io.
Azonao atao ny [[Special:Search/{{PAGENAME}}|Tadiavo ny momba ny {{PAGENAME}}]].'''
* '''[{{fullurl:{{FULLPAGENAME}}|action=edit}} Na forony eto ny lahatsoratra momba ny {{PAGENAME}}]'''.",
'noarticletext-nopermission' => "Mbola tsy misy lahatsoratra ao amin'io pejy io.

Azonao atao ny [[Special:Search/{{PAGENAME}}|mikaroka ity lohateny ity]] eny amin'ny pejy hafa na <span class=\"plainlinks\">[{{fullurl:{{#Special:Log}}|page={{FULLPAGENAMEE}}}} mitady ao amin'ny laogy misy fifandraisana]</span>, fa tsy azonao atao ny mamorona ity pejy ity.",
'missing-revision' => 'Tsy misy ny santiôna #$1 ny pejy "{{PAGENAME}}".

Mitranga izany rehefa manaraka rohin-tantara tola mankany amina pejy voafafa. Ahitana fampahalalana fanampiny ny  [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} laogim-pamafana].',
'userpage-userdoesnotexist' => 'Mbola tsy nisoratra anarana ato i « <nowiki>$1</nowiki> ». Marino raha tena hamorona ity pejy ity ianao.',
'userpage-userdoesnotexist-view' => 'Tsy nisoratra anarana ato i « $1 ».',
'blocked-notice-logextract' => "Ankehitriny ity mpikambana ity dia voasakana.
Ny fampidirana faran'ny laogin'ny fanakanam-pikambana dia naseho teo ambany ho an'ny fampahalalàna :",
'clearyourcache' => "'''Fantaro :''' Rehefa avy mitahiry, dia mila terenao ny fanavaozana ny voatakon'ny mpitety tranonkalanao hahafahanao mahita ny fanovana.
'''Firefox/Safari:''' Tazomy ho voapotsitra ny kitika ''Maj'' na ''Shift'', dia tsindrio eo amin'i ''Actualiser'', na Ctrl+F5
'''Google Chrome:''' Tsindrio miaraka ny Ctrl, Maj ary R.
'''Internet Explorer''': Tsindrio miaraka Ctrl sy F5
'''Opera''': Esory ny voatatoka ao amin'ny ''Outils → Préférences'' (''Fitaovana  → Safidy'').",
'usercssyoucanpreview' => "'''Fika:''' Ampiasao ny bokotra 'Tsipalotra' mialoha ny hitehirizanao ny CSS-nao vaovao.",
'userjsyoucanpreview' => "'''Fika:''' Ampiasao ny bokotra 'Tsipalotra' mialoha ny hitehirizanao ny JS-nao vaovao.",
'usercsspreview' => "'''Tadidio fa mijery tsipalotra ny fivoakan'ny takilan'angalinao (CSS) vaovao fotsiny ihany ianao fa tsy mbola voatahiry akory izy io!'''",
'userjspreview' => "
'''Tadidio fa manandrana/mijery tsipalotra ny fivoakan'ny JavaScript-nao fotsiny ihany ianao fa tsy mbola voatahiry akory izy io!'''",
'sitecsspreview' => "'''Fantaro fa manao topi-maso an'ity CSS ity fotsiny ianao'''.
'''Mbola tsy voatahiry ilay izy !'''",
'sitejspreview' => "'''Tadidio fa manao topi-maso renifango JavaScript ianao.'''
'''Mbola tsy notahirizina izy io !'''",
'userinvalidcssjstitle' => "'''Tandremo''' : Tsy misy fampiankanjoana « $1 » izany.
Tadidio fa mampiasa soramadinika ny lohatenin'ny pejinao manan-tovana *.css sy *.js, ohatra {{ns:user}}:Foo/vector.css fa tsy {{ns:user}}:Foo/Vector.css.",
'updated' => '(Nohavaozina)',
'note' => "'''Fanamarihana:'''",
'previewnote' => "'''Fantaro fa topi-maso fotsiny ity.'''
Mbola tsy voatahiry ny fanovanao !",
'continue-editing' => 'Hanohy ny fanovàna',
'previewconflict' => "
Ity topi-maso ity no mifanaraka amin'ny lahatsoratra ao amin'ny faritra eo ambony,
ary toy izao no ho fisehon'ny pejy raha misafidy ny hitahiry azy ianao.",
'session_fail_preview' => "'''Tsy afaka tahirizina ny fanovanao noho ny haverezan'ny fampahalalàna mikasikan'ny fidiranao. Andramo fanindroany azafady.
Raha mbola tsy mandeha foana dia [[Special:UserLogout|mivoaha]] amin'ny kaontinao ary miverena miditra.'''",
'session_fail_preview_html' => "'''Tsy afaka tehirizinay ny fanovanao noho ny haverezan'ny fampahalalàna momba ny session-nao.

'''Satria nalefan'i {{SITENAME}} HTML tsotra, nasitrika ny topi-paso mba tsy hisy fanafihana atao amin'ny Javascript.

'''Raha ara-dalàna ny fanovanao, avereno.'''
Raha mbola tsy mandeha foana ilay izy, [[Special:UserLogout|mivoaha]] ary midira",
'token_suffix_mismatch' => "'''Tsy nekena ny fanovanao satria tsy voakaodin'ny rindrankajinao tsara ny soratra tao anatin'ny identifiant de modification.'''
Nilaina io tsy fanekena io mba tsy hikatso ilay pejy.
Misy io olana io rehefa mamppiasa serveur mandataire tsy manana anarana sy manan-olana eo amin'ny tranonkala ianao.",
'edit_form_incomplete' => "'''Misy tsy tonga tany amin'ny lohamilina ny singan'ity pejy fenoina ity. Azonao ampiana ny mpandika hafa amin'ny famoronana ny fanazavana ity pejy ity.",
'editing' => "Manova an'i $1",
'creating' => "Famoronana an'i $1",
'editingsection' => 'Fanovana $1 (fizarana)',
'editingcomment' => 'Fanovana $1 (fizarana vaovao)',
'editconflict' => 'Fanovana mifandona : $1',
'explainconflict' => "Nisy olon-kafa koa nanova ity pejy ity taorian'ny nanombohanao nanova azy.
Ireto ny votoatin'ny pejy, ilay eo ambony ny votoatiny araka izay endriny ankehitriny,
ilay eo ambany no misy ny fanovana saika hataonao.
Mila mampiditra ny fanovana nataonao ao anatin'ny votoatiny ankehitriny ianao.
Ny lahatsoratra ao amin'ilay faritra ambony '''ihany''' no ho voatahiry rehefa manindry ilay bokotra \"{{int:savearticle}}\" ianao.",
'yourtext' => 'Lahatsoratrao',
'storedversion' => 'Votoatiny voatahiry',
'nonunicodebrowser' => "'''FAMPITANDREMANA: Tsy mifanaraka tanteraka amin'ny unicode ny navigateur-nao. Misy ihany anefa fika napetraka hahafahanao manova ny lahatsoratra: Ny litera tsy ASCII dia hiseho amin'ny fango isa ta-enina ambin'ny folo.'''",
'editingold' => "'''FAMPITANDREMANA: Ity pejy ity dia efa lany daty io votoatiny ovainao io.
Raha io no tahirizinao, dia ho very ny fanovana ity pejy ity rehetra taorian'io fanovana io.'''",
'yourdiff' => 'Fampitahana',
'copyrightwarning' => "Ny zavatra rehetra apetraka amin'ny {{SITENAME}} dia raisina ho azo adika malalaka araka ny fahazoan-dalana $2 (Jereo $1 ny fanazavana fanampiny). Raha toa ka tianao ho anao manokana ny tahirin-kevitra dia aleo tsy apetraka ato.

<b>AZA MAMPIASA TAHIRINKEVITRA TSY NAHAZOAN-DALANA</b>",
'copyrightwarning2' => "Ny fandraisana anjara ao amin'i {{SITENAME}} dia azo ovaina ary fafan'ny mpikambana hafa. Raha tsy tianao ho ampiasainan, ovaina na zarazaraina ny soratrao, dia aza alefa eto ilay vokatr'asanao<br />
Ny zava-tsoratanao eto dia vokatr'asa naverinao soratana na nodikainao tany amina loharano ao amin'ny vala sarababem-bahoaka na loharano malalaka hafa (Jereo $1 ho an'ny antsipirihany).

'''Aza mampiasa tahirin-kevitra tsy nahazoan-dalana!'''",
'longpageerror' => "'''Hadisoana : Ny tahirin-tsoratra nalefanao dia manana halava {{PLURAL:$1|iray|$1}} kilooktety, izay lava kokoa nohon'ny fetra avo indridra izay natao ho {{PLURAL:$2|iray|$2}} kilooktety.'''
Tsy afaka tahirizina ilay tahirin-tsoratra.",
'readonlywarning' => "'''FAMPITANDREMANA: Nohidiana noho ny antony fikolokoloana aloha ny banky angona,
koa tsy afaka mitahiry ny fanovana nataonao aloha ianao izao. Angamba tokony hanao Couper coller aloha
ianao dia tehirizo anaty rakitra ny fanovanao mandra-paha.'''

Ny mpandrindra nanidy ny banky angona dia nanome ny antony : <br />$1",
'protectedpagewarning' => "'''FAMPITANDREMANA:  Voaaro ity pejy ity ka ny mpikambana manana ny fahazoan-dàlana sysop ihany no afaka manova azy.'''",
'semiprotectedpagewarning' => "'''Naoty''' : Voaaro ity pejy ity, ny mpikambana nanokatra kaonty tato ihany no afaka manova azy.",
'cascadeprotectedwarning' => "'''Tandremo : ''' Voaaro ity pejy ity ary ny mpandrindra ihany no afaka manova azy. Natao ny fiarovana satria ao anatina pejy voaaro mampiasa ny « fiarovana an-driana (protection en cascade) » {{PLURAL:$1}}",
'titleprotectedwarning' => "'''TANDREMO''' : Ny mpikambana manana [[Special:ListGroupRights|alàlana manokana]] ihany no afaka manova ity pejy ity.",
'templatesused' => "endrika{{PLURAL:$1||}} miasa eto amin'ity pejy ity:",
'templatesusedpreview' => "endrika{{PLURAL:$1||}} ampiasaina anatin'ity topi-maso ity :",
'templatesusedsection' => "Endrika miasa anatin'ity{{PLURAL:$1||}} fizaràna ity :",
'template-protected' => '(voaaro)',
'template-semiprotected' => '(voaaro an-tàpany)',
'hiddencategories' => '{{PLURAL:$1|anaty sokajy|anaty sokajy}} nasitrika $1 ity pejy ity',
'nocreatetext' => " Voafetra ihany ny fahafahana mamorona pejy eto amin'ity sehatra ity.  Ny pejy efa misy no azonao ovaina, na [[Special:UserLogin|midira na mamoròna kaonty]].",
'nocreate-loggedin' => 'Tsy mahazo ataonao no manamboatra pejy vao.',
'sectioneditnotsupported-title' => 'Fanovana fizarana tsy zaka',
'sectioneditnotsupported-text' => "Ny fanovana fizarana iray dia tsy zaka ao anatin'ity pejy fanovana ity.",
'permissionserrors' => "Hadisoan'alàlana",
'permissionserrorstext' => 'Tsy afaka manao ilay aza nangatahanao ianao noho ny antony {{PLURAL:$1||maro}} manaraka :',
'permissionserrorstext-withaction' => '{{PLURAL:$1|Tsy manana alalàna ianao|Tsy manana alalàna ianao}} $2. Io ny antony ($2):',
'recreate-moveddeleted-warn' => "'''Tandremo''' : Mamerina pejy efa voafafa ianareo.'''

Marino raha tsara tohizana ny fanovana eto amin'ity pejy ity. Ny laogim-pamafana sy ny famindran-toerana dia eo ambany :",
'moveddeleted-notice' => "Voafafa ity pejy ity.
Eo ambany eo any laogin'ny famindran-toerana sy ny famafana ho an'ny antsipirihany.",
'log-fulllog' => 'Hijery ny tatitr’asa (log)',
'edit-hook-aborted' => 'Tsy nety ny fanovàna
Tsy nanome antony',
'edit-gone-missing' => 'Tsy afaka natao update ilay pejy.
Mety voafafa angamba izy.',
'edit-conflict' => 'Adi-panovàna.',
'edit-no-change' => "Tsy norarahian'ny rindrankajy ny fanovanao satria tsy nanova ny lahatsoratra ianao.",
'postedit-confirmation' => 'Voatahiry ny fanovanao.',
'edit-already-exists' => 'Tsy afaka amboarina ilay pejy vaovao.
Efa misy izy.',
'defaultmessagetext' => 'Hafatra raha tsy misy',
'content-failed-to-parse' => "Tsy naha-parse ny votoatin'i $2 ho an'ny modely $1 : $3",
'invalid-content-data' => "Data anaty votoatiny tsy miady amin'ny fepetra",
'content-not-allowed-here' => "Votoatiny ''$1'' voarara eo amin'ny pejy [[$2]]",
'editwarning-warning' => "Mety hahavery ny fanovana nataonao ny fialanao amin'ity pejy ity.
Raha tafiditra ianao dia azonao esorina ity fampitandremana ity ao amin'ny fizarana \"Fanovàna\" ao amin'ny safidinao",

# Content models
'content-model-wikitext' => 'wiki-soratra',
'content-model-text' => 'soratra tsotra',
'content-model-javascript' => 'JavaScript',
'content-model-css' => 'CSS',

# Parser/template warnings
'expensive-parserfunction-warning' => 'Tandremo : Betsaka loatra ny fanantsoana ny tao parser.

Tsy maintsy latsaky ny $2 ny tao, kanefa misy $1. {{PLURAL:$2||}}',
'expensive-parserfunction-category' => 'Pejy mampiasa be loatra ny tao parser',
'post-expand-template-inclusion-warning' => "'''Tandremo''' : be loatra ny endrika ampiasain'ity pejy ity, misy endrika tsy ho ampiasaina.",
'post-expand-template-inclusion-category' => 'Pejy be be endrika',
'post-expand-template-argument-warning' => "Tandremo : Manana mpihazaka endrika tsy afaka ampidirina ity pejy ity.
Ao aorian'ny fivelarana, mety namoaka valy lava loatra angamba izy, ary tsy nampidirina tato noho izany antony izany.",
'post-expand-template-argument-category' => 'Pejy misy parametatra endrika hadino',
'parser-template-loop-warning' => 'endrika vono hita tao : [[$1]]',
'parser-template-recursion-depth-warning' => "Fetran'ny halalin'ny fiantsoana endrika voahoatra ($1).",
'language-converter-depth-warning' => "Mihoatra ny fetran-kalalin'ny mpamadika teny ($1)",
'node-count-exceeded-category' => "Pejy izay ahitana fihoatran'ny isam-patotra (node)",
'node-count-exceeded-warning' => 'Pejy manana isam-patotra mihoatra',
'expansion-depth-exceeded-category' => 'Pejy manana halalim-panitarana mihoatra',
'expansion-depth-exceeded-warning' => 'Pejy manana halalim-panitarana mihoatra',
'parser-unstrip-loop-warning' => 'Nahitana tondro mifolaka tsy azo vahana',
'parser-unstrip-recursion-limit' => 'Tafahoatra ny fetra avo ny fetra recursion ($1)',
'converter-manual-rule-error' => "Nahitana hadisoana ao amin'ny fepetra famadihana tanana ny fiteny.",

# "Undo" feature
'undo-success' => 'Ho voafafa io fanovana io. Marino tsara ny fanovana eo ambany, ary tehirizo rehefa vita.',
'undo-failure' => "Tsy afaka esorina io fanovàna io : mety tsy miraikitra amin'ny fanovàna misy eo ampivoaniny ra esorina",
'undo-norev' => 'Tsy afaka nesorina ilay fanovàna satria tsy misy na efa voafafa izy.',
'undo-summary' => "Niala ny fanovàna $1 nataon'i [[Special:Contributions/$2|$2]] ([[User talk:$2|resaho]])",
'undo-summary-username-hidden' => 'Namafa ny famerenana $1 nataom-pikambana afenina',

# Account creation failure
'cantcreateaccounttitle' => 'Tsy afaka manokatra kaonty ianao.',
'cantcreateaccount-text' => "Voasakan'i [[User:$3|$3]] ny fanokafana kaonty avy amin'ity adiresy IP (<b>$1</b>)

''$2'' ny antony.",

# History pages
'viewpagelogs' => "Hijery ny fanovan'ity pejy ity",
'nohistory' => 'Tsy manana tantaram-panovana io pejy io.',
'currentrev' => 'Votoatiny ankehitriny',
'currentrev-asof' => "Endrika tamin'ity $1 ity",
'revisionasof' => "Endrik'io pejy io tamin'ny $1",
'revision-info' => "Santiônan'i $1 nataon'i $2",
'previousrevision' => '←Votoatiny antitra kokoa',
'nextrevision' => 'Fanovana vao haingana→',
'currentrevisionlink' => 'Endrika-ny ankehitriny',
'cur' => 'ank',
'next' => 'manaraka',
'last' => 'farany',
'page_first' => 'voalohany',
'page_last' => 'farany',
'histlegend' => "
Fifidianana ny votoatiny hampitahaina: mariho eo anilan'ny versions hampitahaina dia tsindrio ny bokotra Entrée na ny bokotra etsy ambany.<br />
Tadidio: (ank) = fampitahana amin'ny votoatin'ny pejy ankehitriny,
(farany) = fampitahana amin'ny version talohan'ity, M = fanovana madinika",
'history-fieldset-title' => 'Karohy ny tantara',
'history-show-deleted' => 'Voafafa ihany',
'histfirst' => 'antitra indrindra',
'histlast' => 'vaovao indrindra',
'historysize' => '($1 {{PLURAL:$1|oktety|oktety}})',
'historyempty' => '(tsy misy)',

# Revision feed
'history-feed-title' => 'Tantara ny fanovàna',
'history-feed-description' => "Tantaran'ity pejy ity teto amin'ity wiki ity.",
'history-feed-item-nocomment' => "$1 tamin'ny $2",
'history-feed-empty' => "Tsy misy ny pejy notadiavina.
Mety efa voafafa na voafindra angamba izy.
Mitadiava amin'ny '''[[Special:Search|fiasàna fitadiavina]]''' mba hitady ny pejy misy fifandraisana.",

# Revision deletion
'rev-deleted-comment' => '(ambangovangom-panovana nesorina)',
'rev-deleted-user' => '(solonanarana nesorina)',
'rev-deleted-event' => '(nesorina ny fampidirana)',
'rev-deleted-user-contribs' => "[anaram-pikambana na adiresy IP voafafa - fanovana nasitria teo amin'ny fandraisan'anjara modification]",
'rev-deleted-text-permission' => "'''Voafafa''' ny santiônan'ity pejy ity.
Mety misy ny antsipirihany angamba ny [{{fullurl:{{#Special:Log}}/suppress|page={{FULLPAGENAME}}}} laogy momban'ny famafàna pejy].",
'rev-deleted-text-unhide' => "Ity santiônan'ity pejy ity dia '''voafafa'''.
Hita ao amin'ny [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} laogim-pamafana] ny antsipirihany.
Afaka [$1 mijery ilay santiôna] ianao raha tianao.",
'rev-suppressed-text-unhide' => "'''Nofafana''' ity santiônam-pejy ity.
Azo jerena ao amin'ny [{{fullurl:{{#Special:Log}}/suppress|page={{FULLPAGENAMEE}}}} laogim-pamafana] ny antsipirihany.
Azonao [$1 jerena foana ilay santiôna] raha tianao.",
'rev-deleted-text-view' => "'''Nofafana''' ity santiônam-pejy ity.
Azonao jerena ity santiôna voafafa ity ; misy antsipirihany ao amin'ny [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} laogim-pamafana].",
'rev-suppressed-text-view' => "'''Nofafana''' ity santiônam-pejy ity.
Azonao jerena ilay santiôna voafafa ; ny antsipirihany dia ao amin'ny [{{fullurl:{{#Special:Log}}/suppress|page={{FULLPAGENAMEE}}}} laogim-pamafana].",
'rev-deleted-no-diff' => "Tsy afaka mijery anio diff io ianao satria misy santôna '''voafafa''' ao aminy.
Mety any amin'ny [{{fullurl:{{#Special:Log}}/suppress|page={{FULLPAGENAME}}}} laogy momban'ny famafàna pejy] ny antsipirihany.",
'rev-suppressed-no-diff' => "Tsy azo jerenao io diff io satria '''voafafa''' ny iraika amin'ny reviziônany.",
'rev-deleted-unhide-diff' => "Nisy '''voafafa''' ny iraika amin'ny reviziôna an'ity diff ity.
Ny antsipirihany dia mety hita ao amin'ny [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} laogin'ny famafana].
[$1 Azonao jerena foana ilay diff] raha tianao.",
'rev-suppressed-unhide-diff' => "Nisy '''voafafa''' ny iraika amin'ny santiôna an'ity diff ity.
Ny antsipirihany dia mety hita ao amin'ny [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} laogin'ny famafana].
[$1 Azonao jerena foana ilay diff] raha tianao.",
'rev-deleted-diff-view' => "Nisy '''voafafa''' ny iraika amin'ny reviziôna an'ity diff ity.
Ny antsipirihany dia mety hita ao amin'ny
Azonao jerena foana ny mijery ny [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} laogim-pamafana] raha tianao.",
'rev-suppressed-diff-view' => "Nisy santiônan'ity diff ity '''voafafa'''.
Azonao jerena ilay diff ; ao amin'ny [{{fullurl:{{#Special:Log}}/suppress|page={{FULLPAGENAMEE}}}} tatitry ny famafana] ny antsipirihany.",
'rev-delundel' => 'aseho/asitrika',
'rev-showdeleted' => 'aseho',
'revisiondelete' => 'Hamafa na hamerina santiôna',
'revdelete-nooldid-title' => 'Santiôna tanjona tsy mameno fetra.',
'revdelete-nooldid-text' => 'Tsy voalazanao ny santiôna tanjona hanaovana ity tao ity, 
tsy misy ilay izy, na ny santiôna ankehitriny no andramana asitrika.',
'revdelete-nologtype-title' => 'Tsy nilaza karazana tatitra',
'revdelete-nologtype-text' => 'Tsy natsofokao ny karazana tatitra/laogy hanatanterahana ilay asa.',
'revdelete-nologid-title' => 'Iditra laogy tsy mameno fetra',
'revdelete-nologid-text' => 'Tsy nanatsofoka iditra laogy anaovana ilay asa ianao, na tsy nisy ilay iditra natsofoka.',
'revdelete-no-file' => 'Tsy misy ilay rakitra hofafàna.',
'revdelete-show-file-confirm' => "Tapa-kevitra hamafa ny ''revision''-n'i rakitra <nowiki>$1</nowiki> tamin'ny $2 tamin'ny $3 ve ianao ?",
'revdelete-show-file-submit' => 'Eny',
'revdelete-selected' => "'''{{PLURAL:$2|Votoatiny nosafidiana|Votoatiny nosafidiana}}n'i '''[[:$1]]''' :'''",
'logdelete-selected' => "'''{{PLURAL:$1||}}Laogy voafidy :'''",
'revdelete-text' => "'''Mbola ao amin'ny laogy ny santiôna voafafa, fa tsy afaka jeren'ny vahoaka ny lahatsoratra ao aminy.'''
Afaka mijery ny lahatsoratra nasitrika sy mamerina azy ny mpandrindra hafa ny {{SITENAME}} amin'ity interface ity, raha tsy misy \"restriction\" hafa koa.",
'revdelete-confirm' => 'Amafiso eto ny hevitrao raha hanao io ianao, raha azonao sary an-tsaina ny mety ho vokany, ary raha araka ny [[{{MediaWiki:Policy-url}}|fepetra mihatra]] ny zavatra ataonao.',
'revdelete-suppress-text' => "Ny famafàna pejy dia ampiasaina rehefa :
* Misy information tsy sarababem-bahoaka tsy metimety
*: ''Misy adiresy nomeraona antso an-tariby, nomeraona sécurité sociale, sns.''",
'revdelete-legend' => "Ampetraho ny fepetra momban'ny fahitana :",
'revdelete-hide-text' => "Asitriho ny lahatsoratr'ity version ity",
'revdelete-hide-image' => "asitriho ny votoatin'ilay rakitra",
'revdelete-hide-name' => 'Asitriho ny asa sy ny tanjona',
'revdelete-hide-comment' => 'asitriho ny ambangovangony',
'revdelete-hide-user' => "Asitriho ny solonanaran'ny mpikambana/adiresy IP",
'revdelete-hide-restricted' => "Fafao ireo votoatiny ireo amin'ny mpiandrindra sy amin'ny mpikambana hafa",
'revdelete-radio-same' => '(aza ovaina)',
'revdelete-radio-set' => 'Eny',
'revdelete-radio-unset' => 'Tsia',
'revdelete-suppress' => "Manitrika ny votoatiny ho an'ny mpandrindra",
'revdelete-unsuppress' => "Hanala ny fepetra eo amin'ny santiôna naverina",
'revdelete-log' => 'Antony :',
'revdelete-submit' => "Ahàtra amin'ny santiôna nofidiana {{PLURAL:$1}}",
'revdelete-success' => "'''Voaova soa aman-tsara ny fahitana ny santiôna.'''",
'revdelete-failure' => "'''Ny fisehon'ity santiôna ity dia tsy afaka natao update'''
$1",
'logdelete-success' => "'''Voaova soa aman-tsara ny fisehon'ny tatitr’asa.'''",
'logdelete-failure' => "'''Tsy afaka novaina ny fisehon'ny tatitr’asa'''
$1",
'revdel-restore' => 'Ovay ny fahitàna',
'revdel-restore-deleted' => 'santiôna voafafa',
'revdel-restore-visible' => 'santiôna hita',
'pagehist' => "Tantaran'ilay pejy",
'deletedhist' => 'Tantara voafafa',
'revdelete-hide-current' => "Tsi-fetezana tamin'ny zavatra voadaty tamin'ny $1 tamin'ny $2 : io ny reviziôna ankehitriny.
Tsy azo fafana izy.",
'revdelete-show-no-access' => "Tsi-fetazana teo am-panehoana ny zavatra voadaty tamin'ny $1 tamin'ny $2 : izy io dia mitondra ny marika « voafetra ».
Tsy azo jerenao io.",
'revdelete-modify-no-access' => "Tsi-fetezana teo am-panovana ny zavatra voadaty tamin'ny $1 tamin'ny $2 : izy io dia mitondra ny marika « voafetra ». Tsy azonao jerena io.",
'revdelete-modify-missing' => "Tsi-fetezana teo am-panovana ny zavatra miaraka amin'ny marika ID $1 : tsy ao amin'ny banky angona izy !",
'revdelete-no-change' => "'''Tandremo :''' ny zavatra voadaty tamin'ny $1 tamin'ny $2 dia efa manana ny parametatry ny fisehoana nangatahana.",
'revdelete-concurrent-change' => "Tsi-fetezana teo am-panovana ny zavatra voadaty tamin'ny $1 tamin'ny $2 : ny satany dia voaovan' olon-kafa tamin'ianao nanova azy.
Jereo ny laogy.",
'revdelete-only-restricted' => "Tsi-fetezana teo am-panitrihana ny zavatra voadaty tamin'ny $1 tamin'ny $2 : tsy azonao fafana ireo zavatra ireo amin'ny mpandrindra raha tsy misafidy famafana.",
'revdelete-reason-dropdown' => "* Antom-pamafana matetika :
** Tsifanajakan ny zom-pamrona;
** Famoahan-kevitra na fampahalalana ho ann'ny olon-tokana tsy tokony haseho;
** Fampahalalana mety mifototra amin'ny lainga.",
'revdelete-otherreason' => 'Antony hafa / antony miampy :',
'revdelete-reasonotherlist' => 'Antony hafa',
'revdelete-edit-reasonlist' => "Hanova ny anton'ny famafàna",
'revdelete-offender' => 'Mpanao ilay reviziôna :',

# Suppression log
'suppressionlog' => 'tatitr’asa momban’ny famafana pejy',
'suppressionlogtext' => "Ity ny lisitry ny famafana ary ny sakana mikasika ny votoatiny asitrika amin'ny mpandrindra. Jereo ny [[Special:BlockList|lisitry ny sakana]] ho an'ny lisitry ny fandroahana ary ny sakana mbola mihatra amin'izao fotoana.",

# History merging
'mergehistory' => 'Atsonika ny tantara ny pejy',
'mergehistory-header' => "Amin'ity pejy ity, afaka manonika santiônan'ny tantara pejy iaviana makany amina pejy vaovao ianao.
Marino raha manohy ny tantaram-pejy ity asa ity.",
'mergehistory-box' => 'Atsonika ny version ny pejy roa :',
'mergehistory-from' => 'Pejy fiavina :',
'mergehistory-into' => 'pejin-dresaka :',
'mergehistory-list' => "laogin'ny fanovana azo akambana",
'mergehistory-merge' => "Ny santiona manaraka an'ny [[:$1]] dia afaka atambatra miaraka amin'ny [[:$2]]. Ampiasao ny tsanganan'ny bokotra radiô mba hanatambatra ny santiôna namboarina hatramin'ny daty natoro. Fantaharo tsara fa hamerina ity tsanganana ity ny fampiasana ny rohy fizorana.",
'mergehistory-go' => 'Hijery ny fanovàna mety hatsonika',
'mergehistory-submit' => 'atsonika ny version',
'mergehistory-empty' => 'tsy misy version azo hatambarana',
'mergehistory-success' => "$3 version{{PLURAL:$3||s}} de [[:$1]] fusionnée{{PLURAL:$3||s}} dans [[:$2]].

$3 santiôna{{PLURAL:}} natsonika tamin'ny [[:$2]]",
'mergehistory-fail' => "Tsy afaka manatambatra ny tantara(n'asa). Avereno checheo ny pejy sy ny daty.",
'mergehistory-no-source' => "Tsy misy ny pejy avy amin'ny $1.",
'mergehistory-no-destination' => 'Tsy misy ilay pejy tanjona $1.',
'mergehistory-invalid-source' => 'Tokony manana lohateny azo ampiasaina ny pejy fiavina',
'mergehistory-invalid-destination' => 'Tsy maintsy manana lohateny azo ampiasaina ny pejy tanjona.',
'mergehistory-autocomment' => "natambatra miarak'amin'ny [[:$2]]  [[:$1]]",
'mergehistory-comment' => "natambatra miarak'amin'ny [[:$2]] ny/i [[:$1]] : $3",
'mergehistory-same-destination' => 'Ny pejy iaviana sy ny pejy tanjona dia tsy mahazo mitovy',
'mergehistory-reason' => 'Antony :',

# Merge log
'mergelog' => 'Tatitr’asa momban’ny fitambarana',
'pagemerge-logentry' => "voatambatra tamin'ny [[$2]] [[$1]] (fanovàna hatramin'ny $3)",
'revertmerge' => 'Saraho',
'mergelogpagetext' => 'Ity ny lisitry ny fanambarana ny tantaram-pejy vao haingana',

# Diffs
'history-title' => "Tantaran'ny endrik'i « $1 »",
'difference-title' => "$1 : Fahasamihafan'ny santiôna roa",
'difference-title-multipage' => 'Fahasamihafan\'ny pejy "$1" ary "$2"',
'difference-multipage' => "(Fahasamihafan'ny pejy)",
'lineno' => 'Andalana $1:',
'compareselectedversions' => 'Ampitahao ireo version voafidy',
'showhideselectedversions' => 'Aseho/asitrika ireo ny santiôna nofidiana',
'editundo' => 'esory',
'diff-empty' => '(Tsy misy mahasamihafa)',
'diff-multi' => "({{PLURAL:$1|Famerenana tokana|Famerenana $1}} nataon'ny {{PLURAL:$2|mpikambana iray|mpikambana $2}} tsy miseho)",
'diff-multi-manyusers' => "Tsy naseho ny antiôna $1{{PLURAL:}} nataon'ny mpikambana $2.",

# Search results
'searchresults' => 'Valim-pikarohana',
'searchresults-title' => "Valim-pikarohana ho an'ny « $1 »",
'searchresulttext' => "Jereo ny [[{{MediaWiki:Helppage}}|fanazavana fanampiny momba ny fikarohana eto amin'ny {{SITENAME}}]].",
'searchsubtitle' => "nitady lohatsoratra « '''[[:$1]]''' » ianao ([[Special:Prefixindex/$1|ny pejy rehetra manomboka amin'ny « $1 »]]{{int:pipe-separator}}[[Special:WhatLinksHere/$1|ny pejy rehetra manana rohy amin'ny « $1 »]])",
'searchsubtitleinvalid' => "Nitady « '''$1''' » ianao",
'toomanymatches' => "Betsaka loatra ny isan'ny mitovy naverina, mametraha fangatahana hafa.",
'titlematches' => "Mifanitsy amin'ny lohatenin'ny lahatsoratra",
'notitlematches' => 'Tsy nahitana lohateny mifanaraka',
'textmatches' => "Mifanitsy amin'ny votoatin'ny pejy",
'notextmatches' => 'Tsy nahitana votoatim-pejy mifanaraka',
'prevn' => '{{PLURAL:$1|$1}} taloha',
'nextn' => '{{PLURAL:$1|$1}} manaraka',
'prevn-title' => 'Valim-pikarohana taloha $1{{PLURAL:}}',
'nextn-title' => 'Valim-pikarohana manaraka $1{{PLURAL:}}',
'shown-title' => 'Aseho valiny $1 isaky ny pejy iray{{PLURAL:}}',
'viewprevnext' => 'Hijery ($1 {{int:pipe-separator}} $2) ($3).',
'searchmenu-legend' => 'Safidy mikasika ny fitadiavana',
'searchmenu-exists' => "'''Misy pejy mitondra anarana « [[:$1]] » eto amin'ity wiki ity'''",
'searchmenu-new' => "'''Hanamboatra ny pejy « [[:$1|$1]] » eto amin'ity wiki ity !'''",
'searchmenu-prefix' => "[[Special:PrefixIndex/$1|Hitady pejy manomboka amin'io tovona io]]",
'searchprofile-articles' => 'Pejy misy votoatiny',
'searchprofile-project' => 'Pejy fanampiana sy pejy tetikasa',
'searchprofile-images' => 'Multimedia',
'searchprofile-everything' => 'Izy Rehetra',
'searchprofile-advanced' => 'Fikarohana antsipirihany',
'searchprofile-articles-tooltip' => "Hikaroka ao amin'ny $1",
'searchprofile-project-tooltip' => "Hikaroka ao amin'ny $1",
'searchprofile-images-tooltip' => 'Hikaroka rakitra multimedia',
'searchprofile-everything-tooltip' => "Hitady eraky ny tranonkala (miaraka amin'ny pejin-dresaka)",
'searchprofile-advanced-tooltip' => "Hitady ny anaran-tsehatra ho an'ny fikarohana",
'search-result-size' => '$1 ({{PLURAL:$2|teny|teny}} $2)',
'search-result-category-size' => 'Mpiray sokajy $1{{PLURAL:$1}} (zana-tsokajy $2{{PLURAL:}}, rakitra $3{{PLURAL:}})',
'search-result-score' => 'Fifanarahana : $1%',
'search-redirect' => "(redirect avy amin'ny/amin'i $1)",
'search-section' => '(fizaràna $1)',
'search-suggest' => 'Andramo : $1',
'search-interwiki-caption' => 'zandri-tetikasa',
'search-interwiki-default' => "Valiny amin'ny $1 :",
'search-interwiki-more' => '(be kokoa)',
'search-relatedarticle' => 'voadinika',
'mwsuggest-disable' => 'Tsy hampiasa ny toro-hevi-pikarohana AJAX',
'searcheverything-enable' => "Hitady anatin'ny anaran-tsehatra rehetra:",
'searchrelated' => 'voadinika',
'searchall' => 'rehetra',
'showingresults' => "Omeo ny valiny{{PLURAL:$1||}} miisa hatramin'ny <b>$1</b> manomboka ny #<b>$2</b>.",
'showingresultsnum' => 'Omeo ny valiny miisa <b>$3</b> manomboka ny #<b>$2</b>.{{PLURAL:||}}',
'showingresultsheader' => "{{PLURAL:$5}}Valim-pikaronhana '''$1x–$2''' an'i '''$3''' ho an'i '''$4'''",
'nonefound' => "'''Fanamarihana''': ny mahatonga ny fikarohana tsy hahita vokany matetika dia ny
fampiasanao teny miasa matetika toy ny \"izay\" sy ny \"tsy\",
na ny fanomezanao teny mihoatra ny iray (ny pejy ahitana ny teny rehetra hokarohina
ihany no miseho amin'ny vokatry ny karoka).",
'search-nonefound' => 'Tsy nahitana valiny ilay fanontaniana.',
'powersearch' => 'Fitadiavana',
'powersearch-legend' => 'Fikarohana havanana',
'powersearch-ns' => "Hitady anatin'ny anaran-tsehatra :",
'powersearch-redir' => 'Ampiseho ny redirect',
'powersearch-field' => 'Hitady',
'powersearch-togglelabel' => 'Marihana:',
'powersearch-toggleall' => 'Rehetra',
'powersearch-togglenone' => 'Tsy misy',
'search-external' => 'Hikaroka any ivelany',
'searchdisabled' => "Tsy nalefa ny karoka eto amin'i {{SITENAME}}. Afaka mampiasa an'i Google aloha ianao mandra-paha. Nefa fantaro fa mety ho efa lany daty ny valiny omeny.",
'search-error' => 'Hadisoana nitranga tam-pikarohana: $1',

# Preferences page
'preferences' => 'Ny momba anao',
'mypreferences' => 'Safidy',
'prefs-edits' => 'isa ny fanovàna :',
'prefsnologin' => 'Tsy tafiditra',
'prefsnologintext' => 'Mila <span class="plainlinks">[{{fullurl:{{#Special:UserLogin}}|returnto=$1}} misoratra ary tafiditra]</span> amin\'ny kaontinao ianao vao afaka manova ny safidinao.',
'changepassword' => 'Hanova tenimiafina',
'prefs-skin' => 'Endrika',
'skin-preview' => 'Tsipalotra',
'datedefault' => 'Tsy misy safidy',
'prefs-beta' => 'Fitaovana beta',
'prefs-datetime' => 'Daty sy ora',
'prefs-labs' => 'Fitaovana  « labs »',
'prefs-user-pages' => 'Pejim-pikambana',
'prefs-personal' => 'Mombamomba anao',
'prefs-rc' => 'Vao niova',
'prefs-watchlist' => 'Lisitry ny pejy arahana-maso',
'prefs-watchlist-days' => "Isa ny andro haseho anatin'ny lisitra ny pejy arahana-maso",
'prefs-watchlist-days-max' => '$1 {{PLURAL:$1|}} andro farafahabetsany',
'prefs-watchlist-edits' => "Isa ny fanovana aseho eo amin'ny fanaraha-maso navelatra:",
'prefs-watchlist-edits-max' => 'Isa fara-fahabetsany : 1000',
'prefs-watchlist-token' => "token ho an'ny lisitry ny pejy arahi-maso:",
'prefs-misc' => 'Hafa',
'prefs-resetpass' => 'Hanova tenimiafina',
'prefs-changeemail' => 'Hanova ny adiresy imailaka',
'prefs-setemail' => 'Hampiditra adiresy imailaka',
'prefs-email' => 'Safidy mikasika ny imailaka',
'prefs-rendering' => 'Fampisehoana',
'saveprefs' => 'Tehirizo',
'resetprefs' => 'Avereno',
'restoreprefs' => "Hamerina ny safidy taloha (amin'ny fizarana rehetra)",
'prefs-editing' => 'Fanovana',
'rows' => 'Filaharana :',
'columns' => 'Tsanganana/Tioba :',
'searchresultshead' => 'Fikarohana',
'resultsperpage' => "Isa ny valiny isakin'ny pejy :",
'stub-threshold' => 'Fetra ambony ho an\'i <a href="#" class="stub">rohim-bangovango</a> (oktety):',
'stub-threshold-disabled' => 'Tsy alefa',
'recentchangesdays' => "Isa ny andro ho ampiseho eo amin'ny fanovàna farany",
'recentchangesdays-max' => '($1 andro{{PLURAL:$1||}} fara-faha betsany)',
'recentchangescount' => "Isan'ny fanovana haseho (tsipalotra) :",
'prefs-help-recentchangescount' => 'Misy ny fanovana farany, ny tantaram-pejy ary ny laogy',
'savedprefs' => 'Voatahiry ny mombamomba anao.',
'timezonelegend' => "Faritr'ora :",
'localtime' => 'Ora an-toerana',
'timezoneuseserverdefault' => 'Sanda tsipalotry ny wiki ($1)',
'timezoneuseoffset' => 'Hafa (safidio ny faritra)',
'timezoneoffset' => "Fahasamihafan'ny ora<sup>1</sup>:",
'servertime' => "Oran'ny lohamilina",
'guesstimezone' => "
Fenoy araka ny datin'ny solosainan'ny mpitsidika",
'timezoneregion-africa' => 'Afrika',
'timezoneregion-america' => 'Amerika',
'timezoneregion-antarctica' => 'Antarktika',
'timezoneregion-arctic' => 'Arktika',
'timezoneregion-asia' => 'Azia',
'timezoneregion-atlantic' => 'Ranomasimbe Atlantika',
'timezoneregion-australia' => 'Aostralia',
'timezoneregion-europe' => 'Eoropa',
'timezoneregion-indian' => 'Ranomasimbe Indianina',
'timezoneregion-pacific' => 'Ranomasimbe Pasifika',
'allowemail' => "Hanaiky ny fandefasana mailaka avy amin'ny mpikambana hafa",
'prefs-searchoptions' => 'Karoka',
'prefs-namespaces' => "Toeran'anarana",
'defaultns' => "Fikarohana tsipalotra anatin'ireo anaran-tsehatra ireo :",
'default' => 'tsipalotra',
'prefs-files' => 'Rakitra',
'prefs-custom-css' => 'CSS manokana',
'prefs-custom-js' => 'Javascript manokana',
'prefs-common-css-js' => "JavaScript ary CSS zaraina ho an'ny fiankanjoana rehetra:",
'prefs-reset-intro' => "Azonao ampiasaina ity pejy ity mba hamerina ny safidinao amin'izay safidy tsipalotr'ilay sehatra. Tsy azo averina io.",
'prefs-emailconfirm-label' => 'Famarinana ny imailaka :',
'youremail' => 'Imailaka:',
'username' => '{{GENDER:$1}}Anaram-pikambana :',
'uid' => '{{GENDER:$1}}mpikambana :',
'prefs-memberingroups' => "Mpikambana{{GENDER:$2}} ao amin'ny vondrona{{PLURAL:$1}}:",
'prefs-registration' => 'Daty fidirana :',
'yourrealname' => 'Tena anarana marina:',
'yourlanguage' => 'Tenim-pirenena:',
'yourvariant' => 'fitenim-paritry ny fitenim-botoatiny :',
'prefs-help-variant' => "Ny karazan-tsipelina tianao ho ampiasain'ny pejim-botoatiny",
'yournick' => 'Anaram-bositra:',
'prefs-help-signature' => 'Ilaina soniavina amin\'ny "<nowiki>~~~~</nowiki>" ny resaka eo amin\'ny pejin-dresaka izay hametraka ny sonianao ary ny daty nanoratanao.',
'badsig' => 'Tsy mety io sonia io; hamarino ny kialo HTML.',
'badsiglength' => "Lava loatra ny sonianao. {{PLURAL:$1||}}
Tokony mba manana lohavy ambanimbany kokoa non'ny $1",
'yourgender' => 'Tiana hofaritana ahoana ianao?',
'gender-unknown' => 'Tsy tia hanome ny antsipirihany aho',
'gender-male' => 'Manova pejy wiki izy (lehilahy)',
'gender-female' => 'Manova pejy wiki izy (vehivavy)',
'prefs-help-gender' => "Ankifidy : ampiasaina ho an'ny fifandraisan'ny rindrankajy aminao. Ho sarababem-bahoaka ity fampahalalana ity.",
'email' => 'Imailaka',
'prefs-help-realname' => "Anarana marina (afaka tsy fenoina): raha fenoinao ity dia hampiasaina hanomezana anao tambin'ny asa izay efainao eto.",
'prefs-help-email' => 'Azo tsy omena ny adiresy imailaka, fa ilaina izy io raha sendra hadino ny tenimiafinao.',
'prefs-help-email-others' => "Azonareo atao ny misafidy mba hamela ny hafa hifandray aminao eo amin'ny alanana rohy iray eo amin'ny pejin-dresakao.
Tsy haseho ny adiresy imailakao rehefa manoratra any aminao ny mpikambana hafa.",
'prefs-help-email-required' => 'Ilaina ny adiresy imailaka',
'prefs-info' => 'Fampahalalàna fototra',
'prefs-i18n' => 'Fanatontoloana',
'prefs-signature' => 'Sonia',
'prefs-dateformat' => 'Endriky ny daty',
'prefs-timeoffset' => 'Elanelana ora',
'prefs-advancedediting' => 'Antsipirihan-tsafidy',
'prefs-editor' => 'Mpanova',
'prefs-preview' => 'Topi-maso',
'prefs-advancedrc' => 'Antsipirihan-tsafidy',
'prefs-advancedrendering' => 'Antsipirihan-tsafidy',
'prefs-advancedsearchoptions' => 'Antsipirihan-tsafidy',
'prefs-advancedwatchlist' => 'Antsipirihan-tsafidy',
'prefs-displayrc' => 'safidim-tseho',
'prefs-displaysearchoptions' => 'Safidin-tseho',
'prefs-displaywatchlist' => 'Safidin-tseho',
'prefs-tokenwatchlist' => 'Token',
'prefs-diffs' => 'Diff',
'prefs-help-prefershttps' => "Hihatra amin'ny fidiranao manaraka ity safidy ity.",

# User preference: email validation using jQuery
'email-address-validity-valid' => 'Adiresy imailaka mameno fepetra',
'email-address-validity-invalid' => 'Ilaina ny mametraka adiresy imailaka mameno fepetra',

# User rights
'userrights' => "Fandrindràna ny fahefahan'ny mpikambana",
'userrights-lookup-user' => 'Handrindra vondrom-pikambana',
'userrights-user-editname' => 'Manomeza solonanarana:',
'editusergroup' => "Hanova satan'ny mpikambana",
'editinguser' => "Fanovana ny zon'ny mpikambana '''[[User:$1|$1]]''' $2",
'userrights-editusergroup' => 'Hanova vondrom-pikambana',
'saveusergroups' => 'Tehirizo ny vondrom-pikambana',
'userrights-groupsmember' => "Mpikambana amin'ny vondrona:",
'userrights-groupsmember-auto' => "Mpikambana tsy dia voalazan'i :",
'userrights-groups-help' => 'Azonao atao ny manova ny vondrona isian\'ity mpikambana ity.
* Ny boaty voa-"check" dia midika fa ao amin\'io vondrona io ilay mpikambana.
* Ny boaty tsy voa-"check" dia midika fa tsy ao amin\'io vondrona io ilay mpikambana.
* Ny * dia fa tsy azonao esorina amin\'ilay vondrona nampianao/nesorinao ilay mpikambana.',
'userrights-reason' => 'Antony :',
'userrights-no-interwiki' => "Tsy manana alalana manova ny alalan'ny mpikambana eny amin'ny wiki hafa ianao.",
'userrights-nodatabase' => 'Tsy eto akaiky na tsy misy ny banky angona « $1 ».',
'userrights-nologin' => "Tsy maintsy [[Special:UserLogin|miditra]] ary manana kaontim-pandrindra ianao raha hanova ny alalan'ny mpikambana.",
'userrights-notallowed' => 'Tsy manana alalana ny manova na manampy zom-pikambana ianao.',
'userrights-changeable-col' => 'Ny gropy azonao ovaina',
'userrights-unchangeable-col' => 'Ny gropy tsy azonao ovaina',
'userrights-conflict' => 'Fifandonana fanovana zom-pikambana! Avereno vakiana ary marino ny fanovanao.',
'userrights-removed-self' => "Afakao soa aman-tsara ny zonao. Noho izany, tsy afaka mijery amin'ilay pejy intsony ianao.",

# Groups
'group' => 'Gropy :',
'group-user' => 'Mpikambana',
'group-autoconfirmed' => 'Mpikambana voamarina',
'group-bot' => 'Mpikambana rôbô',
'group-sysop' => 'Mpandrindra',
'group-bureaucrat' => 'Borôkraty',
'group-suppress' => 'Mpitondra',
'group-all' => '(izy rehetra)',

'group-user-member' => '{{GENDER:$1|mpikambana}}',
'group-autoconfirmed-member' => '{{GENDER:$1|Mpikambana voamarina ho azy}}',
'group-bot-member' => '{{GENDER:$1|Mpikambana rôbô}}',
'group-sysop-member' => '{{GENDER:$1|Mpandrindra}}',
'group-bureaucrat-member' => '{{GENDER:$1|Borôkraty}}',
'group-suppress-member' => '{{GENDER:$1|Mpitondra}}',

'grouppage-user' => '{{ns:project}}:Mpikambana',
'grouppage-autoconfirmed' => '{{ns:project}}:Mpikambana Voamafy',
'grouppage-bot' => '{{ns:project}}:Mpikambana rôbô',
'grouppage-sysop' => '{{ns:project}}:Mpandrindra',
'grouppage-bureaucrat' => '{{ns:project}}:Borôkraty',
'grouppage-suppress' => '{{ns:project}}:Oversight',

# Rights
'right-read' => 'Mamaky ny pejy',
'right-edit' => 'Manova ny pejy',
'right-createpage' => 'Manamboatra pejy (tsy pejin-dresaka)',
'right-createtalk' => 'Mamorona pejin-dresaka',
'right-createaccount' => 'Manamboatra kaonty',
'right-minoredit' => 'Marihana ho fanovana madinika',
'right-move' => 'Manakisaka pejy',
'right-move-subpages' => "Manakisaka pejy miarak'amin'ny zana-pejiny",
'right-move-rootuserpages' => "Mamindra ny renipejin'ny mpikambana",
'right-movefile' => 'Manova anarana rakitra',
'right-suppressredirect' => "Afaka tsy manometraka redirect avy amin'ny lohateny fiavina",
'right-upload' => 'Mampidi-drakitra',
'right-reupload' => 'Manolo rakitra efa misy',
'right-reupload-own' => "Manolo rakitra nampidirin'ny tena",
'right-reupload-shared' => 'Manolo eo an-toerana rakitra misy eo amina petra-drakitra iraisana',
'right-upload_by_url' => "Mampidi-drakitra avy amin'ny adiresy URL",
'right-purge' => 'Fafàna ny cache ny pejy, tsy mila marihana',
'right-autoconfirmed' => "Tsy iharan'ny fifehezan-kafaingan mikasika ny adiresy IP",
'right-bot' => 'Atao hita otra ny fizorana mande hoazy',
'right-nominornewtalk' => "Tsy alefa ny fampandrenesana ''hafatra vaovao'' rehefa manao fanovana kely ao anatin'ny pejin-dresan'ny mpikambana.",
'right-apihighlimits' => "Mampiasa fepetra ambonimbony kokoa amin'ny fangatahana API",
'right-writeapi' => 'Mampiasa ny API fifanovana ny wiki',
'right-delete' => 'Mamafa pejy',
'right-bigdelete' => 'Mamafa pejy manana tantara be',
'right-deletelogentry' => "Hamafa ary hamerina iditra manokana ao amin'ny laogy.",
'right-deleterevision' => 'Mamafa ny version manokana-na pejy iray',
'right-deletedhistory' => 'Mijery ny tantaram-pejy voafafa fa tsy lahatsorany',
'right-deletedtext' => "Mijery ny lahatsoratra voafafa sy ny fampitahana anelanelan'ny santiôna voafafa",
'right-browsearchive' => 'Mitady pejy voafafa',
'right-undelete' => 'Mamerina pejy voafafa',
'right-suppressrevision' => "Mandinika sy mamerina ny version asitrika amin'ny mpandrindra",
'right-suppressionlog' => 'Mijery ny tao tsy sarababem-bahoaka',
'right-block' => 'Manakana ny mpikambana mba tsy hanova',
'right-blockemail' => 'Manakana ny mpikambana mba tsy handefa imailaka',
'right-hideuser' => "Manakana mpikambana iray amin'ny fanitrihana ny anarany amin'ny vahoaka",
'right-ipblock-exempt' => 'Tsy voakasiky ny fanakanana IP, ny fanakanana mandeha ho azy (aotômatika) ary ny fanakanana sampana IP',
'right-proxyunbannable' => "Tsy voakasiky ny fanakana mande hoazy avy amin'ny proxy",
'right-unblockself' => "Manala ny hidin'ny tena",
'right-protect' => "Manova ny lenta fiarovan'ny pejy sy manova ny pejy voaaro miriana",
'right-editprotected' => 'Manova pejy voaaro (tsy misy fiarovana en cascade)',
'right-editsemiprotected' => 'Hanova ny pejy narovna ho "{{int:protect-level-autoconfirmed}}"',
'right-editinterface' => 'Manova ny interface ny mpikambana',
'right-editusercssjs' => 'Manova ny rakitra CSS sy JS ny mpikambana hafa',
'right-editusercss' => 'Manova ny rakitra CSS ny mpikambana hafa',
'right-edituserjs' => "Manova ny rakitra JS an'ny mpikambana hafa",
'right-editmyusercss' => 'Manova ny rakitra CSS-nao',
'right-editmyuserjs' => 'Manova ny rakitra JavaScript-nao',
'right-viewmywatchlist' => 'Mijery ny pejy arahanao',
'right-editmywatchlist' => 'Manova ny lisitry ny pejy arahanao. Fantaro koa fa hanampy pejy ny tao sasany na dia tsy manana ity zo ity aza.',
'right-viewmyprivateinfo' => 'Mijery ny fampahalalana tsy sarababem-bahoakanao (oh. adiresy mailaka, tena anarana)',
'right-editmyprivateinfo' => 'Manova ny fampahalalana momba anao (oh. mailaka, tena anarana)',
'right-editmyoptions' => 'Manova ny safidinao',
'right-rollback' => "Mamafa haingankaingana ny fanovan'ny mpandray anjara farany amina pejy manokana",
'right-markbotedits' => "Manamarika ny fanovana voafafa hoatry ny nataon'ny rôbô.",
'right-noratelimit' => 'Tsy voafetra ny isa',
'right-import' => "Mampiditra na manafatra pejy avy amin'ny wiki hafa",
'right-importupload' => 'mampiditra na manafatra pejy avy amina rakitra iray',
'right-patrol' => "Manamarina ny fanovan'ny hafa",
'right-autopatrol' => 'Manamarika ny fanovany efa nomarihana',
'right-patrolmarks' => "Mijery ny mariky ny fanamarihana any amin'ny fanovana farany",
'right-unwatchedpages' => 'Mijery ny lisitry ny pejy tsy arahina',
'right-mergehistory' => 'Manatsonika ny tantaram-pejy',
'right-userrights' => "Manova ny fahefan'ny mpikambana",
'right-userrights-interwiki' => "Manova ny fahefan'ny mpikambana any amin'ny wiki hafa",
'right-siteadmin' => 'Manidy sy manokatra ny banky angona',
'right-override-export-depth' => "Mamoaka ny pejy miaraka amin'ny zana-pejy hatramin'ny ambaratonga fahadimy",
'right-sendemail' => "Mandefa imailaka any amin'ny mpikambana hafa",
'right-passwordreset' => 'Hijery ny imailaka famerenana ny tenimiafina',

# Special:Log/newusers
'newuserlogpage' => 'Tatitr’asan’ny fanokafana kaontim-pikambana',
'newuserlogpagetext' => "Ity pejy ity dia maneho ny tantaran'asan'ny fampidirana mpikambana vaovao.",

# User rights log
'rightslog' => 'Tatitr’asa momban’ny fanovana satam-pikambana',
'rightslogtext' => "Ity ny laogy momban'ny fanovana ny zom-pikambana.",

# Associated actions - in the sentence "You do not have permission to X"
'action-read' => 'mamaky ity pejy ity',
'action-edit' => 'manova ity pejy ity',
'action-createpage' => 'hanao pejy',
'action-createtalk' => 'hanao pejin-dresaka',
'action-createaccount' => 'amboary io kaontim-pikambana io',
'action-minoredit' => 'Mariho ho kely ity fanovana ity',
'action-move' => 'hamindra io pejy io',
'action-move-subpages' => 'hamindra io pejy io sy ny zanapejiny',
'action-move-rootuserpages' => "hanolo anaran'ny pejin'ny mpikambana",
'action-movefile' => "manova anaran'ny rakitra iray",
'action-upload' => 'hampiditra io rakitra io',
'action-reupload' => 'Hanolo io rakitra efa misy io',
'action-reupload-shared' => "manitsaka an-toerana rakitra misy any amin'ny petra-drakitra iraisana",
'action-upload_by_url' => 'hampiditra io rakitra io avy amina adiresy URL',
'action-writeapi' => 'hanova ny API fanoratana',
'action-delete' => 'hamafa io pejy io',
'action-deleterevision' => 'hamafa io version io',
'action-deletedhistory' => "mijery ny tantara voafafa n'ity pejy ity",
'action-browsearchive' => 'hitady pejy efa voafafa',
'action-undelete' => 'hamerina io pejy io',
'action-suppressrevision' => 'hijery sy hamerina io version nofafàna io',
'action-suppressionlog' => 'hijery io tao tsy sarababem-bahoaka',
'action-block' => 'manakana am-panoratana ny mpikambana iray',
'action-protect' => "manova ny fanovàn'ity pejy ity",
'action-rollback' => "Manafoana haingana ny fanovan'ny mpikambana farany nanova pejy iray",
'action-import' => "hampiditra ity pejy ity avy amin'ny wiki hafa",
'action-importupload' => "hampiditra ity pejy ity amin'ny fampidirana rakitra",
'action-patrol' => 'marihana ho hita ity version ity',
'action-autopatrol' => 'manana ny fanovanao voamarina',
'action-unwatchedpages' => 'hijery ny lisitry ny pejy tsy arahina',
'action-mergehistory' => 'Manatambatra ny tantaram-pejy',
'action-userrights' => "hanova ny fahefan'ny mpikambana rehetra",
'action-userrights-interwiki' => "hanova ny fahefan'ny mpikambana any amin'ny wiki hafa",
'action-siteadmin' => 'Manidy sy manokatra ny banky angona',
'action-sendemail' => 'handefa imailaka',
'action-editmywatchlist' => 'Manova ny lisitry ny pejy arahana',
'action-viewmywatchlist' => 'Mijery ny pejy arahanao',
'action-viewmyprivateinfo' => 'Mijery ny fampahalalana tsy sarababem-bahoakanao',
'action-editmyprivateinfo' => 'Mijery ny fampahalalana sarababem-bahoakanao',

# Recent changes
'nchanges' => '{{PLURAL:$1|fanovana|fanovana}} $1',
'enhancedrc-since-last-visit' => '$1 ({{PLURAL:$1|hatry ny famangiana farany}})',
'enhancedrc-history' => 'tantara',
'recentchanges' => 'Fanovana farany',
'recentchanges-legend' => 'Safidy ny fanovàna farany',
'recentchanges-summary' => "Jereo eto amin'ity pejy ity izay vao niova vao haingana teto amin'ity wiki ity.",
'recentchanges-noresult' => "Tsy misy fanovana miady amin'ny fepe-potoana napetraka.",
'recentchanges-feed-description' => "Arao ny fanovàna farany amin'ity wiki ity anaty topa",
'recentchanges-label-newpage' => 'Namorona pejy vaovao io fanovana io',
'recentchanges-label-minor' => 'Kely fotsiny ity fanovana ity',
'recentchanges-label-bot' => "Nataon'ny rôbô ity fanovana ity.",
'recentchanges-label-unpatrolled' => 'Ity fanovana ity dia mbola tsy voamarina',
'rcnote' => "!Ity ny {{PLURAL:$1|fanovàna farany|fanovàna farany}} $1 natao nandritra ny <b>$2</b> andro, hatramin'ny $4 tamin'ny ora faha $5.",
'rcnotefrom' => "Ity eto ambany ity ny lisitry ny vao niova manomboka ny <b>$2</b> (hatramin'ny <b>$1</b> no miseho).",
'rclistfrom' => 'Asehoy izay vao niova manomboka ny $1',
'rcshowhideminor' => '$1 ny fanovàna kely',
'rcshowhidebots' => '$1 ny mpikambana rôbô',
'rcshowhideliu' => '$1 ny mpikambana nisoratra anarana',
'rcshowhideanons' => '$1 ny mpikambana tsy nisoratra anarana',
'rcshowhidepatr' => '$1 ny fanovana voaambina',
'rcshowhidemine' => '$1 ny fanovàko',
'rclinks' => "Asehoy ny $1 niova farany tato anatin'ny $2 andro<br />$3",
'diff' => 'Fampitahana',
'hist' => 'tant.',
'hide' => 'Afeno',
'show' => 'Asehoy',
'minoreditletter' => 'k',
'newpageletter' => 'V',
'boteditletter' => 'r',
'number_of_watching_users_pageview' => '[$1 {{PLURAL:$1|mpikambana|mpikambana}} manara-maso]',
'rc_categories' => 'Ferana amin\'ireto sokajy ireto ihany (saraho amin\'ny "|")',
'rc_categories_any' => 'Tsy misy fetrany',
'rc-change-size-new' => "$1{{PLURAL:}} oktety taorian'ny fanovana",
'newsectionsummary' => '/* $1 */ fizarana vaovao',
'rc-enhanced-expand' => 'Hijery ny antsipirihany',
'rc-enhanced-hide' => 'Asitriho ny adidiny sy ny antsipiriany',
'rc-old-title' => 'noforonina tamin\'ilay lohateny "$1"',

# Recent changes linked
'recentchangeslinked' => 'Novaina',
'recentchangeslinked-feed' => 'Novaina',
'recentchangeslinked-toolbox' => 'Novaina',
'recentchangeslinked-title' => "Fanaraha-maso ny pejy miarak'amin'ny « $1 »",
'recentchangeslinked-summary' => "Mampiseho ny fanovàna vao haingana ity pejy manokana ity. Voasoratra amin'ny '''sora-matavy''' ny lohaten'ny [[Special:Watchlist|pejy arahinao-maso]].",
'recentchangeslinked-page' => 'anaram-pejy :',
'recentchangeslinked-to' => "Ampisehoy ny fanovàn'ny pejy misy rohy makany amin'ny pejy fa tsy atao mivadika",

# Upload
'upload' => 'Handefa rakitra',
'uploadbtn' => 'Alefaso ny rakitra',
'reuploaddesc' => "Miverena any amin'ny fisy fandefasan-drakitra.",
'upload-tryagain' => "Hanfefa ny fanoritan'ny rakitra novaina",
'uploadnologin' => 'Tsy niditra',
'uploadnologintext' => 'Mila $1 ianao vao afaka mandefa rakitra.',
'upload_directory_missing' => "Ny petra-drakitra ampidiran-drakitra ($1) dia tsy misy ary tsy afaka namboarin'ny lohamilin-tranonkala.",
'upload_directory_read_only' => "Ny répertoire ($1) handraisana ny rakitra alefan'ny mpikambana dia tsy afaka anoratana.",
'uploaderror' => 'Nisy tsy fetezana ny fandefasana rakitra',
'upload-recreate-warning' => "'''Tandremo : novain-toerana na nofafana ny rakitra mitondra io anarana io.'''

Aseho eo ambany ho fampahalalana fanampiny ny iditra ao amin'ny laogim-panisahana ary ny laogim-pamafana :",
'uploadtext' => "Ampiasao ity fisy ity handefasana rakitra. Jereo eto ny [[Special:FileList|lisitry ny rakitra]] nalefan'ny mpikambana, na koa azonao ampiasaina ny [[Special:Log/delete|tantaran'asan'ny fandefasana sy famonoana rakitra]].

Raha hanisy sary ao anaty pejy, dia mampiasà rohy toy ny iray amin'ireto
'''<nowiki>[[</nowiki>{{ns:file}}<nowiki>:file.jpg]]</nowiki>''', na
'''<nowiki>[[</nowiki>{{ns:file}}<nowiki>:file.png|alt text]]</nowiki>''' na
'''<nowiki>[[</nowiki>{{ns:media}}<nowiki>:file.ogg]]</nowiki>''' raha hirohy mivantana amin'ny rakitra.",
'upload-permitted' => 'Endriky ny rakitra manan-alalana : $1.',
'upload-preferred' => 'Endriky ny rakitra nampidirina : $1',
'upload-prohibited' => 'Endriky ny rakitra tsy manan-alalana : $1',
'uploadlog' => "Laogin'ny fandefasan-drakitra",
'uploadlogpage' => 'Fampidiran-drakitra',
'uploadlogpagetext' => "Ity ny lisitr'ireo rakitra nalefa farany indrindra.",
'filename' => 'Anarana',
'filedesc' => 'Ambangovangony',
'fileuploadsummary' => 'Ambangovangony:',
'filereuploadsummary' => "Fanovan'ilay rakitra :",
'filestatus' => 'Sata ny opyright :',
'filesource' => 'Loharano:',
'uploadedfiles' => 'Rakitra voaray',
'ignorewarning' => 'Aza mihaino fampitandremana fa tehirizo foana ny rakitra.',
'ignorewarnings' => 'Aza mihaino fampitandremana',
'minlength1' => 'Ny anaran-drakitra dia tokony manana litera iray fara-fahakeliny',
'illegalfilename' => 'Misy litera tsy mety amin\'ny lohateny ny anaran\'ilay rakita "$1". Azafady soloy ny anaran\'ny rakitra dia andramo alefa indray.',
'filename-toolong' => 'Tsy afaka mihoatra ny 240 oktety ny anaran-drakitra.',
'badfilename' => 'Novana ho "$1" ny anaran\'ny rakitra.',
'filetype-mime-mismatch' => 'Ny karazan-drakitra ".$1" dia tsy miady amin\'ny karazana MIME novinavinaina ho azy ho an\'ilay rakitra ($2).',
'filetype-badmime' => 'Ny karazan-drakitra MIME « $1 » dia tsy afaka ampidirina.',
'filetype-bad-ie-mime' => "Tsy afaka ampidirina ilay rakitra satria hitan'i Internet Explorer faha « $1 » izy, midika rakitra voarara satria mety mampidi-doza",
'filetype-unwanted-type' => "Karazan-drakitra tsy tiana ny karazan-drakitra '''« .$1 »'''.
{{PLURAL:$3||}}Ny karazan-drakitra fidiana dia $2.",
'filetype-banned-type' => "'''\".\$1\"'''dia {{PLURAL:\$4|anisan'ny|}} karazan-drakitra voarara.
Karazan-drakitra azo alefa {{PLURAL:\$3||}} \$2.",
'filetype-missing' => 'Tsy manan-karazan-drakitra ilay rakitra (hoatry ny « .jpg » ohatra).',
'empty-file' => 'Tsy manam-botoatiny ny rakitra nalefanao.',
'file-too-large' => 'Ngeza loatra ny rakitra nalefanao.',
'filename-tooshort' => 'Fohy loatra ny anaran-drakitra.',
'filetype-banned' => 'Voarara ato io karazan-drakitra io.',
'verification-error' => "Tsy afaka amin'ny fanamarinana rakitra ity rakitra ity.",
'hookaborted' => "Najanon'ny faraingon'itatra ny fanovana nandramanao natao.",
'illegal-filename' => "Tsy nahazoan-dàlana ny anaran'io rakitra io.",
'overwrite' => 'Tsy azo itsahina ny rakitra efa misy.',
'unknown-error' => 'Nisy tsi-fetezana nitranga.',
'tmp-create-error' => 'Tsy afaka mamorona rakitra miserana.',
'tmp-write-error' => "Tsi-fetezana teo am-panoratana an'ilay rakitra miserana",
'large-file' => "Ny haben'ny rakitra hampidirina dia tsy mahazo mihoatra ny $1 ; $2 ny lanjan'ilay rakitra tianao ho ampidirina.",
'largefileserver' => "
Ngeza noho izay zakan'ny serveur io rakitra io.",
'emptyfile' => "Ohatry ny tsy misy na inona na inona ilay rakitra nalefanao teo.
Sao dia misy diso tsipelina ny anaran'ny rakitra? Azafady mba hamarino fa tena naniry handefa io rakitra io tokoa ianao.",
'windows-nonascii-filename' => 'Tsy mahazaka anaran-drakitra misy tarehintsoratra manokana ity wiki ity.',
'fileexists' => 'Efa misy rakitra manana io anarana io ato.
Mariho <strong>[[:$1]]</strong> raha mbola tsy te-hanova azy ianao.
[[$1|thumb]]',
'filepageexists' => "Efa namboarina teto ny pejy mamisavisa ity rakitra ity <strong>[[:$1]]</strong>, fa tsy misy rakitra mitondra io anarana io.
Ny ambangovangony ho ataonareo dia tsy hiseho eo amin'ny pejy famisavisana.
Mba hanao azy, tsy maintsy ovainao manokana ilay pejy [[$1|thumb]]",
'fileexists-extension' => 'Misy rakitra manana anarana mitovitovy : [[$2|thumb]]
* Anaran-drakitra ho ampidirina : <strong>[[:$1]]</strong>
* Anaran-drakitra misy : <strong>[[:$2]]</strong>
Misafidia anarana hafa.',
'fileexists-thumbnail-yes' => "Ohatry ny sary nakelezina ilay rakitra. [[$1|thumb]]
Mba marino ilay rakitra <strong>[[:$1]]</strong>.
Raha mitovy amin'ny sary voalohany ny sarin'ilay rakitra marinina, tsy ilaina ny mampiditra santiôna nakelezina.",
'file-thumbnail-no' => "Manomboka amin'ny <strong>$1</strong> ny anaran'ilay rakitra.
Mety saritapaka ''(vignette)'' io sary io.
Raha manana santiôna ilay rakitra ngezangeza noho io ianao, ampidiro ato ilay izy, raha tsy izany ovay ny anarany.",
'fileexists-forbidden' => 'EEfa misy rakitra iray mitondra io anarana io ary tsy afaka itsahina ilay rakitra.
Raha mbola te-hampiditra ny rakitrao foana ianao, misaotra anao miverina any aoriana sy mampiasa anarana vaovao.
[[File:$1|thumb|center|$1]]',
'fileexists-shared-forbidden' => "Efa misy rakitra mitondra io anarana io ao amin'ny petra-drakitra iraisana.
Raha mbola te-hampiditra io rakitra io foana ianao, miverena any aoriana ary mampiasà anarana hafa.
. [[File:$1|thumb|center|$1]]",
'file-exists-duplicate' => "Ity rakitra ity dia mitovy amin'ny rakitra {{PLURAL:$1|||}} :",
'file-deleted-duplicate' => "Efa voafafa ny rakitra mitovy amin'ity rakitra ity ([[:$1]]). Tokony jerena any amin'ny tantaran'asan'ny famafana io pejy io alohan'ny mampiditra azy indray.",
'uploadwarning' => 'Fampitandremana',
'uploadwarning-text' => "Ovay ny fanoritan' ilay rakitra ary andrao fanindroany.",
'savefile' => 'Tehirizo ny rakitra',
'uploadedimage' => 'tonga ny rakitra"[[$1]]"',
'overwroteimage' => "nampiditra santiôna vaovao an'ny « [[$1]] »",
'uploaddisabled' => 'Miala tsiny! Tsy azo atao ny mandefa rakitra.',
'copyuploaddisabled' => "Tsy alefa ny fandefasan-drakitra amin'ny alalan'ny URL.",
'uploadfromurl-queued' => 'Ao am-piandrasana ny fandefasan-drakitrao.',
'uploaddisabledtext' => "Tsy afaka andefasana rakitra aloha eto amin'ity wiki ity.",
'php-uploaddisabledtext' => "Ny fampidiran-drakitra dia tsy ampiasaina amin'ny PHP.
Marino ny option configuration file_uploads.",
'uploadscripted' => "
Misy kialo HTML na fango script mety tsy ho hain'ny navigateur sasany haseho ity rakitra ity.",
'uploadvirus' => 'Misy viriosy io rakitra io! Toy izao ny antsipirihany: $1',
'uploadjava' => 'Ny rakitra dia rakitra ZIP ahitana rakitra .class Java.
Voarara ny mandefa rakitra Java satria mety hahavaky ny fepetra mikasika ny antoka ireo rakitra ireo.',
'upload-source' => 'Rakitra fango',
'sourcefilename' => "Anaran'ny rakitra:",
'sourceurl' => 'Loharano URL :',
'destfilename' => "Anaran'ny rakitra:",
'upload-maxfilesize' => 'Fetran-danja avo indrindra  : $1',
'upload-description' => "Visavisan'ilay rakitra",
'upload-options' => 'Safidim-pampidirana',
'watchthisupload' => 'Araho maso ity rakitra ity',
'filewasdeleted' => 'Efa nampidirina tato ary efa voafafa ny rakitra manana io anarana io.
Tokony marina ny $1 aloha ny manao fampidirana vaovao.',
'filename-bad-prefix' => "Ny anaran-drakitra ho ampidirinareo dia manomboka amin'ny '''« $1 »''', anarana omena an'ny fakan-tsary elektirônika.
Misafidia anaran-drakitra mambangovango.",
'upload-success-subj' => 'Voaray soa aman-tsara ny rakitra',
'upload-success-msg' => "Vita soa aman-tsara ilay fandefasan-drakitra avy amin'i [$2]. Eto ny toerana mety ahitanao ny rakitrao : [[:{{ns:file}}:$1]]",
'upload-failure-subj' => 'Olana nitranga teo am-pandefasana',
'upload-failure-msg' => "Nisy olana tamin'ny fampidiranao [$2] :

$1",
'upload-warning-subj' => 'Fampitandremana rehefa mampiditra',
'upload-warning-msg' => "Nisy olana nitranga tam-pampidirana avy amin'i [$2] afaka miverina any amin'ny [[Special:Upload/stash/$1|formiolera fampidirana]] ianao hamahana izany olana izany.",

'upload-proto-error' => 'Protokolina diso',
'upload-proto-error-text' => "Mila URL manomboka amin'ny <code>http://</code> na <code>ftp://</code> ny fampidiran-drakitra.",
'upload-file-error' => 'Tsy fetezana anatiny',
'upload-file-error-text' => "Nisy tsi-fetezana anaty nitranga teo am-panamboarana rakitra miserana teo amin'ny lohamilina. Manorata any amin'ny [[Special:ListUsers/sysop|mpandrindra]].",
'upload-misc-error' => 'Tsi-fetezana tsy fantatra teo am-pampidiran-drakitra',
'upload-misc-error-text' => "Nisy tsi-fetezana tsy fantatra nitranga nandritry ny fampidirana.
Marino raha azo andehanana na misy ny URL ary manandrama indray.
Raha mbola misy foana ilay  olana, manorata any amin'ny [[Special:ListUsers/sysop|mpandrindra]].",
'upload-too-many-redirects' => "Be loatra ny fihodinan'ny URL.",
'upload-unknown-size' => 'tsy fantatra ny habe',
'upload-http-error' => 'Nisy tsy fetezana HTTP nitranga : $1',
'upload-copy-upload-invalid-domain' => "Tsy misy eto amin'ity dômenina ity ny tahaky ny upload.",

# File backend
'backend-fail-stream' => 'Tsy afaka mamaky ilay rakitra $1.',
'backend-fail-backup' => 'Tsy afaka mitahiry ilay rakitra $1.',
'backend-fail-notexists' => 'Tsy misy ilay rakitra $1.',
'backend-fail-hashes' => "Tsy azo ilay hash an-drakitra ho an'ny fampitahana.",
'backend-fail-notsame' => "Efa misy rakitra samihafa ho an'i $1",
'backend-fail-invalidpath' => '$1 dia lalam-pitahirizana tsy azo raisina.',
'backend-fail-delete' => 'Tsy afaka mamafa ilay rakitra $1.',
'backend-fail-describe' => 'Tsy nahasolo ny metadata ho an\'ny rakitra "$1".',
'backend-fail-alreadyexists' => 'Efa misy ilay rakitra $1.',
'backend-fail-store' => 'Tsy afaka mitahiry ilay rakitra $1 anaty $2.',
'backend-fail-copy' => 'Tsy afaka mandika ilay rakitra $1 anaty $2.',
'backend-fail-move' => "Tsy afaka manova ny toeran'ilay raktira avy amin'i $1 mankany amin'i $2.",
'backend-fail-opentemp' => 'Tsy afaka manokatra ilay rakitra miserana.',
'backend-fail-writetemp' => "Tsy afaka manoratra ao anatin'ilay rakitra miserana.",
'backend-fail-closetemp' => 'Tsy afaka manidy ilay rakitra miserana.',
'backend-fail-read' => 'Tsy afaka mamaky ilay rakitra $1.',
'backend-fail-create' => "Tsy afaka manoratra anatin'ilay rakitra $1.",
'backend-fail-readonly' => 'Amin\'izao fotoana dia famakiana ihany ny fitahirizana terminal an\'i "$1". "\'\'$2\'\'" no antony nomena',
'backend-fail-connect' => 'Tsy afaka mifandray amin\'ny terminal fitahirizana "$1".',
'backend-fail-internal' => 'Hadisoana tsy fantatra tao anatin\'ny terminal fitahirizana "$1".',
'backend-fail-usable' => 'Tsy afaka nanoratra ny rakitra "$1" nohon\'ny zo tsy ampy na ny tsy fisian\'ny petra-drakitra.',

# File journal errors
'filejournal-fail-dbconnect' => 'Tsy afaka miantso ilay banky angona laogy ho an\'ny terminal fitahirizana "$1".',
'filejournal-fail-dbquery' => 'Tsy afaka manavao ny banky angona laogy ho an\'ilay terminal fitahirizana "$1".',

# Lock manager
'lockmanager-notlocked' => 'Tsy afaka manalahidy an\'i "$1" ; tsy voahidy ilay izy.',
'lockmanager-fail-closelock' => 'Tsy afaka manidy ilay rakitra fanidiana ho an\'i "$1".',
'lockmanager-fail-deletelock' => 'Tsy afaka manidy ilay rakitra fanidiana ho an\'i "$1"',
'lockmanager-fail-acquirelock' => 'Tsy afaka maka ilay rakitra fanidiana ho an\'i "$1"',
'lockmanager-fail-openlock' => 'Tsy afaka manokatra ilay rakitra fanidiana ho an\'i "$1".',
'lockmanager-fail-releaselock' => 'Tsy afaka mamela ilay fanidiana ho an\'i "$1"',
'lockmanager-fail-db-bucket' => "Tsy ampy ny isan'ireo banky angona fanidiana voaantso anatin'ny baketra (godet) $1.",
'lockmanager-fail-db-release' => "Tsy afaka mamela ny fanidiana eo amin'ny banky angona $1.",
'lockmanager-fail-svr-acquire' => "Tsy afaka maka ny fanidiana eo amin'ny lohamilina $1.",
'lockmanager-fail-svr-release' => "Tsy afaka mamela ny fanidiana eo amin'ny banky angona $1.",

# ZipDirectoryReader
'zip-file-open-error' => "Nitrangana hadisoana teo am-panokafana ilay rakitra ZIP ho an'ny fanamarinana.",
'zip-wrong-format' => "Tsy ZIP ny karazan-drakitr'ilay rakitra voatonona.",

# Special:UploadStash
'uploadstash' => "Sitasy (cache) ho an'ny fampidirana",
'uploadstash-clear' => 'Hamafa ny rakitra voatahiry',
'uploadstash-nofiles' => 'Tsy manana rakitra am-boatakona ianao.',
'uploadstash-badtoken' => 'Tsy navokatra ny fampandefasana ilay tao, mety efa lany daty angamba ny fampahalalam-pamantarana anao.
Avereno fanindroany.',
'uploadstash-errclear' => 'Tsy navokatra ny famafana rakitra.',
'uploadstash-refresh' => 'Vaozina ny lisi-drakitra',

# img_auth script messages
'img-auth-accessdenied' => 'Tsy afa-mankao',
'img-auth-nopathinfo' => "Tsy misy PATH_INFO.
Tsy voaparametatra ny lohamilinao hampita io fampahalalàna io.
Mety mampiasa CGI angamba ilay lohamilina ka tsy mahazaka an'i img_auth
Vangio ny https://www.mediawiki.org/wiki/Manual:Image_Authorization.",
'img-auth-notindir' => 'Ny lalana nangatahana dia tsy ny petra-drakitra nokaonfigiorena.',
'img-auth-badtitle' => "Tsy afaka mamorona lohateny azo ampiasaina avy amin'ny « $1 ».",
'img-auth-nologinnWL' => "Tsy mbola niditra ianao ary tsy ao amin'ny lisitra fotsy « $1 ».",
'img-auth-nofile' => 'Tsy misy ny rakitra « $1 ».',
'img-auth-isdir' => "Nanandrana nakao amin'ny petra-drakitra « $1 » ianao.
Ny petra-drakitra misy rakitra ihany no azo aleha.",
'img-auth-streaming' => 'Vaky streaming « $1 ».',
'img-auth-public' => "Ny asa ataon'i img_auth.php dia maneho ny rakitry ny wiki an'olona.
ity wiki ity dia no-regler-na ho sarababem-bahoaka.",
'img-auth-noread' => "Tsy manana ny alalam-pamakiana ilay mpikambana eo amin'ny « $1 ».",
'img-auth-bad-query-string' => 'Manana tohintsora-kataka tsy manara-penitra ilay URL.',

# HTTP errors
'http-invalid-url' => 'URL diso : $1',
'http-invalid-scheme' => "Tsy zaka ny URL miaraka amin'ny sema « $1 »",
'http-request-error' => 'Tsi-fetezana tsy fantam-piaviana teo ampandefasana ilay hataka.',
'http-read-error' => "Tsy fetezana momban'ny famakiana HTTP.",
'http-timed-out' => 'Ny fangatahana HTTP dia efa lany daty.',
'http-curl-error' => 'Tsi-fetezana teo am-pangalana ny URL : $1',
'http-bad-status' => 'Nisy tsi-fetezana teo ampandefasana ny hataka HTTP: $1 $2',

# Some likely curl errors. More could be added from <http://curl.haxx.se/libcurl/c/libcurl-errors.html>
'upload-curl-error6' => 'URL tsy afaka andehanana',
'upload-curl-error6-text' => 'Tsy afaka takarina ny URL nomena. Marino raha voasoratra tsara ny URL ary raha an-tranonkala ilay sehatra.',
'upload-curl-error28' => 'Nihoatra ny fotoana fampidiran-drakitra',
'upload-curl-error28-text' => "Ela loatra ilay sehatra vao mamaly. Marino raha an-tranonkala ilay sehatra, miandraza kely ary avereno indray. Afaka mamerina amin'ny ora tsy itsidihana azy matetika ianao.",

'license' => 'Lisansy:',
'license-header' => "Navoaka tambanin'ny lisansy",
'nolicense' => 'Tsy misy safidy',
'license-nopreview' => '(Topi-maso tsy misy)',
'upload_source_url' => " (URL misy ary azo vangian'ny daholobe)",
'upload_source_file' => " (rakitra eo amin'ny milinao)",

# Special:ListFiles
'listfiles-summary' => "Ahitana ny rakitra rehetra nampidirina ity pejy manokana ity.
Rehefa sivanin'ny mpikambana iray izy ity, ny rakitra izay ahitana santiôna vaovao indrindra izay nalefan'io mpikamana io no aseho.",
'listfiles_search_for' => 'Hitady anarana media :',
'imgfile' => 'rakitra',
'listfiles' => "Lisitran'ny rakitra",
'listfiles_thumb' => 'Sary nakelezina',
'listfiles_date' => 'Daty',
'listfiles_name' => 'Anarana',
'listfiles_user' => 'Mpikambana',
'listfiles_size' => 'Habe',
'listfiles_description' => 'Visavisa',
'listfiles_count' => 'Version',
'listfiles-latestversion-yes' => 'Eny',
'listfiles-latestversion-no' => 'Tsia',

# File description page
'file-anchor-link' => 'Rakitra',
'filehist' => 'Tantara ny rakitra',
'filehist-help' => "Tsindrio eo amin'ny daty/ora iray mba hijery ny toetra n'ilay rakitra tamin'io fotoana io.",
'filehist-deleteall' => 'fafao daholo',
'filehist-deleteone' => 'hamafa',
'filehist-revert' => 'hamerina',
'filehist-current' => 'ankehitriny',
'filehist-datetime' => 'Daty sy ora',
'filehist-thumb' => 'saritapaka',
'filehist-thumbtext' => "Vignette ho an'ny $1",
'filehist-nothumb' => 'Tsy misy saritapaka',
'filehist-user' => 'Mpikambana',
'filehist-dimensions' => 'Habe',
'filehist-filesize' => "Hangezan'ilay rakitra",
'filehist-comment' => 'resaka',
'filehist-missing' => 'Tsy ampy rakitra',
'imagelinks' => "Fampiasana an'io rakitra io",
'linkstoimage' => "Ireto avy no {{PLURAL:$1|pejy mirohy|pejy mirohy}} ($1) amin'io rakitra io:",
'nolinkstoimage' => "Tsy misy pejy mirohy amin'ity sary ity.",
'morelinkstoimage' => "Hijery [[Special:WhatLinksHere/$1|rohy fanampiny]] makany amin'io rakitra io.",
'linkstoimage-redirect' => '$1 (fihodinana) $2',
'sharedupload' => "Mety ho rakitra itambarana amin'ny tetikasa hafa ny rakitra $1.",
'sharedupload-desc-here' => "Avy amin'i $1 io rakitra io ary mety ampiasain'ny tetikasa hafa.
Aseho eo ambany ny [$2 famisavisana ilay rakitra].",
'filepage-nofile' => 'Tsy nahitana rakitra mitondra io anarana io.',
'filepage-nofile-link' => 'Tsy misy rakitra mitondra io anarana io, fa afaka [$1 mampiditra azy ianao].',
'uploadnewversion-linktext' => "Andefa version vaovao n'ity rakitra ity",
'shared-repo-from' => "avy amin'ny $1",
'shared-repo' => 'petra-drakitra iraisana',
'upload-disallowed-here' => 'Tsy azonao itsahina ity rakitra ity.',

# File reversion
'filerevert' => "Hamerinan'i $1",
'filerevert-legend' => 'Hamerina ilay rakitra',
'filerevert-intro' => "Eo am-pamerenana ilay rakitra '''[[Media:$1|$1]]''' any amin'ny [$4 santiona tamin'ny $2 tamin'ny $3].",
'filerevert-comment' => 'Antony :',
'filerevert-defaultcomment' => "Voaverina ny santiônan'ny $1 tamin'ny $2",
'filerevert-submit' => 'Hamerina',
'filerevert-success' => "Naverina tamin' [$4 ny santiôn'ny $2 tamin'ny $3] i '''[[Media:$1|$1]]'''",
'filerevert-badversion' => "An-toerana, tsy misy santiôna nialoha io rakitra io miankina amin'ny daty voatoro.",

# File deletion
'filedelete' => 'Hamafa $1',
'filedelete-legend' => 'Fafao ilay rakitra',
'filedelete-intro' => "Ampamafana ny rakitra '''[[Media:$1|$1]]''' ianao miaraka amin'ny tantarany rehetra.",
'filedelete-intro-old' => "Am-pamafana ny santiôna '''[[Media:$1|$1]]''' tamin'ny [$4 $2 tamin'ny $3] ianao.",
'filedelete-comment' => 'Antony :',
'filedelete-submit' => 'Hamafa',
'filedelete-success' => "voafafa '''$1'''.",
'filedelete-success-old' => "Voafafa ny santiônan'ny '''[[Media:$1|$1]]''' tamin'ny $2 tamin'ny $3.",
'filedelete-nofile' => "Tsy misy '''$1'''.",
'filedelete-nofile-old' => "Tsy nisy santiôna voatahirin'i '''$1''' miaraka amin'ny mahasamihafa naseho.",
'filedelete-otherreason' => 'Antony fanampiny :',
'filedelete-reason-otherlist' => 'Antony hafa',
'filedelete-reason-dropdown' => '* Antom-pamafàna rakitra miasa matetika
** Tsi-fanajana ny zom-pamorona
** Rakitra efa misy',
'filedelete-edit-reasonlist' => 'Hanova ny antom-pamafàna',
'filedelete-maintenance' => 'Ny famafana sy ny famerenan-drakitra dia tsy alefa mandritra ny fikojakojana.',
'filedelete-maintenance-title' => 'Tsy afaka mamafa ilay rakitra',

# MIME search
'mimesearch' => 'Fikarohana MIME',
'mimesearch-summary' => "Ity pejy ity dia afahanao manalisitra ny rakitra azo jerena amin'ny alàlan' ity wiki ity arakaraka ny karazana votoatiny MIME ananany

Fampidirana : ''karazambotoatiny''/''zanakarazana'', ohatra par exemple <code>sary/jpeg</code>",
'mimetype' => 'Karazana MIME :',
'download' => 'Hampidina',

# Unwatched pages
'unwatchedpages' => 'Pejy voaaisotra ny fanaraha-maso azy',

# List redirects
'listredirects' => 'Lisitra ny fihodinana',

# Unused templates
'unusedtemplates' => 'Endrika tsy miasa',
'unusedtemplatestext' => "Ity pejy ity dia manalisitra ny pejy rehetra ao amin'ny anaran-tsehatra « {{ns:template}} » ao tsy anaty pejy hafa.
Aza manadino manamarina raha tsy misy rohy makany amin'ny endrika hafa alohan'ny mamafa azy.",
'unusedtemplateswlh' => 'rohy hafa',

# Random page
'randompage' => 'Takelaka kisendra',
'randompage-nopages' => "Tsy misy pejy ao amin'ny anaran-tsehatra {{PLURAL:$2}} : $1.",

# Random page in category
'randomincategory' => "Pejy kisendra ao amin'ny sokajy",
'randomincategory-invalidcategory' => 'Tsy anaran-tsokajy azo raisina "$1"',
'randomincategory-nopages' => "Tsy misy pejy ao amin'i [[:Category:$1]]",
'randomincategory-selectcategory' => "Haka pejy kisendra ao amin'ny sokajy: $1 $2",
'randomincategory-selectcategory-submit' => 'Alefa',

# Random redirect
'randomredirect' => 'Pejy fihodinana kisendra',
'randomredirect-nopages' => "Tsy misy pejy fihodinana eo amin'ny anaran-tsehatra «$1»",

# Statistics
'statistics' => 'Statistika',
'statistics-header-pages' => "Statistikan'ny pejy",
'statistics-header-edits' => "Statistikan'ny fanovana",
'statistics-header-views' => "Statistikan'ny tsidika",
'statistics-header-users' => "Statistikan'ny mpikambana",
'statistics-header-hooks' => 'statistika hafa',
'statistics-articles' => 'Lahatsoratra',
'statistics-pages' => 'Pejy rehetra',
'statistics-pages-desc' => "Pejy rehetra eto amin'ity wiki ity: pejin-dresaka, redirect, sns.",
'statistics-files' => 'Rakitra voaray',
'statistics-edits' => 'Isan’ny fanovana hatry ny fisian’i {{SITENAME}}',
'statistics-edits-average' => "Isan'ny fanovana isaky ny pejy",
'statistics-views-total' => 'Tsidika',
'statistics-views-peredit' => 'Tsidika isaky ny fanovana',
'statistics-users' => '[[Special:ListUsers|Mpikambana]] nisoratra anarana',
'statistics-users-active' => 'Mpikambana mavitrika',
'statistics-users-active-desc' => "Mpikambana nanao zavatra teto tanatin'ny $1 andro{{PLURAL:}}.",
'statistics-mostpopular' => 'Pejy voatsidika',

'pageswithprop' => 'Pejy misy toe-pejy',
'pageswithprop-legend' => 'Pejy misy toe-pejy',
'pageswithprop-text' => 'Manalisitra ny pejy mampiasa toe-pejy manokana ity',
'pageswithprop-prop' => "Anaran'ilay tondro",
'pageswithprop-submit' => 'Alefa',
'pageswithprop-prophidden-long' => 'Sandan-toe-dahatsoratra lava miafina ($1)',
'pageswithprop-prophidden-binary' => 'sandan-toetra roa fototra miafina ($1)',

'doubleredirects' => 'Fihodinana roa',
'double-redirect-fixed-move' => "Ity fihodinana ity, nanana ny tanjona [[$1]] novaina anarana, dia mitondra mankany amin'ny [[$2]].",
'double-redirect-fixer' => 'Mpanitsy fihodinana',

'brokenredirects' => 'Tapaka ny redirection',
'brokenredirectstext' => "Mitondra makany amin'ny pejy tsy misy ireo fihodinana ireo :",
'brokenredirects-edit' => 'ovao',
'brokenredirects-delete' => 'fafao',

'withoutinterwiki' => 'Pejy tsy manan-drohi-piteny',
'withoutinterwiki-summary' => "Ireo pejy ireo dia tsy manan-drohy makany amin'ny fiteny hafa :",
'withoutinterwiki-legend' => 'Tovona',
'withoutinterwiki-submit' => 'Aseho',

'fewestrevisions' => 'Pejy vitsy mpanova',

# Miscellaneous special pages
'nbytes' => '$1 {{PLURAL:$1|oktety|oktety}}',
'ncategories' => '{{PLURAL:$1|vondrona|vondrona}} $1',
'nlinks' => '{{PLURAL:$1|rohy|rohy}} $1',
'nmembers' => '{{PLURAL:$1|mpikambana|mpikambana}} $1',
'nrevisions' => '{{PLURAL:$1|fanovana|fanovana}} $1',
'nviews' => '{{PLURAL:}}Tsidika $1',
'nimagelinks' => "Ampiasain'ny pejy miisa{{PLURAL:}} $1",
'ntransclusions' => "Ampiasaina eo amin'ny pejy miisa $1 {{PLURAL:}}",
'specialpage-empty' => 'Tsy misy valiny ho aseho.',
'lonelypages' => 'Pejy manirery',
'lonelypagestext' => "Ireo pejy ireo dia tsy voarohy sy tsy ampiasain'ny pejin' ity wiki ity.",
'uncategorizedpages' => 'Pejy tsy voasokajy',
'uncategorizedcategories' => 'Sokajy tsy voasokajy',
'uncategorizedimages' => 'Rakitra tsy voasokajy',
'uncategorizedtemplates' => 'Endrika tsy voasokajy',
'unusedcategories' => 'Sokajy tsy miasa',
'unusedimages' => 'Rakitra tsy miasa',
'popularpages' => 'Pejy maresaka',
'wantedcategories' => 'Vondrona tokony hoforonina',
'wantedpages' => 'Pejy tokony hoforonina',
'wantedpages-badtitle' => "Lohateny tsy ekena amin'ny valiny : $1",
'wantedfiles' => 'Rakitra tadiavina',
'wantedtemplates' => 'Endrika tadiavina',
'mostlinked' => "Misy firohizana betsaka amin'ny pejy hafa",
'mostlinkedcategories' => "Misy firohizana betsaka amin'ny sokajy",
'mostlinkedtemplates' => "Misy firohizana betsaka amin'ny endrika",
'mostcategories' => 'Lahatsoratra misy sokajy betsaka indrindra',
'mostimages' => "Misy firohizana betsaka amin'ny sary",
'mostinterwikis' => 'Pejy be interwiki indrindra',
'mostrevisions' => 'Lahatsoratra niova im-betsaka indrindra',
'prefixindex' => "Pejy manomboka amin'ny...",
'prefixindex-namespace' => 'Ny pejy rehetra mitondra ny tovona (anaran-tsehatra $1)',
'shortpages' => 'Pejy fohy',
'longpages' => 'Pejy lavabe',
'deadendpages' => 'Pejy tsy mirohy',
'deadendpagestext' => "Tsy misy rohy mitondra makany amin'ny pejin'ny wiki hafa ireo pejy ireo.",
'protectedpages' => 'Pejy voaaro',
'protectedpages-indef' => 'Ny fiarovana maharitra ihany',
'protectedpages-cascade' => 'Ny fanovana an-driana ihany',
'protectedpagestext' => "Ny pejy manaraka dia voaaro amin'ny fanovana sy ny famindrana.",
'protectedpagesempty' => 'Tsy misy pejy voaaro ankehitriny.',
'protectedtitles' => 'Lohateny voaaro',
'protectedtitlestext' => "Ny lohateny manaraka dia voaaro amin'ny famoronana",
'protectedtitlesempty' => "Tsy misy lohateny voaaro miaraka amin'ireo mpihazaka ireo.",
'listusers' => 'Lisitry ny mpikambana',
'listusers-editsonly' => "Ny mpikambana manam-pandraisan'anjara ihany no aseho",
'listusers-creationsort' => "Afantina amin'ny daty fanokafana",
'usereditcount' => 'fanovana $1 {{PLURAL:}}',
'usercreated' => "Noforonina ny {{GENDER:$3}} $1 tamin'ny $2",
'newpages' => 'Pejy vaovao',
'newpages-username' => 'Solonanarana:',
'ancientpages' => 'Ireo pejy tranainy indrindra',
'move' => 'Hamindra azy toerana',
'movethispage' => 'Afindrao ity pejy ity',
'unusedimagestext' => "<p>Mariho tsara aloha fa mety misy sehatra hafa mampiasa ireto sary ireto
ka mety ho antony tokony hamelana azy eto izany na dia tsy miasa ato anatin'ity
wiki ity aza izy.</p>",
'unusedcategoriestext' => 'Ireto sokajy manaraka ireto dia noforonina kanefa tsy misy pejy na dia iray aza mampiasa azy akory.',
'notargettitle' => 'Tsy misy tanjona',
'notargettext' => 'Tsy nofaritanao ny pejy na solonanarana mpikambana hanaovana io asa io.',
'nopagetitle' => "Tsy misy pejy tanjona tahak' izany",
'nopagetext' => 'Tsy misy ny pejy tanjona nolazainareo.',
'pager-newer-n' => '$1 {{PLURAL:$1|vao haingana|vao haingana}}',
'pager-older-n' => '$1 {{PLURAL:$1|taloha|taloha}}',
'suppress' => 'Hitondra',
'querypage-disabled' => 'Tsy ampiasaina ity pejy manokana ity mba hitsitsy ny solosaina',

# Book sources
'booksources' => 'boky tsiahy',
'booksources-search-legend' => "hikaroka anatin'ny boky todika",
'booksources-go' => 'Ataovy lisitra',
'booksources-text' => "Ity misy lisitra maneho ny rohy makany amin'ny sehatra mivarotra boky vaovao sy efa vaky ary mety ahitanao fampahalalàna momban'ny boky sy soratra notadiavinao :",
'booksources-invalid-isbn' => 'Ny ISBN nomena dia mety diso ; marino raha diso ianao teo am-pandikanana ny loharano fotony.',

# Special:Log
'specialloguserlabel' => 'Mpikambana nanao :',
'speciallogtitlelabel' => 'Tanjona (lohateny na mpikambana) :',
'log' => 'Tatitr’asa',
'all-logs-page' => 'Ny tatitr’asa',
'alllogstext' => "Seho nakambana ho an'ny laogy rehetra azo jerena eto amin'ny {{SITENAME}}.
Azonao ferana ny fahitana ny tao amin'ny fisafidianana karazana laogy iray, anaram-pikambana iray na pejy iray (samihafa ny sorabaventy sy soramadinika).",
'logempty' => 'Tsy nahitana.',
'log-title-wildcard' => "Hitady amin'ny lohateny manomboka amin'io soratra io",
'showhideselectedlogentries' => 'Haneho/Hanafina ny iditry ny laogy nofidiana',

# Special:AllPages
'allpages' => 'Pejy rehetra',
'alphaindexline' => "$1 hatramin'ny $2",
'nextpage' => 'Pejy manaraka ($1)',
'prevpage' => 'Pejy taloha ($1)',
'allpagesfrom' => 'Asehoy ny pejy manomboka ny:',
'allpagesto' => "Asehoy ny pejy manomboka amin'ny :",
'allarticles' => 'Lahatsoratra rehetra',
'allinnamespace' => 'Pejy rehetra ($1 namespace)',
'allnotinnamespace' => "Ny pejy rehetra (tsy ao amin'ny $1 namespace)",
'allpagesprev' => 'Aloha',
'allpagesnext' => 'Manaraka',
'allpagessubmit' => 'Alefa',
'allpagesprefix' => "Asehoy ny pejy miantomboka amin'ny:",
'allpagesbadtitle' => 'Tsy mety ny anaram-pejy : misy tovona iraisam-piteny na interwiki natokana, na misy soratra iray na maro tsy azo ampiasaina anaty anaram-pejy.',
'allpages-bad-ns' => '{{SITENAME}} dia tsy manana anaran-tsehatra mitondra anarana « $1 ».',
'allpages-hide-redirects' => 'Haneho ny fihodinana',

# SpecialCachedPage
'cachedspecial-refresh-now' => 'Hijery ny farany indrindra',

# Special:Categories
'categories' => 'Sokajy',
'categoriespagetext' => "{{PLURAL:$1}}Ampiasain'ny rakitra na pejy ireo sokajy manaraka ireo.
Tsy hiseho eto ny [[Special:UnusedCategories|sokajy tsy miasa]].
Vangio koa ny [[Special:WantedCategories|sokajy ilaina]].",
'categoriesfrom' => "Haneho ny sokajy manomboka amin'ny :",
'special-categories-sort-count' => "afantina amin'ny isan-javatra",
'special-categories-sort-abc' => 'famantinana ara-abidy',

# Special:DeletedContributions
'deletedcontributions' => "Fandraisan'anjara voafafa",
'deletedcontributions-title' => "fandraisan'anjara voafafa",
'sp-deletedcontributions-contribs' => "fandraisan'anjara",

# Special:LinkSearch
'linksearch' => 'Fikarohana rohy ivelany',
'linksearch-pat' => 'Volana tadiavina :',
'linksearch-ns' => 'Anaran-tsehatra :',
'linksearch-ok' => 'Fikarohana',
'linksearch-text' => "Azo ampiasaina ny soratra joker toa i « *.wikipedia.org ».
Mila top-level domain ambonimbony kokoa izy ireo, sahala « *.org » <br />
Protokoly zaka <code>$1</code> aza ampiana ao amin'ny karokao izy ireo.",
'linksearch-line' => "$1 dia voarohy amin'ny $2",
'linksearch-error' => "Ny soratra joker dia ampiasaina anatin'ny fanombohan'ny anaran-tsehatry ny milina hôte ihany.",

# Special:ListUsers
'listusersfrom' => "Haneho ny mpikambana manomboka amin'ny :",
'listusers-submit' => 'Aseho',
'listusers-noresult' => 'Tsy nahitana mpikambana.',
'listusers-blocked' => '(voasakana)',

# Special:ActiveUsers
'activeusers' => 'Lisitry ny mpikambana mavitrika',
'activeusers-intro' => 'Ity ny lisitry ny mpikambana izay nanao zavatra iray nandritry ny andro $1 farany. {{PLURAL:}}',
'activeusers-count' => "Tao $1{{PLURAL:}} tanatin'ny $3 andro",
'activeusers-from' => 'Aseho ny mpikambana hatry ny :',
'activeusers-hidebots' => 'Asitriho ny robo',
'activeusers-hidesysops' => 'Asitriho ny mpandrindra',
'activeusers-noresult' => 'Tsy nahitana mpikambana.',

# Special:ListGroupRights
'listgrouprights' => "Fahefan'ny vondrom-pikambana",
'listgrouprights-summary' => "Ity pejy ity dia ahitana ny lisitry ny vondrom-pikambana voafaritra ato amin'ity wiki ity ary ny zo ananany. Mety misy [[{{MediaWiki:Listgrouprights-helppage}}|fampahalalana fanampiny]] mikasika ny zo manokana.",
'listgrouprights-key' => '* <span class="listgrouprights-granted">Zo nomena</span>
* <span class="listgrouprights-revoked">Zo nofoanana</span>',
'listgrouprights-group' => 'Vondrona/Gropy',
'listgrouprights-rights' => 'Fahefana miaraka aminy',
'listgrouprights-helppage' => "Help:Fahefan'ny vondrona",
'listgrouprights-members' => '(lisitry ny mpikambana)',
'listgrouprights-addgroup' => '{{PLURAL:$2}}Manampy ny mpikambana : $1',
'listgrouprights-removegroup' => "Manala ny mpikambana {{PLURAL:$2}}amin'ny gropy : $1",
'listgrouprights-addgroup-all' => 'Manampy mpikambana anaty vondrona rehetra',
'listgrouprights-removegroup-all' => 'Manala mpikambana anaty gropy rehetra',
'listgrouprights-addgroup-self' => "Afaka manampy ny tenany amin'ny vondrona{{PLURAL:$2}}: $1",
'listgrouprights-removegroup-self' => "Afaka manala ny tenany amin'ny vondrona{{PLURAL:$2}} : $1",
'listgrouprights-addgroup-self-all' => "Manampy ny vondrom-pikambana rehetra amin'ny kaontiny",
'listgrouprights-removegroup-self-all' => "Manala ny vondrom-pikambana rehetra amin'ny kaontiny",

# Email user
'mailnologin' => 'Tsy misy adiresy handefasana ny tenimiafina',
'mailnologintext' => "Mila [[Special:UserLogin|miditra]] ianao sady manana imailaka mandeha sy voamarina ao amin'ny [[Special:Preferences|mombamomba anao]] vao afaka mandefa imailaka amin'ny mpikambana hafa.",
'emailuser' => 'Andefaso imailaka io mpikambana io',
'emailuser-title-target' => "Handefa mailaka any amin'ity mpikambana ity{{GENDER:$1}}",
'emailuser-title-notarget' => "Handefa imailaka an'ilay mpikambana",
'emailpage' => 'Andefaso imailaka io mpikambana io',
'emailpagetext' => 'Azonao ampiasaina io fôrmiolera eo ambany io mba handefa mailaka mankany amin\'ny mpikambana $1. Ho ao amin\'ny saha "Mpandefa" (Expéditeur) ny adiresy mailakao ka ho afaka hamaly anao avy hatrany ilay mpandray ny hafatra.',
'usermailererror' => "Misy tsy mety amin'ny lohatenin'ny imailaka:",
'defemailsubject' => '{{SITENAME}} Mailaky ny mpikambana "$1"',
'usermaildisabled' => 'Tsy azo mifandefa imailaka ny mpikambana',
'usermaildisabledtext' => "Tsy mahazo mandefa imailaka any amin'ny mpikamban'ity wiki ity ianao",
'noemailtitle' => 'Tsy misy adiresy imailaka',
'noemailtext' => "Na tsy nanome adiresy imailaka voamarina io mpikambana io,
na tsy maniry handray imailaka avy amin'ny mpikambana hafa izy.",
'nowikiemailtitle' => 'Tsy manaiky imailaka alefa ho azy',
'nowikiemailtext' => "Ity mpikambana ity dia te-hahazo imailaka avy amin'ny mpikambana hafa.",
'emailnotarget' => "Anaram-pikamban'ny mpandray hafatra tsy misy na diso.",
'emailtarget' => "Atsofohy ny anaram-pikamban'ilay tanjona",
'emailusername' => 'Anaram-pikambana :',
'emailusernamesubmit' => 'Alefa',
'email-legend' => "Handefa imailaka any amin'ny mpikambana hafa an'i {{SITENAME}}",
'emailfrom' => "Avy tamin'i",
'emailto' => "Ho an'i",
'emailsubject' => 'Lohateny :',
'emailmessage' => 'Hafatra',
'emailsend' => 'Alefaso',
'emailccme' => "Andefaso tahak' ity hafatra ity ahy.",
'emailccsubject' => "Tahaka ny hafatrao nalefa tany amin'i $1 : $2",
'emailsent' => 'Lasa',
'emailsenttext' => 'Lasa soa aman-tsara ny imailaka nalefanao.',
'emailuserfooter' => "Ity imailaka ity dia nalefan'i « $1 » tany amin'i « $2 » tamin'ny alalan'ny « Handefa Imailaka » an'i {{SITENAME}}.",

# User Messenger
'usermessage-summary' => 'Namela hafatra rindrankajy',
'usermessage-editor' => 'Mpampita hafatry ny rindrankajy',

# Watchlist
'watchlist' => 'Pejy arahako',
'mywatchlist' => 'Pejy arahana',
'watchlistfor2' => "Ho an'i $1 $2",
'nowatchlist' => 'Tsy manaraka pejy ianao.',
'watchlistanontext' => "Andana $1 hahafahanao mijery na manova zavatra ao amin'ny pejy arahanao.",
'watchnologin' => 'Tsy niditra',
'watchnologintext' => 'Mila [[Special:UserLogin|miditra]] ianao vao afaka manova ny lisitry ny pejy arahanao.',
'addwatch' => "Ampiana ao amin'ny pejy arahana",
'addedwatchtext' => 'Voalisitra ao amin\'ny [[Special:Watchlist|pejy arahanao]] ilay pejy "[[:$1]]". Ny fanovana ho avy ao amin\'ilay pejy ary ao amin\'ilay pejin-dresaka dia ho voalisitra any.',
'removewatch' => "Alàna amin'ny pejy arahana",
'removedwatchtext' => 'Tsy [[Special:Watchlist|arahanao]] intsony ny pejy [[:$1]].',
'watch' => 'Arahana',
'watchthispage' => 'Hanaraka ity pejy ity',
'unwatch' => 'Aza arahana intsony',
'unwatchthispage' => 'Aza arahana intsony',
'notanarticle' => 'Tsy votoatim-pejy ity pejy ity',
'notvisiblerev' => 'Voafafa ilay santiôna',
'watchlist-details' => "Pejy $1{{PLURAL:}} ao amin'ny lisitry ny pejy arahanao, tsy isaina ny pejin-dresaka.",
'wlheader-enotif' => "Alefa ny fampilazana amin'ny mailaka.",
'wlheader-showupdated' => "Aseho '''sorabaventy''' ny pejy niova taorian'ny famangianao azy farany.",
'watchmethod-recent' => 'fanamarinana ny fanovana farany hahitana pejy arahana',
'watchmethod-list' => 'fanamarinana ny pejy arahana ahitana fanovana farany',
'watchlistcontains' => "Ao amin'ny pejy arahanao dia ahitana pejy $1{{PLURAL:}}.",
'iteminvalidname' => "Olana amin'ny zavatra « $1 » : tsy ara-dalàna ny anarana...",
'wlnote' => "Eo ambany dia ahitana ny  {{PLURAL:$1|fanovana farany indrindra|ny fanovana ''$1'' farany}} natao tanatin'ny adin'ny {{PLURAL:$2|iray|'''$2'''}}, nanomboka ny $3, $4.",
'wlshowlast' => 'Haneho ny $1 ora farany, ny $2 andro farany na $3',
'watchlist-options' => 'Safidy ny lisitry ny pejy arahana',

# Displayed when you click the "watch" button and it is in the process of watching
'watching' => 'Fanarahana...',
'unwatching' => 'Fanalana ny fanarahana...',
'watcherrortext' => "Nisy hadisoana nitranga teo ampanovana ny safidy ny lisitry ny pejy arahanao ho an'i « $1 ».",

'enotif_mailer' => "Fomba fampandrenesana amin'ny alalan'ny imailaka an'i {{SITENAME}}",
'enotif_reset' => 'Marihana ho efa voavaky ny pejy rehetra',
'enotif_impersonal_salutation' => "Mpikamban'i {{SITENAME}}",
'enotif_lastvisited' => "Jereo eto $1 ny niova rehetra hatramin'ny fitsidihanao farany.",
'enotif_lastdiff' => 'Jereo $1 mba ahitana ireo fanovana ireo.',
'enotif_anon_editor' => 'mpikambana tsy nisoratra anarana $1',
'enotif_body' => 'Tompoko $WATCHINGUSERNAME,

$PAGEINTRO $NEWPAGE

Ambangovangon\'ny mpikambana nanova : $PAGESUMMARY $PAGEMINOREDIT

Ifandraisana amin\'io mpikambana io :
mailaka : $PAGEEDITOR_EMAIL
wiki : $PAGEEDITOR_WIKI

Tsy hisy fampandrenesana hafa raha misy mpikambana manova aorian\'ny nandefasana ity mailaka ity, raha tsy hoe mitsidika ilay pejy ianao. Azonao atao koa ny mamerina ho aotra ny flag fampandrenesana ho an\'ny pejy rehetra ao amin\'ny lisitry ny pejy arahanao.

             Ny rafitr\'i {{SITENAME}} mampandre anao.

--
Rehefa hanova ny parametatra mikasika ny fampandrenesana amin\'ny alalan\'ny mailaka, tsidiho
{{canonicalurl:{{#special:Preferences}}}}


Rehefa tia hanova ny parametatray ny lisitry ny pejy arahanao, tsidiho
{{canonicalurl:{{#special:EditWatchlist}}}}

Rehefa tsy hanaraka ilay pejy intsony ianao dia tsidiho
$UNWATCHURL

Verindrohy ary fanampiana:
{{canonicalurl:{{MediaWiki:Helppage}}}}',
'created' => 'voaforona',
'changed' => 'voaova',

# Delete
'deletepage' => 'Hamafa ny pejy',
'confirm' => 'Antero',
'excontent' => "votoatiny: '$1'",
'excontentauthor' => "votoatiny: '$1' (ary i '[[Special:Contributions/$2|$2]]' irery ihany no nikitika azy)",
'exbeforeblank' => "Talohan'ny namafana ny votoatiny : « $1 »",
'exblank' => 'tsy nisy na inona na inona ilay pejy',
'delete-confirm' => 'Hamafa ny « $1 »',
'delete-legend' => 'Fafao',
'historywarning' => "'''Tandremo :''' Ny pejy hofafanao io dia manana tantaram-pejy misy famerenana $1{{PLURAL:}}",
'confirmdeletetext' => "Handeha hamafa tanteraka ny pejy na sary miaraka amin'ny tantarany rehetra
ao anatin'ny toby ianao. Azafady mba hamafiso fa irinao tokoa izany,
fantatrao ny vokany ary mahalala ianao fa tsy mifanipaka amin'ny
[[{{MediaWiki:Policy-url}}|fepetra]] izao ataonao izany.",
'actioncomplete' => 'Vita ny asa',
'actionfailed' => 'Tsy nandeha ny tao',
'deletedtext' => 'Voafafa i "$1".
Jereo amin\'ny $2 ny lisitry ny famafana pejy faramparany.',
'dellogpage' => 'Laogim-pamafana pejy',
'dellogpagetext' => 'Eto ambany eto ny lisitry ny famafana pejy/sary faramparany.',
'deletionlog' => 'laogim-pamafàna',
'reverted' => 'Naverina ny votoatiny nisy teo aloha',
'deletecomment' => 'Antony :',
'deleteotherreason' => 'antony hafa miampyy:',
'deletereasonotherlist' => 'antony',
'deletereason-dropdown' => "* Antom-pamafana matetika miasa
** Hataka avy amin'ny tompony
** Tsi-fanajana ny zom-pamorona
** Fandotoana",
'delete-edit-reasonlist' => 'Hanova ny antony amafana pejy',
'delete-toobig' => 'Ity pejy  ity dia manana tantaram-panovana be, mihoatra ny santiôna {{PLURAL:$1}} $1.
Ny famafana ireo pejy ireto dia voafetra mba tsy hikorontana {{SITENAME}}.',
'delete-warning-toobig' => "Lava be mihitsy ny tantaram-piovan'ity pejy ity, mihoatra santiôna $1{{PLURAL:}}.
Mety hitondra fikorontanana ao amin'ny banky angon'i {{SITENAME}} ny famafana azy ;
ataovy am-pitandremana ity tao ity.",

# Rollback
'rollback' => 'Foano indray ilay fanovana',
'rollback_short' => 'Aza ovaina indray',
'rollbacklink' => 'foano',
'rollbacklinkcount' => 'hamoana fanovana{{PLURAL:$1}} $1',
'rollbackfailed' => "Tsy voaverina amin'ny teo aloha",
'cantrollback' => "Tsy afaka iverenana ny fanovana; ny mpanova farany ihany no tompon'ny pejy.",
'alreadyrolled' => "Tsy afaka foanana ny fanovana ny pejy « [[:$1]] » nataon'i [[User:$2|$2]] ([[User talk:$2|Dinika]]{{int:pipe-separator}}[[Special:Contributions/$2|{{int:contribslink}}]])

Efa nataon'i [[User:$3|$3]] ([[User talk:$3|dinika]]{{int:pipe-separator}}[[Special:Contributions/$3|{{int:contribslink}}]]) ny fanovana farany.",
'editcomment' => "Toy izao no fanamarihana momba io fanovana io: \"''\$1''\".",
'revertpage' => "Voafafa ny fanovana ny [[Special:Contributions/$2|$2]] ([[User talk:$2|Dinika]]); voaverina amin'ny votoatiny teo aloha nataon'i [[User:$1|$1]]",
'revertpage-nouser' => "Manala ny fanovana (nataon'ny anaram-pikambana nesorina), miverina any amin'ny santiona farany nataon'i  [[User:$1|$1]]",
'rollback-success' => "Fanalàna ny fanovana nataon'i $1 ;
miverina any amin'ny santiôna farany nataon'i $2.",

# Edit tokens
'sessionfailure-title' => 'Tsi-fetezaka mikasika ny kaonty idirana',
'sessionfailure' => 'Ohatry ny misy olana ny fidirana amin\'ny kaontinao ; 
nofoanana ilay tao mba tsy hisy fanodinana fotaom-pidirana (session).
Tsindrio "Mialoha" ary vaozy ilay pejy niavianao ary andramo fanindroany.',

# Protect
'protectlogpage' => 'Tatitr’asa momban’ny fiarovana',
'protectlogtext' => "Eto ambany ny lisitry ny fiarovana/fanalana hidy ny pejy. 
Ho ann'y fanazavana fanampiny, jereo [[Special:ProtectedPages|ny lisitry ny pejy voaaro]] ho an'ny pejy fiarovana amin'izao fotoana izao.",
'protectedarticle' => 'voaaro ny pejy "[[$1]]"',
'modifiedarticleprotection' => "nanova ny haabo ny fiarovana ho an'ny « [[$1]] »",
'unprotectedarticle' => "nanala ny fiarovana an'i « [[$1]] »",
'movedarticleprotection' => 'nanova ny safidim-piarovana : « [[$2]] » lasa « [[$1]] »',
'protect-title' => "Hanova ny lentam-piarovana ho an'i « $1 »",
'protect-title-notallowed' => "Hijery ny lentam-piarovana ho an'i «[[$1]]»",
'prot_1movedto2' => '[[$1]] voaova anarana ho [[$2]]',
'protect-badnamespace-title' => 'Anaran-tsehatra tsy azo arovana',
'protect-badnamespace-text' => "Tsy afaka arovana ny pejy ao amin'io anaran-tsehatra io.",
'protect-norestrictiontypes-title' => 'Pejy tsy azo arovana',
'protect-legend' => 'Fanekena ny fiarovana pejy',
'protectcomment' => 'Antony :',
'protectexpiry' => 'Daty fitsaharana :',
'protect_expiry_invalid' => 'Tsy mety ilay daty fialàna.',
'protect_expiry_old' => 'Efa lasa ilay daty fialàna.',
'protect-unchain-permissions' => 'Aitatra ny fomba fiarovana',
'protect-text' => "Afaka jerenao na ovainao eto ny politikam-piarovana ny pejy '''$1'''.",
'protect-locked-blocked' => "Tsy afaka ovanao ny sokajy ny fiarovana raha tsy mahazo manoratra ianao.
Ity ny sokajy ny pejy '''$1''' :",
'protect-locked-dblock' => "Tsy afaka solona ny sokajy ny fiarovana satria ny voatohana ny fotom-pandraisana.
Ity ny reglajy ny pejy  '''$1'''",
'protect-locked-access' => "Tsy manana alalana manova ny fiarovana ny pejy ianao.
Ity ny réglage ny pejy '''$1''' :",
'protect-cascadeon' => "Voaaro ity pejy ity ankehitriny noho ny fisiany anatin'{{PLURAL:$1|ity pejy voaaro ity|ireo pejy voaaro ireo}} miaraka amin'ny « fiarovana an-driana » (protection en cascade). Azonareo ovaina ny fiarovan'ity pejy ity fa tsy ho voakasika ny fiarovana an-driana.",
'protect-default' => 'Avela daholo ny mpikambana',
'protect-fallback' => 'Hanome alalana ny mpikambana manana ny zo "$1"',
'protect-level-autoconfirmed' => 'Hanome alalana ny mpikambana voamarina',
'protect-level-sysop' => 'Hanome alalana ny mpandrindra ihany',
'protect-summary-cascade' => 'Fiarovana an-driana',
'protect-expiring' => "Miala amin'ny $1",
'protect-expiring-local' => 'mitsahatra ny $1',
'protect-expiry-indefinite' => 'tsiefa',
'protect-cascade' => "Miaro ny pejy ao anatin'ity pejy ity (cascading protection)",
'protect-cantedit' => "Tsy afaka manolo ny sokaji-piarovan'ity pejy ity ianao satria tsy manana ny sata ilaina",
'protect-othertime' => 'Daty hafa :',
'protect-othertime-op' => 'daty hafa',
'protect-existing-expiry' => "Datin'ny fanalana ilay sazy : $2 amin'ny $3",
'protect-otherreason' => 'Antony hafa miampy :',
'protect-otherreason-op' => 'Antony hafa',
'protect-dropdown' => "*Anton'ny fiarovana
** Misy be mpanimba
** Misy be mpametraka spam
** Misy adim-panontana
** Misy olona maro no mandalo eo",
'protect-edit-reasonlist' => 'Hanova ny antony famafana',
'protect-expiry-options' => '1 ora:1 hour,1 andro:1 day,1 herinandro:1 week,tapa-bolana:2 weeks,1 volana:1 month,3 volana:3 months,6 volana:6 months,1 taona:1 year,mandrakizay:infinite',
'restriction-type' => 'Sata ilaina :',
'restriction-level' => 'Sokajy ny fanerena :',
'minimum-size' => 'Hnageza fara-fahakeliny',
'maximum-size' => 'Habe avo indrindra:',
'pagesize' => '(oktety)',

# Restrictions (nouns)
'restriction-edit' => 'Hanova',
'restriction-move' => 'Hamindra',
'restriction-create' => 'Mamorona',
'restriction-upload' => 'Mampiditra',

# Restriction levels
'restriction-level-sysop' => 'voaaro manontolo',
'restriction-level-autoconfirmed' => 'fiarovana an-tàpany',
'restriction-level-all' => 'ambaratonga rehetra',

# Undelete
'undelete' => 'Jereo ny pejy voafafa',
'undeletepage' => 'Hijery sy hamerina ny pejy efa voafafa',
'undeletepagetitle' => "'''Ahitana ny santiôna voafafan'i [[:$1|$1]] ity lisitra manaraka.'''",
'viewdeletedpage' => 'Hijery ny pejy efa nofafana',
'undeletepagetext' => "Ireto pejy ireto dia efa voafafa nefa mbola voatahiry ao amin'ny tahiry ihany,
ary mbola afaka averina, mandra-pifafan'ny tahiry. Mety ho voafafa matetitetika
ihany ny tahiry {{PLURAL:$1}}.",
'undelete-fieldset-title' => 'Hamerina ny santiôna',
'undeleterevisions' => "{{PLURAL:$1|fanovana|fanovana}} $1 voatahiry any amin'ny arsiva",
'undeletehistory' => "
Raha averinao ity pejy ity dia hiverina hiaraka aminy koa ny tantaran'ny
fanovana rehetra natao taminy. Raha efa misy pejy mitondra io anarana io
noforonina taorian'ny namafana azy, dia hitambatra amin'ny tantaran'io
pejy vaovao io ny tantaran'ity pejy voafafa ity, fa tsy ho voafafa akory.",
'undeletehistorynoadmin' => "Efa voafafa io lahatsoratra io. Ny antony namafana azy dia io miseho ambangovangony eo ambany eo io, miaraka amin'ny fampahalalana antsipirihany momba ny mpikambana nikitika io pejy io talohan'ny namafana azy. Ny votoatin'ny pejy izay efa nofafana ireo dia ny mpitantana ihany no afaka mahita azy ankehitriny.",
'undelete-revision' => "Santiôna voafafa an'i $1 (santiôna tamin'ny $4 tamin'ny $5) nataon'i $3 :",
'undeleterevision-missing' => "Santiôna diso na tsy misy.
Mety rohy tsy izy no anananao, na mety voafafa na naverina tamin'ny tahiry ilay santiôna.",
'undelete-nodiff' => 'Tsy nahitana santiôna nialoha.',
'undeletebtn' => 'Avereno!',
'undeletelink' => 'Topi-maso/averina',
'undeleteviewlink' => 'hijery',
'undeletereset' => 'Hamerina',
'undeleteinvert' => 'Hampifamaidika ny safidy',
'undeletecomment' => 'Antony :',
'undeletedrevisions' => 'voaverina ny {{PLURAL:$1|fanovana|fanovana}} $1',
'undeletedfiles' => 'rakitra voaverina $1 {{PLURAL:$1}}',
'cannotundelete' => 'Tsy nandeha soa aman-tsara ilay famerenana ;
efa nisy mpikambana iray hafa angamba no namerina ilay pejy.',
'undeletedpage' => "'''Voaverina ny pejy $1.'''

Vakio ny [[Special:Log/delete|laogim-pamafana]] ho an'ny lisitry ny famafana sy ny famerenana pejy.",
'undelete-header' => 'Jereo ny [[Special:Log/delete|laogim-pamafana]] rehefa hanalisitra ny pejy vao voafafa.',
'undelete-search-title' => 'Hitady pejy voafafa',
'undelete-search-box' => 'Hitady pejy voafafa',
'undelete-search-prefix' => "Asehoy ny pejy manomboka amin'ny :",
'undelete-search-submit' => 'Fikarohana',
'undelete-no-results' => "Tsy nahitana pejy mitovy tanatin'ny tahirin'ny fafa.",
'undelete-filename-mismatch' => "Tsy afaka averina ny santiônan'ilay rakitra tamin'ny $1 : tsy mifanaraka ny anaran-drakitra.",
'undelete-bad-store-key' => "Tsy mety averina ny santiônan'ilay rakitra tamin'ny $1 : mbola tsy tao ilay rakitra talohan'ny famafana.",
'undelete-cleanup-error' => 'Tsy fetezana teo am-pamafana ilay rakitra an-tahiry tsy miasa « $1 ».',
'undelete-missing-filearchive' => "Tsy afaka atao ny mamerina ilay rakitra tahiry miaraka amin'ny ID $1 satria tsy ao amin'ny banky angona izy io.
Mety efa naverina angamba izy io.",
'undelete-error' => 'Pejin-kadisoam-panafoanana',
'undelete-error-short' => 'Tsi-fetezana teo am-pamerenana ilay rakitra : $1',
'undelete-error-long' => 'Nisy tsi-fetezana nitranga teo am-pamerenana ilay rakitra :

$1',
'undelete-show-file-confirm' => "Tapa-kevitra ny hamafa ny santiôna voafafan'ny rakitra <nowiki>$1</nowiki> tamin'ny $2 tamin'ny $3 ve ianao ?",
'undelete-show-file-submit' => 'Eny',

# Namespace form on various pages
'namespace' => 'Anaran-tsehatra :',
'invert' => 'Ampifamadiho ny safidy',
'namespace_association' => 'Anaran-tsehatra nampiarahana',
'tooltip-namespace_association' => 'Mariho ity boaty ity mba hampiditra ny pejin-dresaky ny anaran-tsehatra voafidy',
'blanknamespace' => '(fotony)',

# Contributions
'contributions' => "Fandraisan'anjaran'ny mpikambana{{GENDER:$1}}",
'contributions-title' => "Fandraisan'anjaran'i $1",
'mycontris' => "Fandraisan'anjara",
'contribsub2' => "Ho an'ny $1 ($2)",
'nocontribs' => "Tsy misy fanovana mifanaraka amin'ireo critères ireo.",
'uctop' => '(ankehitriny)',
'month' => "Tamin'ny volana (sy teo aloha) :",
'year' => "Tamin'ny taona (sy teo aloha) :",

'sp-contributions-newbies' => "Haneho ny fandraisan'anjaran'ireo mpikambana vaovao ihany",
'sp-contributions-newbies-sub' => "Ao amin'ny kaonty vaovao",
'sp-contributions-newbies-title' => "Fandraisan'anjara ao amin'ny kaonty vaovao",
'sp-contributions-blocklog' => 'Laogim-panakanana',
'sp-contributions-deleted' => "fandraisan'anjara voafafa",
'sp-contributions-uploads' => 'fampidiram-pejy',
'sp-contributions-logs' => 'laogy',
'sp-contributions-talk' => 'dinika',
'sp-contributions-userrights' => 'fitantanana ny satam-pikambana',
'sp-contributions-blocked-notice' => "Voasakana ity mpikambana ity amin'izao fotoana izao.
Aseho eo ambany ny laogim-panakanana mba hampahalala anao :",
'sp-contributions-blocked-notice-anon' => "Voasakana ity adiresy IP ity amin'izao fotoana izao.
Aseho eo ambany ny iditra farany ao amin'ny laogim-panakanana  mba hampahalala :",
'sp-contributions-search' => "Hikaroka fandraisan'anjara",
'sp-contributions-username' => 'Adiresy IP na anaram-pikambana :',
'sp-contributions-toponly' => 'Fanovana izay farany eo ihany no aseho',
'sp-contributions-submit' => 'Hikaroka',

# What links here
'whatlinkshere' => 'Pejy mirohy eto',
'whatlinkshere-title' => "Pejy mirohy any amin'i « $1 »",
'whatlinkshere-page' => 'Pejy :',
'linkshere' => "Ireo pejy ireo dia manana rohy mankany amin'i '''[[:$1]]'''",
'nolinkshere' => "Tsy nahitana pejy mirohy any amin'i '''[[:$1]]'''.",
'nolinkshere-ns' => "Tsy nahitana pejy mirohy any amin'i [[:$1]] ao amin'ny anaran-tsehatra nofidiana.",
'isredirect' => 'pejy fihodinana',
'istemplate' => 'tsofo-pejy',
'isimage' => "rohy mankany amin'ilay rakitra",
'whatlinkshere-prev' => '$1 taloha{{PLURAL:$1||}}',
'whatlinkshere-next' => '$1 manaraka{{PLURAL:$1||}}',
'whatlinkshere-links' => '← rohy',
'whatlinkshere-hideredirs' => '$1 ny fihodinana',
'whatlinkshere-hidetrans' => '$1 ny tsofo-pejy',
'whatlinkshere-hidelinks' => '$1 ny rohy',
'whatlinkshere-hideimages' => '$1 ny rakitra mirohy',
'whatlinkshere-filters' => 'sivana',

# Block/unblock
'autoblockid' => 'Fanakanana mandeha ho azy #$1',
'block' => 'Hanakana ilay mpikambana',
'unblock' => "Hanala ny sakan'ilay mpikambana",
'blockip' => 'Sakano ny mpikambana',
'blockip-title' => 'Hanakana ilay mpikambana',
'blockip-legend' => 'Sakano ny mpikambana',
'blockiptext' => "Ampiasao ity formulaire ity hisakanana ny fahazoan-dàlana hanoratra
ananan'ny adiresy IP iray na solonanarana iray.
Tokony ho antony fisorohana ny fisomparana ihany, ary mifanaraka amin'ny [[{{MediaWiki:Policy-url}}|fepetra]]
ihany no hanaovana ny fisakanana.
Fenoy etsy ambany ny antony manokana (ohatra, mitanisà pejy nosomparana).",
'ipadressorusername' => 'Adiresy IP na solonanarana',
'ipbexpiry' => 'Fahataperana',
'ipbreason' => 'Antony :',
'ipbreasonotherlist' => 'Antony hafa',
'ipb-hardblock' => 'Hanakana ny mpikambana nisoratra anarana mampiasa ity adiresy IP ity',
'ipbcreateaccount' => 'Hanakana ny fanokafana kaonty',
'ipbemailban' => 'Hanakana ny fandefasana imailaka',
'ipbenableautoblock' => "Manakana ny IP farany ampiasain'ity mpikambana ity, ary ny IP-ny taloha mety ho andramnay",
'ipbsubmit' => 'Sakano',
'ipbother' => 'Hafa',
'ipboptions' => '2 ora:2 hours,1 andro:1 day,3 andro:3 days,1 herinandro:1 week,2 herinandro:2 weeks,1 volana:1 month,3 volana:3 months,6 volana:6 months,1 taona:1 year,mandrakizay:infinite',
'ipbotheroption' => 'hafa',
'ipbotherreason' => 'Antony hafa na fanampiny :',
'ipbhidename' => "Hanitrika ny anaram-pikambana anatin'ny fanovana sy anaty lisitra",
'ipbwatchuser' => "Hanaraka ny pejim-pikambana sy pejin-dresak'ity mpikambana ity",
'ipb-disableusertalk' => 'Manakana ilay mpikambana hanova ny pejin-dresany mandritry ny sakana',
'ipb-change-block' => "Hanakana io mpikambana io amin'ireto parametatra ireto.",
'ipb-confirm' => 'Sakanana marina',
'badipaddress' => 'Tsy mety ny adiresy IP (invalid)',
'blockipsuccesssub' => 'Vita soa aman-tsara ny sakana',
'blockipsuccesstext' => 'Voasakana i [[Special:Contributions/$1|$1]].<br />
Jereo ny [[Special:BlockList|lisitry ny voasakana]] raha hanala ny sakana efa misy.',
'ipb-blockingself' => 'Hanakana ny kaontinao ianao ! Tena hanao izany ve ?',
'ipb-confirmhideuser' => "Eo ampanakanana mpikambana miaraka amin'ny \"fanakonana mpikambana\" ampiasaina. Izany dia mamafa ny anaran'ilay mpikambana amin'ny listra ary amin'ny iditra laogy. Tena hanao izany ve ianao?",
'ipb-edit-dropdown' => 'Hanova ny antony fanakanana tsipalotra',
'ipb-unblock-addr' => "Hanala ny sakan' i $1",
'ipb-unblock' => "Hanala ny sakan'ny mpikambana na adiresy IP",
'ipb-blocklist' => 'Hijery ny sakana efa misy',
'ipb-blocklist-contribs' => "Fandraisan'anjaran'i $1",
'unblockip' => "Esory ny sakana amin'io mpikambana io",
'unblockiptext' => "
Ampiasao ity fisy eto ambany ity hanalana ny sakana
mihatra amin'ny adiresy IP na solonanarana iray.",
'ipusubmit' => 'Esory ny sakana',
'unblocked' => "voaala ny sakan'i [[User:$1|$1]]",
'unblocked-range' => "Afaka ny sakan'i $1.",
'unblocked-id' => "Niala ny sakan'i $1",
'blocklist' => 'Mpikambana voasakana',
'ipblocklist' => 'Lisitry ny adiresy IP sy mpikambana voasakana',
'ipblocklist-legend' => 'Hitady mpikambana voasakana',
'blocklist-userblocks' => 'Hanakana ny fanakanana kaonty',
'blocklist-tempblocks' => 'Hanakana ny sakana miserana',
'blocklist-addressblocks' => 'Hanakana ny fanakanana adiresy IP tokana',
'blocklist-timestamp' => 'Daty sy ora',
'blocklist-target' => 'Tanjona',
'blocklist-expiry' => 'Daty fitsaharana :',
'blocklist-by' => 'Mpandrindra nanakana',
'blocklist-params' => 'Parametatry ny sakana',
'blocklist-reason' => 'Antony',
'ipblocklist-submit' => 'Fikarohana',
'ipblocklist-localblock' => 'Fanakanana eo an-toerana',
'ipblocklist-otherblocks' => '{{PLURAL:$1}}sakana hafa',
'infiniteblock' => 'mandrakizay',
'expiringblock' => "tapitra amin'ny $1 amin'ny $2",
'anononlyblock' => 'mpikambana tsy nisoratra anarana ihany',
'noautoblockblock' => 'fanakanana mande ho azy nesorina',
'createaccountblock' => 'tsy mahazo manokatra kaonty',
'emailblock' => 'imailaka voasakana',
'blocklist-nousertalk' => 'Tsy afaka manova ny pejin-dresany',
'ipblocklist-empty' => 'Ny lisitra ny IP voasakana dia tsy misy votoatiny ankehitriny.',
'ipblocklist-no-results' => 'Ilay adiresy IP na ilay mpikambana dia mbola tsy voasakana.',
'blocklink' => 'sakano',
'unblocklink' => 'esory ny sakana',
'change-blocklink' => 'ovay ny fanakanana',
'contribslink' => "fandraisan'anjara",
'emaillink' => 'Handefa imailaka',
'autoblocker' => "Voasakana satria ny adiresy IP-nao dia vao avy nampiasain'i \"[[User:\$1|\$1]]\". Ny anton'ny fanakanana dia: \"'''\$2'''\"",
'blocklogpage' => "Tantaran'ny sakana",
'blocklog-showlog' => 'Efa voasakana ity mpikambana ity taloha.
Eo ambany ny laogim-panakanana.',
'blocklog-showsuppresslog' => 'Efa voasakana sy voasitrika ity mpikambana ity.
Eo ambany ny laogim-pamafana.',
'blocklogentry' => 'voasakana i "[[$1]]" mandritra ny $2 ; antony : $3',
'reblock-logentry' => "nanova ny parametatry ny sakan'i [[$1]], ary tapitra amin'ny $2. Ny antony dia ''$3''",
'blocklogtext' => "Eto no ahitana ny tantaran'ny hetsika momba ny fisakanana sy ny famoanana ny fisakanana mpandray anjara.
Tsy aseho eto ny adiresy IP voasakana ho azy.
Jereo ao amin'ny [[Special:BlockList|lisitry ny sakana]] hahitana ny lisitry ny sakana mihatra amin'izao fotoana izao",
'unblocklogentry' => "voaaisotra ny sakana an'i $1",
'block-log-flags-anononly' => 'mpikambana tsy nisoratra anarana ihany',
'block-log-flags-nocreate' => 'tsy mahazo manokatra kaonty',
'block-log-flags-noautoblock' => 'fanakanana ny IP nesorina',
'block-log-flags-noemail' => 'voarara ny fandefasana imailaka',
'block-log-flags-nousertalk' => 'tsy azo ovainy ny pejin-dresany',
'block-log-flags-angry-autoblock' => 'fanakanan-tena notsaraina efa mandeha',
'block-log-flags-hiddenname' => 'anaram-pikambana nasitrika',
'range_block_disabled' => 'Tsy mandeha ny zo-mpandrindra mamorona fanakanana vondrona IP.',
'ipb_expiry_invalid' => "Tsy mety ilay fotoana hahataperan'ny sakana.",
'ipb_expiry_temp' => 'tsy maintsy lalandava ny fanakanana anaram-pikambana nasitrika.',
'ipb_hide_invalid' => 'Tsy afaka fafana io kaonty io ; hoatra ny manana fanovana maro loatra izy.',
'ipb_already_blocked' => 'Efa voasakana « $1 »',
'ipb-needreblock' => 'Efa voasakana i $1. Tianao ovaina ve ny parametatra ?',
'ipb-otherblocks-header' => '{{PLURAL:$1}}sakana hafa',
'unblock-hideuser' => "Tsy azonao atao ny manala ny sakan'ity mpikambana ity, satria nafenina ny anaram-pikambany.",
'ipb_cant_unblock' => 'Tsy fetezana : Marik ny fanakanana $1 tsy hita.
Mety efa natao angamba ny fanalana sakana.',
'ipb_blocked_as_range' => "Hadisoana : tsy nosakanana manokana ny adiresy IP $1 ka noho izany tsy afaka alàna ny sakany.
Ao amin'ny laharana $2 izay afaka alàna sakana anefa izy io.",
'ip_range_invalid' => 'Tsy mety io IP io.',
'ip_range_toolarge' => 'Ny fanidiana laharana IP ngeza nohonny /$1 dia tsy azo atao.',
'proxyblocker' => 'Mpisakana proxy',
'proxyblockreason' => "Voasakana ny adiresy IP-nao satria adiresy proxy malalaka izy io. Azafady mba lazao amin'ny mpanome internet anao io olana io.",
'sorbsreason' => "Voasokokajin'ny DNSBL ho ao anatin'ny proxy midanadana ny adiresy IP-nao.",
'sorbs_create_account_reason' => "Voasokajy ho isan'ny proxy midanadana ao amin'ny DNSBL ny adiresy IP-nao. Ireo IP ireo dia ahiana ho fitaovana azon'ny mpandefa spam ampiasaina. Tsy afaka manokatra kaonty ianao.",
'cant-block-while-blocked' => 'Tsy azo sakananao ny mpikambana hafa raha mbola voasakana ianao.',
'cant-see-hidden-user' => "Ny mpikambana andramanao sakanana dia efa nosakanana ary nasitrika.
Noho ianao tsy manana ny zon'ny mpanitrika mpikambana (''hideuser''), tsy azonao jerena na ovaina ny sakan'ity mpikambana ity.",
'ipbblocked' => "Tsy afaka manala ny sakan'ny mpikambana hafa ianao, satria voasakana koa ianao",
'ipbnounblockself' => 'Tsy afaka manala ny sakanao ianao',

# Developer tools
'lockdb' => 'Fanidiana ny banky angona',
'unlockdb' => "Fanala hidin'ny banky angona",
'lockdbtext' => "
Rehefa mihidy ny banky angona dia mihantona koa ny
asa rehetra azon'ny mpikambana atao toy ny manova pejy, manova ny mombamomba azy,
manova ny lisitry ny pejy arahiny maso sy ny zavatra hafa mila fifandraisana amin'ny
banky angona.
Azafady antero fa tena ilainao izany, ary hoesorinao io hidy io rehefa vita izay ataonao.",
'unlockdbtext' => "
Ny fanalana ny hidin'ny banky angona dia mameriny ny fahafahan'ny tsirairay manova
sy mamorona pejy, manova ny mombamomba azy na ny lisitry ny pejy arahiny maso, sy izay
asa hafa mila fifandraisana amin'ny banky angona.
Azafady mba antero fa izay tokoa no tena irinao.",
'lockconfirm' => 'Eny tompoko, tena tiako hidiana aloha ny banky angona',
'unlockconfirm' => "Eny, tena tiako hovohaina amin'izay ny banky angona.",
'lockbtn' => 'Hidio ny banky angona',
'unlockbtn' => 'Vohay ny banky angona',
'locknoconfirm' => 'Tsy nomarihinao ilay faritra natokana hananterana ny safidinao.',
'lockdbsuccesssub' => 'Voahidy ny banky angona',
'unlockdbsuccesssub' => "Voaala ny hidin'ny banky angona",
'lockdbsuccesstext' => 'Voahidy ny banky angona
<br />Aza adino ny manala hidy rehefa vita izay ataonao.',
'unlockdbsuccesstext' => "Voaala soa aman-tsara ny hidin'ny banky angona.",
'lockfilenotwritable' => "Tsy azo soratana ny rakitra fanidiana ny banky angona.
Mba hahafahany manidy na mamoha ny banky angona, mila azo soratan'ny lohamilin-tranonkala izy.",
'databasenotlocked' => 'Tsy voaidy ny banky angona.',
'lockedbyandtime' => "(nataon'i $1 ny $2 tamin'ny $3)",

# Move page
'move-page' => "Hanova anarana an'i $1",
'move-page-legend' => 'Afindrao toerana ny pejy',
'movepagetext' => "Ampiasao ilay fôrmiolera eo ambany eo mba hamindra azy toerana, voakisaka any amin'ny anarany ankehitriny ny tantarany. Lasa pejy fihodinana ilay pejy taloha, (manondro makany amin'ny anarany ankehitriny ilay pejy).

Afaka manavao ho azy ny fihodinana mankany amin'ny lohateny taloha ianao. Raha tsy fidinao ny manao izany, marino tsara ny fisian'ireo [[Special:DoubleRedirects|fihodinana roa]] na [[Special:BrokenRedirects|fihodinana tapaka]]. Ianao no manana andrikitra amin'ny fanamarinana ny tsi-fitapahan'ireo rohy.

Jereo koa fa '''tsy afaka''' akisaka ilay pejy ra mitovy anarana amin'ny pejy efa misy ny anarana ny anarana vaovaon'ilay pejy tianao akisaka, fa mety atao ihany io asa io ra tsy misy nininona ilay pejy. Afaka manolo anarana pejy efa manondro ny fihisiny taloha ianao ra diso ianao, fa tsy afaka ataonao no manitsaka pejy efa misy.

'''TANDREMO'''

Mety ho fiovana lehibe ary tsy ampoizina ny fanaovana izany ho an'ny pejy voatsidika mateetika ; fantaro tsara ny fiantraika alohan'ny manao izany.",
'movepagetalktext' => "Voasikaka koa ny pejin-dresak'ity pejy ity '''ra''' :

* Efa misy pejin-dresaka efa misy votoatiny amin'ilay anarana vaovao, na
* Ra ny ''décocher''-nao ilay kazy eo ambany.

Tokony ataonao rery io asa io (fusion)",
'movearticle' => 'Afindrao toerana ny pejy',
'movenologin' => 'Tsy mbola tafiditra ianao',
'movenologintext' => 'Ny mpikambana nisoratra anarana sy [[Special:UserLogin|tafiditra]] ihany no afaka mamindra toerana takelaka.',
'movenotallowed' => 'Tsy azo ovainao anarana ny pejy.',
'movenotallowedfile' => 'Tsy mahazo ovainao anarana ny rakitra.',
'cant-move-user-page' => "Tsy azo ovainao anarana ny renipejim-pikambana (any ivelan'ny zana-pejiny).",
'cant-move-to-user-page' => 'Tsy azo ovainao ny manova anarana pejy makany amina pejim-pikambana (afatsy zana-pejy iray).',
'newtitle' => 'Lohateny vaovao',
'move-watch' => 'araho-maso ity pejy ity',
'movepagebtn' => 'Afindrao',
'pagemovedsub' => 'Voafindra ny pejy',
'movepage-moved' => "voafindra tany amin'ny '''$2''' i '''$1'''",
'movepage-moved-redirect' => "Voaforona ny fihodinana manketo any amin'ny anarany taloha.",
'movepage-moved-noredirect' => "Tsy nasiana fihodinana (redirect) avy any amin'ny anarana taloha.",
'articleexists' => 'Efa misy ny lahatsoratra mitondra io anarana io, na
tsy mety ny anarana nosafidianao.
Azafady mba misafidiana anarana hafa.',
'cantmove-titleprotected' => "Tsy azonao afindra any amin'io anarana io ny rakitra satria ny famoronana pejy mitondra io lohateny io dia voaaro.",
'talkexists' => "
'''Tafafindra soa aman-tsara ny pejy, fa ny pejin-dresaka
miaraka aminy no tsy afaka nakisaka satria efa misy pejin-dresaka
mifanaraka amin'ilay anarana vaovao. Azafady mba atambaro izay pejin-dresaka izay.'''",
'movedto' => "voafindra any amin'ny",
'movetalk' => 'Afindrao any koa ny "pejin-dresaka", raha mety.',
'move-subpages' => "Hanova ny anaranan'ny zana-pejy (hatramin'ny pejy miisa $1)",
'move-talk-subpages' => "Hanova ny anaranan'ny zana-pejin'ny pejin-dresaka (hatramin'ny pejy miisa $1).",
'movepage-page-exists' => 'Efa misy ny pejy $1 ary tsy afaka soloina ho azy.',
'movepage-page-moved' => 'Voaova anarana lasa $2 ilay pejy $1.',
'movepage-page-unmoved' => 'Tsy afaka novaina anarana $2 ilay pejy $1.',
'movepage-max-pages' => 'Efa tratra ny isam-pejy farafahabetsany izay azo ovaina anarana (pejy $1){{PLURAL:}}, ka tsy ho voaova anarana ho azy intsony ny pejy hafa.',
'movelogpage' => 'Ny laogim-panisahana',
'movelogpagetext' => 'Lisitry ny pejy nafindra toerana.',
'movesubpage' => 'Zana-pejy{{PLURAL:$1||}} $1',
'movesubpagetext' => 'Ity pejy ity dia manana zanapejy $1 miseho eo ambany. {{PLURAL:$1||}}',
'movenosubpage' => 'Tsy manana zana-pejy ity pejy ity.',
'movereason' => 'Antony :',
'revertmove' => 'averina',
'delete_and_move' => 'Ovay toerana dia fafao',
'delete_and_move_text' => '==Mila fafàna==

Efa misy ny lahatsoratra hoe "[[:$1]]". Irinao ve ny hamafana azy mba hahafahana mamindra toerana ity lahatsoratra ity?',
'delete_and_move_confirm' => 'Eny, fafao io pejy io',
'delete_and_move_reason' => "Pejy voafafa hahafahana manolo ny anaran'i ''[[$1]]''",
'selfmove' => 'Mitovy ny anarana taloha sy anarana vaovao; tsy afaka afindra ny pejy.',
'immobile-source-namespace' => "Tsy afaka ovaina anarana ny pejy ao amin'ny anaran-tsehatra « $1 »",
'immobile-target-namespace' => "Tsy afaka ovainao ny pejy makany amin'ny anaran-sehatra « $1 »",
'immobile-target-namespace-iw' => "Ny rohy interwiki dia tanjona tsy mety ho an'ny fanetsehana pejy.",
'immobile-source-page' => 'Tsy azo ovaina anarana ity pejy ity.',
'immobile-target-page' => "Tsy afaka ovaina anarana makany amin'io lohateny io ilay pejy.",
'imagenocrossnamespace' => 'Tsy mety ovaina anarana makany amina anaran-tsehatra hafa afatsy rakitra ihany ny rakitra.',
'nonfile-cannot-move-to-file' => "Tsy afaka manova anaran'ny pejy tsy rakitra any amin'ny anaran-tsehatry ny rakitra.",
'imagetypemismatch' => "Tsy mifanaraka amin'ny karazany ny fanitaran'ity rakitra ity.",
'imageinvalidfilename' => 'Diso ny anaran-drakitra tanjona',
'fix-double-redirects' => "Hanao update ny fihodinana makany amin'ny lohateny fotony",
'move-leave-redirect' => "Hamela fihodinana makany amin'ny lohateny vaovao",
'move-over-sharedrepo' => "== Efa misy ilay rakitra ==
Efa misy ao amina petra-drakitra zaraina ny rakitra [[:$1]]. Raha ovaina anarana ity rakitra ity, dia tsy ho hita eto intsony ny rakitra eo amin'ny petra-drakitra zaraina.",
'file-exists-sharedrepo' => "Efa ampaisain'ny rakitra iray ao amin'ny petra-drakitra iraisana io anarana io.
Anarana hafa omena.",

# Export
'export' => 'Hamoaka pejy',
'exporttext' => "Afaka manondrana ny lahatsoratra miaraka amin'ny tantaram-panovana ny pejy na vondrom-pejy maromaro ianao.
Aoriana dia mety hafaran'ny wiki iray mandeha amin'ny rindrankajy MediaWiki izany, na dia mbola tsy afaka
atao aza izany amin'izao fotoana izao.

Ny fomba fanondranana pejy dia, manomeza lohateny izay na maromaro eto amin'ny boaty ety ambany eto, lohateny iray isaky ny andalana,
ary safidio na ny votoatiny ankehitriny ihany no ilainao na miaraka amin'ny endriky ny pejy rehetra taloha, sy hoe ny votoatiny ankehitriny
miampy fampahalalana momba ny fanovana farany fotsiny ve sa miaraka amin'ny tantaran'ny fanovana rehetra.

Etsy amin'ny toerana farany dia afaka mampiasa rohy ihany koa ianao, ohatra [[{{#Special:Export}}/{{MediaWiki:Mainpage}}]] ho an'ny [[{{MediaWiki:Mainpage}}]].",
'exportall' => 'Hamoaka ny pejy rehetra',
'exportcuronly' => "Ny votoatiny ankehitriny ihany no haondrana fa tsy miaraka amin'ny tantarany iray manontolo",
'exportnohistory' => "
----
'''Fanamarihana:''' nosakanana aloha ny fanondranana pejy miaraka amin'ny tantarany iray manontolo amin'ny alalan'ity fisy ity noho ny antony performance.",
'export-submit' => 'Hamoaka',
'export-addcattext' => "Hanampy pejy ao amin'ny sokajy :",
'export-addcat' => 'Hanampy',
'export-addnstext' => "Hanampy pejy ao amin'ny anaran-tsehatra :",
'export-addns' => 'Hanampy',
'export-download' => 'Hitahiry azy anaty rakitra',
'export-templates' => 'Ataovy ao ny endrika',
'export-pagelinks' => "Ataovy ao any pejy mmirohy amin'y halalina :",

# Namespace 8 related
'allmessages' => 'Hafatry ny rindrankajy',
'allmessagesname' => 'Anarana',
'allmessagesdefault' => 'Dikan-teny tany am-boalohany',
'allmessagescurrent' => 'Dikan-teny miasa ankehitriny',
'allmessagestext' => "Ity dia lisitry ny hafatra hita ao amin'ny anaran-tsehatra MediaWiki.
Andana vangio ny [//www.mediawiki.org/wiki/Localisation Fandikana an'i Mediawiki] ary [//translatewiki.net/ translatewiki.net] raha tia handray anjara amin'ny fandikana an'i Mediawiki amin'ny ankapobeny.",
'allmessagesnotsupportedDB' => "Tsy mbola mandeha ny '''{{ns:special}}:Allmessages''' satria tsy mandeha koa ny '''\$wgUseDatabaseMessages'''.",
'allmessages-filter-legend' => 'Tantavanina',
'allmessages-filter' => 'Hanasivana araka ny satam-panovana :',
'allmessages-filter-unmodified' => 'Mbola tsy voaova',
'allmessages-filter-all' => 'Rehetra',
'allmessages-filter-modified' => 'Voaova',
'allmessages-prefix' => 'Tantavanina araka ny tovona :',
'allmessages-language' => 'Tenim-pirenena/fiteny :',
'allmessages-filter-submit' => 'Alefa',

# Thumbnails
'thumbnail-more' => 'Angedazina',
'filemissing' => 'Tsy hita ny rakitra',
'thumbnail_error' => 'Tsy fetezana eo am-panamboarana ilay saritapaka : $1',
'thumbnail_error_remote' => "Hafa-kadisoana avy amin'i $1:
$2",
'djvu_page_error' => "Pejy DjVu any ivelan'ny fetra",
'djvu_no_xml' => "Tsy afaka alaina ny XML ho an'ny rakitra DjVu",
'thumbnail-temp-create' => 'Tsy afaka namorona ilay thumbnail miserana',
'thumbnail-dest-create' => "Tsy nahatahiry ilay thumbnail tany amin'ny tanjona",
'thumbnail_invalid_params' => 'Parametatry ny saritapaka tsy mety',
'thumbnail_dest_directory' => 'Tsy mety amboarina ilay petra-drakitra tanjona',
'thumbnail_image-type' => 'Karazan-drakitra tsy zaka',
'thumbnail_image-missing' => "Rakitra ohatran'ny tsy ao : $1",

# Special:Import
'import' => 'Hampidi-pejy',
'importinterwiki' => 'fampidirana interwiki',
'import-interwiki-text' => "Safidio wiki loharano iray ary ny lohatenin'ilay pejy ho ampidirina eto.
Ho voatazona ao amin'ny tantara ny datin'ny santiôna sy ny anaran'ny mpandray anjara.
Ho voasoratra ao amin'ny [[Special:Log/import|laogim-pampidirana]] ny tao rehetra mikasika ny fampidirana pejy interwiki",
'import-interwiki-source' => 'Wiki sy pejy fango :',
'import-interwiki-history' => "Handika ny santiônan'ny tantaran'ity pejy ity",
'import-interwiki-templates' => 'Ataovy ao ny endrika rehetra',
'import-interwiki-submit' => 'Hampiditra',
'import-interwiki-namespace' => 'Anaran-tsehatra tanjona :',
'import-interwiki-rootpage' => 'Foto-pejy tanjona (azo tsy fenoina):',
'import-upload-filename' => 'Anaran-drakitra :',
'import-comment' => 'Resaka :',
'importstart' => 'Am-pampidirana ny pejy…',
'import-revision-count' => '$1 santiôna{{PLURAL:$1||}}',
'importnopages' => 'Tsy misy pejy ho ampidirana.',
'importfailed' => "Tsy fetezan' ilay fampidirana : <nowiki>$1</nowiki>",
'importunknownsource' => "Karazana tsy fantatra an'ilay fango ho ampidirina",
'importcantopen' => 'Tsy mety sokafana ilay rakitra ho ampidirina',
'importbadinterwiki' => 'Rohy interwiki tsy izy',
'importnotext' => 'Tsy misy votoatiny',
'importsuccess' => 'Tafiditra soa aman-tsara !',
'importhistoryconflict' => "Misy ady hita ao amin'y tantaran-tsantiôna (nety nalefa io pejy io taloha).",
'importnosources' => 'Mbola tsy voatono ny loharano interwiki fampidiram-pejy ary mbola tsy mandeha ny fandefasana tantaram-pejy.',
'importnofile' => 'Tsy nisy rakitra fandefasana nalefa.',
'importuploaderrorsize' => "Tsy tafiditra soa aman-tsara ilay rakitra.
Ambony nohon'ny lanja ahazoan-dalana ny lanjany.",
'importuploaderrorpartial' => 'Tsy tafiditra tato ilay rakitra.
Singam-botoatiny fotsiny no nalefa.',
'importuploaderrortemp' => 'Ny fandefasana ilay rakitra dia tsy nety.
Tsy hita ny rakitra miserana.',
'import-parse-failure' => 'Tsy fetezana teo am-pandinihana ny XML ho ampidirina',
'import-noarticle' => 'Tsy misy pejy ho ampidirina !',
'import-nonewrevisions' => 'Efa nampidirina taloha daholo ny santiôna rehetra.',
'xml-error-string' => "$1 eo amin'ny andininy faha $2, tsanganana faha $3 (oktety $4) : $5",
'import-upload' => 'Fandrefasana data XML',
'import-token-mismatch' => 'Very ny fampahalalàna momba ny kaonty.
Avereno fanindroany.',
'import-invalid-interwiki' => "Tsy afaka mampiditra avy any amin'ilay wiki nofidiana.",
'import-error-edit' => 'Tsy nafarana ny pejy "$1" satria tsy afaka manova azy ianao.',
'import-error-create' => 'Tsy nafarana ny pejy "$1" satria tsy afaka mamorona azy ianao.',
'import-error-interwiki' => 'Tsy nafarana ny pejy "$1" satria atokana ho an\'ny rohy interwiki ny anarany.',
'import-error-special' => 'Tsy nafarana ny pejy "$1" satria amy valan\'anarana tsy mandray pejy ilay izy.',
'import-error-invalid' => 'Tsy nafarana ny pejy "$1" satria tsy ekena ny anarany.',
'import-rootpage-invalid' => 'Lohateny tsy azo raisina ny foto-pejy nomenao:',

# Import log
'importlogpage' => "laogin'ny fampidirana",
'importlogpagetext' => "Fampidirana ara-pandraharahana ny pejy miaraka amin'ny tantaram-panvany avy any amin'ny wiki hafa.",
'import-logentry-upload' => "nampiditra [[$1]] tamin'ny fampidiran-drakitra",
'import-logentry-interwiki' => "nampiditra $1 tamin'ny transwiki",

# JavaScriptTest
'javascripttest' => 'Fanandramana JavaScript',
'javascripttest-title' => 'Mandefa fanandramana $1',

# Tooltip help for the actions
'tooltip-pt-userpage' => 'Ny pejinao',
'tooltip-pt-anonuserpage' => "Ny pejim-bikamban'ny IP andraisanao anjara",
'tooltip-pt-mytalk' => 'Pejin-dresakao',
'tooltip-pt-anontalk' => "Ny pejin-dresaka ho an'ny fandraisan' anjara tamin'ny alànan'ity IP ity",
'tooltip-pt-preferences' => 'Ny safidinao',
'tooltip-pt-watchlist' => 'Ny lisitra ny pejy arahanao-maso',
'tooltip-pt-mycontris' => "Lisitra ny fandraisan'anjaranao",
'tooltip-pt-login' => 'Tsara aminao no miditra na misoratra anarana, fa tsy voatery ianao.',
'tooltip-pt-anonlogin' => 'Tsara aminao no miditra na misoratra anarana, fa tsy voatery ianao.',
'tooltip-pt-logout' => 'Hidio',
'tooltip-ca-talk' => 'resaka momba io takelaka io',
'tooltip-ca-edit' => "Azonao atao no manova n'ity pejy ity.
Ampesao ny topi-maso aloha no mihatiry.",
'tooltip-ca-addsection' => 'hanomboka fizaràna vaovao',
'tooltip-ca-viewsource' => 'Voaaro ilay pejy. Fa afaka itanao ny voatotiny.',
'tooltip-ca-history' => "Ny revision natao tamin'ity pejy ity",
'tooltip-ca-protect' => 'Arovy ity pejy ity',
'tooltip-ca-unprotect' => "Hanala ny fiarovan'ity pejy ity",
'tooltip-ca-delete' => 'Fafao ity pejy ity',
'tooltip-ca-undelete' => "Hamerina ny fanovana natao tamin'ity pejy ity talohan'ny famafany",
'tooltip-ca-move' => 'Ovay anarana ilay pejy',
'tooltip-ca-watch' => "Ampio amin'ny lisitra ny pejy arahinao-maso ity pejy ity",
'tooltip-ca-unwatch' => "Esory amin'ny pejy arahinao ity pejy ity",
'tooltip-search' => "Karoka amin'ny {{SITENAME}}",
'tooltip-search-go' => "Mandana any amina pejy mitondra n'io anarana io ra misy.",
'tooltip-search-fulltext' => "Tadiavo ny pejy misy an'io lahatsoratra io.",
'tooltip-p-logo' => 'Renpejy',
'tooltip-n-mainpage' => 'Jereo ny renipejy',
'tooltip-n-mainpage-description' => 'hitsidika ny renipejy',
'tooltip-n-portal' => 'Ny mombamomba ny tetikasa',
'tooltip-n-currentevents' => "Hidady ny rohy momban'ny vaovao ankehitriny",
'tooltip-n-recentchanges' => "Lisitra ny fanovàna farany efa vita eto amin'ity wiki ity",
'tooltip-n-randompage' => 'Hjery pejy aki-sendra',
'tooltip-n-help' => 'fanoroana',
'tooltip-t-whatlinkshere' => 'Lisitra ny pejy wiki mirohy eto',
'tooltip-t-recentchangeslinked' => "Lisitry ny fanovàna faran'ny pejy manana rohy amin'ity zavatra ity",
'tooltip-feed-rss' => "Topaka RSS ho an'ity pejy ity",
'tooltip-feed-atom' => "Topaka atom ho an'ity pejy ity",
'tooltip-t-contributions' => "Hijery ny lisitry ny fandraisan'anjara n'io mpikambana io",
'tooltip-t-emailuser' => "Handefa imailaka any amin'io mpikambana io",
'tooltip-t-upload' => 'Handefa sary na rakitra',
'tooltip-t-specialpages' => 'Listry ny pejy manokana rehetra',
'tooltip-t-print' => 'Takelaka azo atonta printy',
'tooltip-t-permalink' => "Rohy n'ity version ity",
'tooltip-ca-nstab-main' => 'Jereo ny takelaka',
'tooltip-ca-nstab-user' => "Jereo ny pejin'ny mpikambana",
'tooltip-ca-nstab-media' => "Hijery ny pejin'ny Media",
'tooltip-ca-nstab-special' => 'Pejy manokana ity pejy ity, ny rindrankajy wiki no mitantana ity pejy ity',
'tooltip-ca-nstab-project' => "Jereo ny pejy momban'ny tetikasa",
'tooltip-ca-nstab-image' => "jereo ny pejy an'io rakitra io",
'tooltip-ca-nstab-mediawiki' => "Hijery ny hafatra ampiasain'ny rindrankajy",
'tooltip-ca-nstab-template' => 'Jereo ny endrika  (môdely)',
'tooltip-ca-nstab-help' => 'Hijery ny pejy fanoroana',
'tooltip-ca-nstab-category' => "Hijery ny pejy momban'ilay sokajy",
'tooltip-minoredit' => 'Mariho ho fanovana madinika ihany',
'tooltip-save' => 'Tehirizo ny fanovana',
'tooltip-preview' => 'Topazy maso ny fanovana nataonao, iangaviana ianao mba hijery tsipalotra mialoha ny fitahirizana ny fanovana!',
'tooltip-diff' => "Asehoy izay novainao tamin'ny lahatsoratra.",
'tooltip-compareselectedversions' => "Jereo ny fahasamihafana amin'ireo votoatin'ny pejy anankiroa ireo.",
'tooltip-watch' => "Ampidiro amin'ny lisitry ny pejy arahinao maso ity pejy ity",
'tooltip-watchlistedit-normal-submit' => 'Hanala ny lohateny',
'tooltip-watchlistedit-raw-submit' => 'Hanavao ny pejy arahana',
'tooltip-recreate' => 'Hamorona ilay pejy fanindroany raha efa voafafa izy',
'tooltip-upload' => 'Hanomboka ny fampidirana',
'tooltip-rollback' => "Manala ny fanovan'ny mpikambana farany nanova azy ilay asa « foano » (Rollback) .",
'tooltip-undo' => "Manala n'io fanovàna io ilay rohy « esory ».
Mamerina ny version taloha io asa io ary afaka manometraka ny antony anatin'ny ambangovangony.",
'tooltip-preferences-save' => 'Tehirizina ny safidy',
'tooltip-summary' => 'Atsofohy eo ambangovangony fohifohy',

# Stylesheets
'monobook.css' => "/* Ovay ity rakitra ity raha hampiasa takilan'angaly (stylesheet) anao manokana amin'ny wiki iray manontolo */",

# Metadata
'notacceptable' => "Tsy afaka manome données amin'ny format zakan'ny navigateur-nao ny serveur wiki.",

# Attribution
'anonymous' => "Mpikambana {{PLURAL:$1}} tsy mitonona anarana eto amin'ny {{SITENAME}}",
'siteuser' => '{{SITENAME}} mpikambana $1',
'anonuser' => "ny mpikambana tsy nisoratra anarana $1 an'i {{SITENAME}}",
'lastmodifiedatby' => "Novain'i $3 tamin'ny $1 tamin'ny $2 ity pejy ity.",
'othercontribs' => "Mifototra amin'ny asan'i $1.",
'others' => 'hafa',
'siteusers' => '{{SITENAME}} mpikambana $1 miisa $2{{PLURAL:}}',
'anonusers' => "Ny mpikambana tsy nisoratra anarana $1 ao amin'i {{SITENAME}}",

# Spam protection
'spamprotectiontitle' => "Sivana mpiaro amin'ny spam",
'spamprotectiontext' => "Voasakan'ny sivana mpiaro amin'ny spam ny pejy saika hotahirizinao. Mety ho anton'izany ny fisian'ny rohy mankany amin'ny sehatra ivelan'ity wiki ity.",
'spamprotectionmatch' => "Izao teny izao: $1 ; no nanaitra ny sivana mpiaro amin'ny spam",
'spambot_username' => "Fanadiovana ny spam amin'i MediaWiki.",
'spam_reverting' => "Famerenana an'ilay santiôna farany tsy misy ny rohy mankany amin'ny $1",
'spam_blanking' => "Voafotsy ny santiôna misy ny rohy mankany amin'ny $1",

# Info page
'pageinfo-title' => 'Fampahalalana ho an\'i "$1"',
'pageinfo-header-basic' => 'Fampahalalana fototra',
'pageinfo-header-edits' => "Tantaran'ny fanovana",
'pageinfo-header-restrictions' => "Fiarovana an'ilay pejy",
'pageinfo-header-properties' => "Tondron'ilay pejy",
'pageinfo-display-title' => 'Lohateny aseho',
'pageinfo-length' => 'Halavam-pejy (oktety)',
'pageinfo-article-id' => 'Laharam-pejy',
'pageinfo-language' => "Tenin'ny votoatiny",
'pageinfo-robot-policy' => "Satan'ny motera fikarohana",
'pageinfo-robot-index' => 'Azo tondroina',
'pageinfo-robot-noindex' => 'Tsy azo tondroina',
'pageinfo-views' => "Isan'ny jery",
'pageinfo-watchers' => "Isan'ny mpandray anjara manaraka",
'pageinfo-redirects-name' => "Fihodinana manketo amin'ity pejy ity",
'pageinfo-subpages-name' => "Zana-pejin'ity pejy ity",
'pageinfo-firstuser' => 'Mpamorona ilay pejy',
'pageinfo-firsttime' => 'Daty namoronana ilay pejy',
'pageinfo-lastuser' => 'Mpanova farany',
'pageinfo-lasttime' => "Datin'ny fanovana farany",
'pageinfo-edits' => "Isa manontolon'ny fanovana",
'pageinfo-authors' => "Isa manontolon'ny mpandray anjara",
'pageinfo-recent-edits' => "Fanovana vao haingana (natao tanatin'ny $1)",
'pageinfo-recent-authors' => "Isa vao haingan'ny mpanoratra misongadina",
'pageinfo-hidden-categories' => 'Sokajy nafenina{{PLURAL:$1}} ($1)',
'pageinfo-templates' => 'Endrika natsofoka{{PLURAL:$1}} ($1)',
'pageinfo-transclusions' => "Pejy natsofoka tanatin'i ($1){{PLURAL:}}",
'pageinfo-toolboxlink' => 'Fampahalalana mikasika ny pejy',
'pageinfo-redirectsto' => "Fihdinana mankany amin'ny",
'pageinfo-redirectsto-info' => 'fampahalalana',
'pageinfo-contentpage' => 'Isaina ho pejim-botoatiny',
'pageinfo-contentpage-yes' => 'Eny',
'pageinfo-protect-cascading' => 'Miriana avy eto ny fiarovana',
'pageinfo-protect-cascading-yes' => 'Eny',
'pageinfo-protect-cascading-from' => "Ny fiarovana dia miriana avy amin'i",
'pageinfo-category-info' => 'Fampahalalana mikasika ny sokajy',
'pageinfo-category-pages' => 'Isam-pejy',
'pageinfo-category-subcats' => "Isan'ny zana-tsokajy",
'pageinfo-category-files' => "Isan'ny rakitra",

# Patrolling
'markaspatrolleddiff' => 'Marihana ho voamarina',
'markaspatrolledtext' => 'Marihana ho hita sy voatsara',
'markedaspatrolled' => 'Voamarina',
'markedaspatrolledtext' => "Ny santiôna voafidy an'ny [[:$1]] dia voamarika ho voamarina.",
'rcpatroldisabled' => "Tsy nalefa ny fanamarinana ao amin'ny fanovana farany.",
'rcpatroldisabledtext' => 'Tsy atao ankehitriny ny fanamarinana ny pejy novaina farany.',
'markedaspatrollederror' => 'Tsy afaka marihana ho voamarina',
'markedaspatrollederrortext' => 'Tsy maintsy misafidy santiôna iray ianao mba hahafahanao manamarika azy ho voamarina.',
'markedaspatrollederror-noautopatrol' => 'Tsy azonao marihana ho voamarina ny fanovanao.',
'markedaspatrollednotify' => "Voamarika ho hita ny fanovana natao tamin'i $1.",

# Patrol log
'patrol-log-page' => "Laogin'ny fanovana voamarina",
'patrol-log-header' => "Ity dia laogy mikasikan'ny fanovana voamarina.",
'log-show-hide-patrol' => "$1 ny laogy mikasikan'ny santiôna voamarina",

# Image deletion
'deletedrevision' => "Fanovana an'i $1 taloha voafafa.",
'filedeleteerror-short' => 'Tsi-fetezana teo am-pamafàna ilay rakitra : $1',
'filedeleteerror-long' => 'Nisy tsi-fetezana nitranga teo am-pamafàna ilay rakitra :

$1',
'filedelete-missing' => 'Ny rakitra « $1 » dia tsy afaka fafàna satria tsy misy izy.',
'filedelete-old-unregistered' => "Ny santiôn'ilay rakitra voafidy « $1 » dia tsy ao amin'ny banky angona.",
'filedelete-current-unregistered' => "Ny rakitra voafidy « $1 » dia tsy ao amin'ny banky angona.",
'filedelete-archive-read-only' => "Ny petra-drakitra fitehirizana « $1 » dia tsy afaka ovain'ny lohamilina.",

# Browsing diffs
'previousdiff' => '← Ilay fampitahana teo arina',
'nextdiff' => 'fampitahana manaraka →',

# Media information
'mediawarning' => "'''Fampitandremana''': Mety misy renifango manao ratsy io karazan-drakitra io.
Raha alefanao ilay izy, mety ho simban'io renifango io ny solosainao.",
'imagemaxsize' => "Ferana ny haben'ny sary ao amin'ny pejy famaritana ho:",
'thumbsize' => "Haben'ny thumbnail",
'widthheightpage' => '$1 × $2, pejy $3{{PLURAL:}}',
'file-info' => 'Haben-drakitra : $1, karazana MIME : $2',
'file-info-size' => "$1 × $2 teboka, haben'ilay rakitra : $3, endrika MIME : $4",
'file-info-size-pages' => '$1 × $2 teboka, haben-drakitra : $3, karazana MIME $4, pejy $5 {{PLURAL:}}',
'file-nohires' => "Tsy misy sary ngeza non'io",
'svg-long-desc' => 'rakitra SVG, habe $1 × $2 teboka, habe : $3',
'svg-long-error' => 'Rakitra SVG tsy ekena : $1',
'show-big-image' => "Hijery ny tena haben'ny sary",
'show-big-image-preview' => "Haben'ny topi-maso: $1.",
'show-big-image-other' => 'Habe hafa: $1{{PLURAL:$2}}',
'show-big-image-size' => '$1 × $2 teboka',
'file-info-gif-looped' => 'miverimberina',
'file-info-gif-frames' => 'sary{{PLURAL:$1}} $1',
'file-info-png-looped' => 'miverimberina',
'file-info-png-repeat' => 'nalefa in-$1{{PLURAL:$1}}',
'file-info-png-frames' => 'Sary $1{{PLURAL:$1}}',
'file-no-thumb-animation' => "'''Fantaro: Nohon'ny fifehezana ara-teknka, tsy ho alefa sarimihetsika ny sarikely GIF mavesatra ohatr'ity'''",

# Special:NewFiles
'newimages' => 'Tahala misy ny rakitra vaovao',
'imagelisttext' => "{{PLURAL:}}Eto ambany ny lisitran'ny rakitra $1 milahatra araka ny $2.",
'newimages-legend' => 'Anaran-drakitra',
'newimages-label' => "Anaran-drakitra (na singan'izy io) :",
'showhidebots' => '(rôbô $1)',
'noimages' => 'Tsy misy sary ato.',
'ilsubmit' => 'Karohy',
'bydate' => 'araka ny daty',
'sp-newimages-showfrom' => "Aseho ny rakitra vaovao manomboka amin'ny $1 tamin'ny $2",

# Video information, used by Language::formatTimePeriod() to format lengths in the above messages
'seconds' => 'segondra{{PLURAL:$1}}',
'minutes' => 'minitra{{PLURAL:$1}}',
'hours' => 'ora{{PLURAL:$1}}',
'days' => 'andro{{PLURAL:$1}}',
'ago' => '$1 lasa izay',
'just-now' => 'vao izao',

# Human-readable timestamps
'hours-ago' => '$1 ora lasa{{PLURAL:$1}}',
'minutes-ago' => '$1{{PLURAL:$1}} minitra lasa',
'seconds-ago' => '$1 segondra lasa{{PLURAL:$1}}',
'monday-at' => "Alatsinainy tamin'ny $1",
'tuesday-at' => "Talata tamin'ny $1",
'wednesday-at' => "Alarobia tamin'ny $1",
'thursday-at' => "Alakamisy tamin'ny $1",
'friday-at' => "Zoma tamin'ny $1",
'saturday-at' => "Sabotsy tamin'ny $1",
'sunday-at' => "Alahady tamin'ny $1",
'yesterday-at' => "Omaly tamin'ny $1",

# Bad image list
'bad_image_list' => "Ity ny andrefiny :

Ny lisitra ny takelaka (andalana manomboka amin'ny *) ihany no mandanja.
Tokony sary tsy misy na sary tsy izy ny rohy voalohany anaty andalana iray .
''Exception'' ny rohy hafa anatin'ilay andalana iray, ohatra ny pejy mety mampiasa ilay sary.",

# Metadata
'metadata' => 'Metadata',
'metadata-help' => "Mirakitra fampahalalana fanampiny, izay inoana ho napetraky ny fakan-tsary na scanner nampiasaina nanaovana ny numérisation-ny ity rakitra ity. Raha kitihina na ovana izy ity dia mety tsy hifanitsy amin'ny sary voaova ireo antsipirihany sasany ireo.",
'metadata-expand' => 'Asehoy ny antsipirihany',
'metadata-collapse' => 'Aza aseho ny antsipirihany',
'metadata-fields' => "Ho ao amin'ny ambangovangom-pejin-tsary ireo saham-pampahalala mahakasika ny tsary valisitra anatin'ity hafatra ity rehefa hafohezina ny tabilaon-tsaham-pampahalalana mahakasika ny sary. Hasitrika araka ny fahazarana ny saha fanatsofohan-teny hafa.
* make
* model
* datetimeoriginal
* exposuretime
* fnumber
* isospeedratings
* focallength
* artist
* copyright
* imagedescription
* gpslatitude
* gpslongitude
* gpsaltitude",

# Exif tags
'exif-imagewidth' => 'Halalaka',
'exif-imagelength' => 'Haavo',
'exif-bitspersample' => 'Bit isaky ny singa',
'exif-compression' => 'Karazana fanakelezana',
'exif-photometricinterpretation' => 'Endrika kôlôrimetrika',
'exif-orientation' => 'Todika',
'exif-samplesperpixel' => 'Mpandahatra isaky ny piksely',
'exif-planarconfiguration' => 'Fandaminana ny data',
'exif-ycbcrpositioning' => 'Fipetraky ny Y sy C',
'exif-yresolution' => 'Isan-teboka mijidina',
'exif-stripoffsets' => "Toerana isian'ny datan'ny sary",
'exif-rowsperstrip' => "Isan'ny andininy isaky ny bandy",
'exif-stripbytecounts' => "Haben'ny bandy amin'ny oktety",
'exif-whitepoint' => "Krômatisiten'ny teboka fotsy",
'exif-primarychromaticities' => "Krômatisiten'ny reniloko",
'exif-ycbcrcoefficients' => 'Fatra YCbCr',
'exif-datetime' => 'Daty fanovana',
'exif-imagedescription' => "Visavisan'ilay sary",
'exif-make' => 'Mpanamboatra ilay fakan-tsary',
'exif-model' => "Karazan'ilay fakan-tsary",
'exif-software' => 'Rindrankajy nampiasaina',
'exif-artist' => 'Mpaka azy',
'exif-copyright' => 'Mpanana ilay copyright',
'exif-exifversion' => 'Santiôna EXIF',
'exif-flashpixversion' => 'Santiôna FlashPix',
'exif-colorspace' => 'Valan-doko',
'exif-pixelydimension' => 'Haavon-tsary',
'exif-pixelxdimension' => 'Halala-tsary',
'exif-usercomment' => 'Diniky ny mpikambana',
'exif-relatedsoundfile' => 'Rakitra audio miaraka',
'exif-datetimeoriginal' => 'Daty fangalana niaviana',
'exif-datetimedigitized' => 'Daty nanaovana numerisation',
'exif-subsectime' => 'Daty nanovana',
'exif-exposuretime' => 'Fitaona famakiana',
'exif-exposuretime-format' => '$1 s ($2 s)',
'exif-fnumber' => 'Isa F',
'exif-exposureprogram' => 'Fomba famakiana',
'exif-isospeedratings' => 'ISO',
'exif-shutterspeedvalue' => 'hafaingam-panapenana ny APEX',
'exif-aperturevalue' => 'Fisanasana APEX',
'exif-brightnessvalue' => "Hazavan'ny APEX",
'exif-exposurebiasvalue' => 'fanitsiana ny fanehoana',
'exif-maxaperturevalue' => 'Fisokafana be indrindra',
'exif-subjectdistance' => "Halaviran'ny alaina sary",
'exif-meteringmode' => 'Fomba fandrefesana',
'exif-lightsource' => 'Loharanon-kazavana',
'exif-flashenergy' => "Angôvon'akonkazavana",
'exif-subjectlocation' => "Toeram-pisian'ny alaina sary",
'exif-filesource' => 'Fangon-drakitra',
'exif-digitalzoomratio' => "Tahan'ny zoom arak'isa",
'exif-imageuniqueid' => "ID an'io sary io manokana",
'exif-gpslatituderef' => 'Laharam-pehintany avaratra na atsimo',
'exif-gpslatitude' => 'Laharam-pehintany',
'exif-gpslongituderef' => 'Laharan-jarahasina andrefana na atsinanana',
'exif-gpslongitude' => 'Laharan-jarahasina',
'exif-gpsaltituderef' => 'Haambo tsiahy',
'exif-gpsaltitude' => 'Haambo',
'exif-gpstimestamp' => 'Ora GPS (famantaranandro atômika)',
'exif-gpsmeasuremode' => 'Fomba fandrefesana',
'exif-gpsdop' => 'Hatsiko ny fandrefesana',
'exif-gpsspeedref' => 'Mari-drefi-kafainganana',
'exif-gpsspeed' => 'Hafaingam-pandray GPS',
'exif-gpsimgdirection' => "Fitodihan'ny sary",
'exif-gpsdestlatitude' => 'Laharam-pehintany tanjona',
'exif-gpsareainformation' => 'Anaram-paritra GPS',
'exif-gpsdatestamp' => 'Daty GPS',
'exif-countrycreated' => 'Firenena nangalana ilay sary',
'exif-worldregiondest' => 'Faritany aseho',
'exif-countrydest' => 'Firenena aseho',
'exif-countrycodedest' => 'Kaodim-pirenena aseho',
'exif-provinceorstatedest' => 'Faritany aseho',
'exif-citydest' => 'Tanàna aseho',
'exif-sublocationdest' => 'Fari-tanàna aseho',
'exif-objectname' => 'Lohateny fohy',
'exif-specialinstructions' => 'Torolalana manokana',
'exif-headline' => 'Lohateny',
'exif-credit' => 'Isaorana/mpanome',
'exif-source' => 'Fiaviana',
'exif-editstatus' => "Sata ara-panontan'ny sary",
'exif-urgency' => 'Ilaina maika',
'exif-fixtureidentifier' => 'Anarana zavatra miverimberina',
'exif-locationdest' => 'Toerana aseho',
'exif-locationdestcode' => "Kaodin'ny toerana aseho",
'exif-objectcycle' => "Ora tanjon'ilay aino aman-jery",
'exif-contact' => 'Fampahalalana mikasika ny fifandraisana',
'exif-writer' => 'Mpanoratra',
'exif-languagecode' => 'Fiteny',
'exif-iimcategory' => 'Sokajy',
'exif-iimsupplementalcategory' => 'Sokajy fanampiny',
'exif-datetimeexpires' => 'Asa ampiasaina aoriany',
'exif-datetimereleased' => 'Navoaka ny',
'exif-originaltransmissionref' => "Kaodin-toeran'ny fampitana niaviana",
'exif-identifier' => 'Mpamaritra',
'exif-lens' => 'Lojy nampiasaina',
'exif-serialnumber' => "Isa laharan'ny fakan-tsary",
'exif-cameraownername' => "Tompon'ilay mpaka sary",
'exif-datetimemetadata' => "Daty nanovana faran'ny metadata",
'exif-nickname' => "Solonanaran'ilay sary",
'exif-rating' => "Naoty (ampahan'ny 5)",
'exif-rightscertificate' => 'Sertifikà fitantanana ny zo',
'exif-copyrighted' => "Satan'ny zom-pamorona",
'exif-copyrightowner' => "Tompon'ny zom-pamorona",
'exif-usageterms' => 'Fepe-pampiasana',
'exif-webstatement' => 'Fanamnbarana ny zom-pamorona online',
'exif-originaldocumentid' => 'ID manokana ny rakitra niaviana',
'exif-licenseurl' => "URl an'ilay lisansa",
'exif-morepermissionsurl' => 'Fampahalanana hafa mikasika ny lisansa',
'exif-attributionurl' => "Rehefa mampiasa ity asa ity dia asio rohy mankany amin'i",
'exif-preferredattributionname' => 'Rehefa mampiasa ilay asa, isaory',
'exif-pngfilecomment' => "Famoahan-kevitra momban'ilay rakitra PNG",
'exif-contentwarning' => 'Fampitandremana mikasika ny votoatiny',
'exif-giffilecomment' => 'Famoahan-kevitry ny rakirta GIF',
'exif-intellectualgenre' => 'Karazan-javatra',

'exif-copyrighted-true' => "Iharan'ny zom-pamorona",
'exif-copyrighted-false' => "Toetran'ny zom-pamorona tsy voafaritra",

'exif-unknowndate' => 'Daty tsy fantatra',

'exif-orientation-1' => 'Tsotra',

'exif-componentsconfiguration-0' => 'tsy nahitana',

'exif-exposureprogram-0' => 'Tsy nolazaina',

'exif-subjectdistance-value' => '$1 metatra',

'exif-meteringmode-0' => 'Tsy fantatra',
'exif-meteringmode-1' => 'Elanelana',
'exif-meteringmode-3' => 'Spot',
'exif-meteringmode-4' => 'Spot maro',
'exif-meteringmode-5' => 'Modely',
'exif-meteringmode-6' => 'An-tsilany',
'exif-meteringmode-255' => 'Hafa',

'exif-lightsource-0' => 'Tsy fantatra',
'exif-lightsource-1' => "Hazavan'andro",
'exif-lightsource-9' => "Toetr'andro mazava",
'exif-lightsource-10' => "Toetr'andro mandrahona",
'exif-lightsource-11' => 'Haloka',

# Flash modes
'exif-flash-mode-3' => 'Toetra aotômatika',

'exif-focalplaneresolutionunit-2' => 'Posy',

'exif-sensingmethod-1' => 'Tsy voafaritra',

'exif-subjectdistancerange-1' => 'Makrô',

# Pseudotags used for GPSLatitudeRef and GPSDestLatitudeRef
'exif-gpslatitude-n' => 'Avaratra',
'exif-gpslatitude-s' => 'Atsimo',

# Pseudotags used for GPSLongitudeRef and GPSDestLongitudeRef
'exif-gpslongitude-e' => 'Atsinanana',
'exif-gpslongitude-w' => 'Andrefana',

'exif-gpsstatus-a' => 'Am-pandrefesana',

'exif-gpsmeasuremode-2' => 'Fandrefesana 2D',
'exif-gpsmeasuremode-3' => 'Fandrefesana 3D',

# Pseudotags used for GPSSpeedRef
'exif-gpsspeed-k' => "Kilometatra isak'ora",
'exif-gpsspeed-m' => "Maily isak'ora",
'exif-gpsspeed-n' => 'Knot',

# Pseudotags used for GPSTrackRef, GPSImgDirectionRef and GPSDestBearingRef
'exif-gpsdirection-m' => "Avaratra arak'andriamby",

# External editor support
'edit-externally' => "Ovao amin'ny alalan'ny fampiasana fitaovana ivelan'ity Wiki ity io rakitra io",
'edit-externally-help' => "jereo any amin'[//www.mediawiki.org/wiki/Manual:External_editors ny torolalana] ny fanazavana fanampiny,.",

# 'all' in various places, this might be different for inflected languages
'watchlistall2' => 'rehetra',
'namespacesall' => 'rehetra',
'monthsall' => 'rehetra',
'limitall' => 'rehetra',

# Email address confirmation
'confirmemail' => 'Fanamarinana adiresy imailaka.',
'confirmemail_noemail' => "Tsy nilaza adiresy imailaka azo ampiasaina ianao tao amin'ny [[Special:Preferences|safidinao]].",
'confirmemail_text' => "
Ity wiki ity dia mitaky anao hanamarina ny adiresy imailaka nomenao
vao mahazo mampiasa ny momba ny imailaka ianao. Ampiasao ity bokotra eto ambany ity
mba handefasana fango fanamarinana any amin'ny adiresinao. Ny hafatra voaray dia ahitana
rohy misy fango. Sokafy amin'ny navigateur-nao
io rohy io mba hanamarinana fa misy ny adiresy imailaka nomenao.",
'confirmemail_pending' => 'Efa nandefasana imailaka misy ny tenimiafina fanamarinana ianao ;
raha vao nanokatra kaonty ianao, dia miandrasa minitra vitsivitsy mba ho tonga ilay imailaka aloha ny manontany tenimiafina vaovao.',
'confirmemail_send' => 'Alefaso ny fanamarinana ny imailaka',
'confirmemail_sent' => 'Lasa ny fanamarinana ny imailaka.',
'confirmemail_oncreate' => "Nalefa tany amin'ny adiresy imailakao ny kaody fanamarinana.
Tsy ilaina ampaisaina io tenimiafina io rehefa hiditra eto amin'ity wiki ity ianao, fa tsy maintsy omenao ilay izy rehefa mampiasa tao mifototra amin'ny imailaka.",
'confirmemail_sendfailed' => "Tsy lasa ny fanamarinana ny imailaka. Hamarino ny adiresy fandrao misy litera tsy mety.

Ity no naverin'ny mpandefa mailaka : $1",
'confirmemail_invalid' => 'Tsy mety ilay fango fanamarinana. Angamba efa lany daty?',
'confirmemail_needlogin' => 'Mila $1 ianao raha hanamarina ny adiresy imailakao.',
'confirmemail_success' => 'Voamarina ny adiresy imailakao. Afaka [[Special:UserLogin|miditra]] ianao ankehitriny ary mankafia ny wiki.',
'confirmemail_loggedin' => 'Voamarina ny adiresy imailakao ankehitriny.',
'confirmemail_error' => 'Nisy tsy fetezana nandritra ny fanamarinana adiresy imailaka.',
'confirmemail_subject' => "Fanamarinana adiresy imailaka avy amin'ny sehatra {{SITENAME}}",
'confirmemail_body' => 'Nisy olona, izay ianao ihany angamba, avy tamin\'ny adiresy IP $1, nanokatra kaonty
"$2" tamin\'ity adiresy imailaka ity tao amin\'ny sehatra {{SITENAME}}.

Mba hanamarinana fa anao tokoa io adiresy io ary mba hahafahana mampiasa
imailaka ao amin\'ny {{SITENAME}}, dia mba sokafy ity rohy eto ambany ity:

$3

Raha *tsy* ianao no nanokatra io kaonty io, dia aza sokafana ilay rohy.
Io fango fanamarinana io dia miasa hatramin\'ny $4.',
'confirmemail_invalidated' => 'Fanamarinana ny adiresy imailaka najanona',
'invalidateemail' => 'Manajanona ny fanamarinana ny adiresy imailaka',

# Scary transclusion
'scarytranscludedisabled' => '[Najanona ny atipetraka (transclusion) interwiki]',
'scarytranscludefailed' => "[Ny voaaka soa aman-tsara ilay endrika ho an'i $1]",
'scarytranscludetoolong' => '[Lava loatra ny URL]',

# Delete conflict
'deletedwhileediting' => 'Fampitandremana: Nisy namafa ity pejy ity raha mbola teo am-panovana azy ianao!',
'confirmrecreate' => "Nofafan'i [[User:$1|$1]] ([[User talk:$1|dinika]]) ity lahatsoratra ity taorian'ny nanombohanao nanova azy. Ny antony dia:
: ''$2''
Azafady hamafiso fa tena irinao averina hoforonina tokoa ity lahatsoratra ity.",
'recreate' => 'Jereo indray',

# action=purge
'confirm_purge_button' => 'Eka',
'confirm-purge-top' => "Fafana ve ny cache-n'ity pejy ity?",

# Multipage image navigation
'imgmultipageprev' => '← pejy nialoha',
'imgmultipagenext' => 'pejy manaraka →',
'imgmultigo' => 'Andao !',
'imgmultigoto' => "Handeha any amin'ny pejy $1",

# Table pager
'ascending_abbrev' => 'mihak.',
'descending_abbrev' => 'mihid.',
'table_pager_next' => 'Pejy manaraka',
'table_pager_prev' => 'Pejy nialoha',
'table_pager_first' => 'Pejy voalohany',
'table_pager_last' => 'Pejy farany',
'table_pager_limit' => 'Haneho zavatra $1 isaky ny pejy',
'table_pager_limit_submit' => 'Hitsidika',
'table_pager_empty' => 'Tsy nahitana valiny',

# Auto-summaries
'autosumm-blank' => 'Pejy nofotsiana',
'autosumm-replace' => 'Votoatiny novaina ho « $1 »',
'autoredircomment' => 'Pejy fihodinana mankany [[$1]]',
'autosumm-new' => "Pejy voaforona amin'ny « $1 »",

# Live preview
'livepreview-loading' => 'Am-pakàna…',
'livepreview-ready' => 'Am-pakàna … vita !',
'livepreview-failed' => 'Tsy nandeha soa aman-tsara ny topi-maso haingankaingana !
Andrano ny topi-maso tsotra.',
'livepreview-error' => 'Tsy afaka mifandray : $1 « $2 ».
Andramo ny topi-maso tsotra',

# Friendlier slave lag warnings
'lag-warn-normal' => "Ny fanovana vaovao nohon'ny $1 segondra {{PLURAL:}} dia tsy hiseho eo amin'ity lisitra ity.",
'lag-warn-high' => "Noho ny hataraiky ny lohamilin'ny banky angona, tsy hiseho eto ny fanovana natao tao anatin'ny fotoana latsaky ny $1 segondra{{PLURAL:}}.",

# Watchlist editor
'watchlistedit-numitems' => 'Ny lisitry ny pejy arahanao maso dia misy {{PLURAL:$1|lohateny iray|lohateny $1}}, raha tsy kaontiana ny pejin-dresaka.',
'watchlistedit-noitems' => 'Tsy misy lohateny ny lisitrao.',
'watchlistedit-normal-title' => 'Hanova ny lisitra ny pejy arahako maso',
'watchlistedit-normal-legend' => "Hanala lohateny ao amin'ny lisitra",
'watchlistedit-normal-submit' => 'Hanala ireo lohateny nosafidiana ireo',
'watchlistedit-raw-title' => "Hanova ny lisitra ny pejy arahako maso amin'ny fomba akorany",
'watchlistedit-raw-legend' => "Fanovana ilay lisitry ny pejy arahina maso amin'ny fomba akorany",
'watchlistedit-raw-titles' => 'Lohateny :',
'watchlistedit-raw-submit' => 'Havaozina ny lisitra',
'watchlistedit-raw-done' => 'Voavao ny lisitrao.',

# Watchlist editing tools
'watchlisttools-view' => 'pejy arahako maso',
'watchlisttools-edit' => 'Jereo sy ovao ny lisitra ny pejy fanaraha-maso',
'watchlisttools-raw' => 'Ovay ilay pejy arahako maso amizao',

# Core parser functions
'unknown_extension_tag' => 'Balizy mitondra itatra « $1 » tsy fantatra',
'duplicate-defaultsort' => '\'\'\'Tandremo\'\'\' : manitsaka ny sort key taloha "$1" ilay sort key ankehitriny "$2".',

# Special:Version
'version' => 'Santiôna',
'version-extensions' => 'Fanitarana nampidirina',
'version-specialpages' => 'Pejy manokana',
'version-variables' => 'Miova',
'version-other' => 'Samihafa',
'version-hook-subscribedby' => "Nalefan'i",
'version-version' => '(Santiôna $1)',
'version-license' => 'Lisansy',
'version-software' => 'Rindrankahy voapetraka',
'version-software-product' => 'Vokatra',
'version-software-version' => 'Santiôna',

# Special:FileDuplicateSearch
'fileduplicatesearch' => 'Hitady rakitra mitovy endrika',
'fileduplicatesearch-legend' => 'Hitady mitovy endrika',
'fileduplicatesearch-filename' => 'Anaran-drakitra :',
'fileduplicatesearch-submit' => 'Hikaroka',
'fileduplicatesearch-info' => "piksely $1 × $2<br />Haben'ilay rakitra : $3 <br />Karazana MIME : $4",
'fileduplicatesearch-result-1' => "Tsy misy rakitra mitovy amin'ny « $1 ».",
'fileduplicatesearch-result-n' => "Misy rakitra {{PLURAL:}}$2 mitovy amin'i « $1 ».",

# Special:SpecialPages
'specialpages' => 'Pejy manokana',
'specialpages-note' => '* Pejy manokana tsotra
* <strong class="mw-specialpagerestricted">Pejy manokana voafetra.</strong>',
'specialpages-group-maintenance' => 'laogy hikojakojana',
'specialpages-group-other' => 'Pejy manokana hafa',
'specialpages-group-login' => 'Hiditra / hisoratra anarana',
'specialpages-group-changes' => 'Fanovana farany sy laogy',
'specialpages-group-media' => 'Laogy sy fampidirana rakitra media.',
'specialpages-group-users' => 'Mpikambana sy satany',
'specialpages-group-highuse' => 'Pejy ampiasaina mafy',
'specialpages-group-pages' => 'Lisitra ny pejy',
'specialpages-group-pagetools' => "Fitaovna ho an'ny pejy",
'specialpages-group-wiki' => 'Data sy fitaovana',
'specialpages-group-redirects' => 'Pejy manokana voaodina',
'specialpages-group-spam' => 'Fitaovana fanalana spam',

# Special:BlankPage
'blankpage' => 'Pejy fotsy',
'intentionallyblankpage' => 'Avela fananiana ho fotsy ity pejy ity.',

# External image whitelist
'external_image_whitelist' => "#Avelao tahaka izao ity andalana ity.<pre>
#Lazao ny singana REGEX (ny singa voalaza eo anelanelan'ny //) eo ambany.
#Miady amin'ny URL ny sary ivelany izy ireo.
#Hiseho sahala sary izay miady, raha tsy izany dia rohy mankany amin'ilay sary ihany no haseho.
#Ho resaka ny andalana manomboka amin'ny #.
#Tsy miraharaha ny zanatsoratra sy ny renisoratra ity lisitra ity.

#Ataovy eo ambonin'ity andalana ity ny singana REGEX. Avelao tahaka izao ity andalana farany ity.</pre>",

# Special:Tags
'tags' => "Balizin'ny fanovana mety",
'tag-filter' => 'manasongadina [[Special:Tags|balizy]] :',
'tag-filter-submit' => 'Manasongadina',
'tags-title' => 'Balizy',
'tags-intro' => "Ity pejy ity dia manalisitra ny balizy azon'ny rindrankajy ampiasaina mba hanamarika fanovana iray sy ny dikany.",
'tags-tag' => "Anaran'ny balizy",
'tags-display-header' => "Seho anatin'ny lisitry ny fanovana",
'tags-description-header' => "Famisavisana tanteraka an'ilay balizy",
'tags-hitcount-header' => 'Fanovana voabalizy',
'tags-edit' => 'hanova',
'tags-hitcount' => '{{PLURAL:$1|fanovana|fanovana}} $1',

# Special:ComparePages
'comparepages' => 'Hampitaha pejy',
'compare-selector' => 'Hampitaha ny santiôm-pejy',
'compare-page1' => 'Pejy 1',
'compare-page2' => 'Pejy 2',
'compare-rev1' => 'Santiôna 1',
'compare-rev2' => 'Santiôna 2',
'compare-submit' => 'Ampitahao',

# Database error messages
'dberr-header' => 'Misy olana io wiki io',
'dberr-problems' => 'Azafady Tompoko ! Manana olana ara-teknika ny sehatra.',
'dberr-again' => 'Miandrasa minitra vitsivitsy ary alefaso fanindroany',
'dberr-info' => "(Tsy afaka mifandray amin'ny lohamilin'ny database : $1)",
'dberr-usegoogle' => "Afaka manandrana mikaroka eo amin'ny Google ianao mandritra izay.",
'dberr-cachederror' => 'Izy io dia dika nasitriky ny pejy nangatahana ary mety efa tola.',

# HTML forms
'htmlform-invalid-input' => "Nisy olana nitranga tamin'ny sanda sasany",
'htmlform-select-badoption' => 'Tsy azo ekena ny sanda nambaranao.',
'htmlform-int-invalid' => 'Tsy isa manontolo ny sanda nambaranao.',
'htmlform-float-invalid' => 'Tsy isa ny sanda nambaranao.',
'htmlform-int-toolow' => "Ny sanda nambaranao dia kely nohon'ny fetra iva indrindra $1",
'htmlform-int-toohigh' => "Ny sanda nambaranao dia ngeza nohon'ny fetra avo indrindra $1",
'htmlform-submit' => 'Alefa',
'htmlform-reset' => 'Hanala ny fanovana',
'htmlform-selectorother-other' => 'Hafa',

# New logging system
'logentry-delete-delete' => "nofafan'i $1 ny pejy $3",
'logentry-suppress-delete' => "nofafan'i $1 ny pejy $3",
'revdelete-restricted' => "nametraka fanerena ho an'ny mpandrindra",
'revdelete-unrestricted' => "fanerena nesorina tamin'ny mpandrindra",
'logentry-move-move' => "nanova ny anaran'i $3 ho $4 i $1",
'logentry-newusers-newusers' => '{{GENDER:$2|Noforonina}} ny kaontim-pikambana $1',
'logentry-newusers-create' => '{{GENDER:$2|Noforonina}} ny kaontim-pikambana $1',
'logentry-newusers-create2' => "{{GENDER:$2|Noforonin}}'i $1 ny kaomtim-pikambana $3",
'logentry-newusers-autocreate' => '{{GENDER:$2|Noforonina}} ho azy ny kaontim-pikambana $1',
'logentry-rights-rights' => "$1 dia nanova ny sokajim-pikambana isian'i $3 avy amin'ny $4 lasa $5{{GENDER:$2}}",
'logentry-rights-rights-legacy' => "{{GENDER:$2}}$1 nanova ny vonodrom-pikambana isian'i $3",
'logentry-rights-autopromote' => '{{GENDER:$2}}Lasa $5 ho azy i $1 izay $4 taloha',
'rightsnone' => '(tsy misy)',

# Feedback
'feedback-subject' => 'Lohahevitra:',
'feedback-message' => 'Hafatra:',
'feedback-cancel' => 'Foanana',
'feedback-submit' => 'Handefa ny fanehoan-kevitra',
'feedback-adding' => "Manampy ny fahenoan-kevitra amin'ilay pejy...",
'feedback-error1' => "Hadisoana: Valiny avy amin'ny API tsy fantatra",
'feedback-error2' => 'Hadisoana: Tsy voaòva',
'feedback-error3' => "Hadisoana: Tsy nisy valiny avy amin'ny API",
'feedback-thanks' => "Misaotra! lanefa tany amin'ilay pejy ''[$2 $1]'' ilay fanehoan-kevitrao.",
'feedback-close' => 'Vita',

# API errors
'api-error-empty-file' => 'Tsy misy na inona na inna ilay rakitra nalefanao.',
'api-error-emptypage' => 'Tsy azo atao ny mamorona pejy vaovao tsy misy votoatiny.',
'api-error-fetchfileerror' => 'Hadisoana naaty : misy hadisoana nitranga teo am-pangalana ilay rakitra.',
'api-error-file-too-large' => 'Lehibe loatra ny rakitra nalefanao.',
'api-error-filename-tooshort' => "Fohy loatra ny anaran'ilay rakitra.",
'api-error-filetype-banned' => 'Voarara io karazan-drakitra io.',
'api-error-filetype-missing' => 'Tsy ampy tovana ilay anaran-drakitra.',
'api-error-hookaborted' => "Najanon'ny faraingon'itatra ny fanovana nandramanao natao.",
'api-error-http' => "Hadisoana anaty: Tsy tafaray tamin'ilay lohamilina.",
'api-error-illegal-filename' => 'Tsy azo ampiasaina io anaran-drakitra io.',
'api-error-internal-error' => 'Hadisoana anaty: Nisy hadisoana nitranga teo am-pikajikajiana ny rakitrao',
'api-error-invalid-file-key' => "Hadisoana anaty: Tsy hita tao amin'ilay tahiry vonjimaika ilay rakitra.",
'api-error-missingparam' => "Hadisoana anaty: Parametatra tsy ampy ao amin'ny hataka.",
'api-error-missingresult' => 'Hadisoana anaty: Tsy afaka milaza izahay raha tena nahomby ilay fandikana.',
'api-error-mustbeloggedin' => 'Mila tafiditra ianao mba handefa rakitra.',
'api-error-mustbeposted' => 'Hadisoana anaty: Mila HTTP POST ilay hataka.',
'api-error-noimageinfo' => 'Nahomby ilay fandikana, fa tsy nanome antsika fampahalalana mikasika ilay raktira ilay lohamilina.',
'api-error-nomodule' => 'Hadisoana anaty: Tsy namaritra joro fandefasana.',
'api-error-ok-but-empty' => "Hadisoana anaty: Tsy nisy valiny avy amin'ilay lohamilina.",
'api-error-overwrite' => 'Tsy azo atao ny manitsaka rakitra efa misy.',
'api-error-stashfailed' => 'Hadisoana anaty: Tsy nahomby ny fitahirizana ilay rakitra vonjimaika ilay lohamilina.',
'api-error-timeout' => "Tsy namaly tanatin'ny fe-potoana nandrasana ilay lohamilina.",
'api-error-unclassified' => 'Nisy hadisoana tsy fantatra nitranga.',
'api-error-unknown-code' => "Hadisoana tsy fantatra : ''$1''.",
'api-error-unknown-error' => 'Hadisoana anaty: Nisy hadisoana tam-pandefasana ny rakitrao.',
'api-error-unknown-warning' => "Fampitandremana tsy fantatra : ''$1''.",
'api-error-unknownerror' => "Hadisoana tsy fantatra : ''$1''.",
'api-error-uploaddisabled' => "Tsy alefa eto amin'ity wiki ity ny fandefasan-drakita.",
'api-error-verification-error' => 'Mety tapaka ity rakitra ity, na diso tovan-drakitra.',

);
