<?php

$result = array( 'xmp-exif' =>
	array(
		'GPSAltitude' => -3.14159265301,
		'GPSDOP' => '5/1',
		'GPSLatitude' => 88.51805555,
		'GPSLongitude' => -21.12356945,
		'GPSVersionID' => '2.2.0.0'
        )
);
