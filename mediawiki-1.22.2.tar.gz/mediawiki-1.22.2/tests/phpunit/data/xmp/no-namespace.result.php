<?php

$result = array( 'xmp-exif' =>
	array(
		'FNumber' => '28/10',
	)
);
